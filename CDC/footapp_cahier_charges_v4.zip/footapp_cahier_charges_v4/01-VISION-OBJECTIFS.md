# 01 - VISION & OBJECTIFS

> **Document fondamental #1** | À lire en premier pour comprendre le "pourquoi" du projet.

---

## 🎯 VISION

**FootApp** est l'app de pronostics football automatisés par IA la plus accessible et fiable d'Afrique francophone.

> *"Donner aux parieurs les outils statistiques des pros, à un prix qu'un café ne coûte pas."*

---

## 🔥 PROBLÈME À RÉSOUDRE

Les parieurs francophones (Afrique de l'Ouest, France, Maghreb) souffrent de 3 maux :

1. **Services trop chers** : 50-100€/mois (Tipster Pro, BettingExpert)
2. **Trop opaques** : aucune transparence sur le taux de réussite réel
3. **Trop complexes** : nécessitent souvent carte bancaire (95% des Africains n'en ont pas)

### Conséquences pour eux

- Pertes financières à cause de pronostics au "feeling"
- Manque de confiance dans les services existants
- Pas d'accès aux outils statistiques modernes (xG, ML, analyses pros)

---

## 💡 SOLUTION FOOTAPP

Une application mobile + web qui propose :

| Pilier | Bénéfice utilisateur |
|--------|----------------------|
| 🤖 **IA + Machine Learning** | Pronostics analysés sur 50+ critères, auto-amélioration |
| 💰 **Freemium accessible** | Gratuit utilisable + abonnement à 8000 FCFA/mois |
| 📱 **Mobile Money** | Wave, Orange Money, MTN, Moov (sans CB) |
| 🎁 **Bonus 7 jours** | Premium gratuit via inscription bookmaker |
| 🔍 **Transparence totale** | Score de confiance 0-100 affiché publiquement |
| ⚡ **Auto-fill bookmakers** | Parier en 15 secondes au lieu de 5 minutes |

---

## 👥 PUBLIC CIBLE

### Persona Principal : "Mamadou, parieur urbain"

| Critère | Détail |
|---------|--------|
| **Âge** | 22-40 ans |
| **Sexe** | 90% hommes |
| **Localisation** | Capitales/grandes villes Afrique Ouest |
| **Profession** | Étudiant, jeune actif, travailleur informel |
| **Budget paris** | 10 000 - 50 000 FCFA/mois |
| **Device** | Smartphone Android entrée/milieu de gamme |
| **Connexion** | 4G majoritaire, parfois 3G |
| **Comportement** | Consulte 2-3x/jour, parie sur les soirs/weekends |
| **Frustration** | "Je perds plus que je ne gagne, je ne sais pas quoi parier" |

### Marchés Géographiques

#### 🥇 Priorité 1 - Afrique de l'Ouest (Mois 1-6)
- 🇧🇫 Burkina Faso
- 🇸🇳 Sénégal
- 🇨🇮 Côte d'Ivoire
- 🇲🇱 Mali

**Pourquoi en premier ?**
- Forte culture de paris sportifs
- Mobile Money mature (Wave, Orange Money)
- Faible concurrence locale
- Langue française (réduction coût marketing)

#### 🥈 Priorité 2 - Maghreb (Mois 7-9)
- 🇲🇦 Maroc
- 🇩🇿 Algérie
- 🇹🇳 Tunisie

#### 🥉 Priorité 3 - Europe Francophone (Mois 10-12)
- 🇫🇷 France
- 🇧🇪 Belgique
- 🇨🇭 Suisse romande

---

## 🎯 OBJECTIFS CHIFFRÉS

### Phase 1 - MVP (Mois 1-4)

**Objectifs techniques** :
- ✅ Algorithme à **60%+ de taux de réussite** sur backtest
- ✅ App stable (uptime > 99%)
- ✅ Temps réponse API < 500ms
- ✅ 0 crash critique

**Objectifs business** :
- ✅ 50 beta testeurs actifs
- ✅ 10 premières conversions premium (test du modèle)
- ✅ 5 inscriptions bookmakers via affiliation

### Phase 2 - Commercial (Mois 5-8)

**KPIs ciblés** :
- 🎯 **500 utilisateurs actifs** (DAU)
- 🎯 **10% conversion gratuit → premium**
- 🎯 **20 inscriptions bookmakers/semaine**
- 🎯 **Churn < 30%/mois**
- 🎯 **Revenus : 4 000€/mois**
- 🎯 **Break-even atteint** (mois 8)

### Phase 3 - Scale (Mois 9-12)

**KPIs ciblés** :
- 🚀 **2 000 utilisateurs actifs**
- 🚀 **15% conversion gratuit → premium**
- 🚀 **50 inscriptions bookmakers/semaine**
- 🚀 **NPS > 50**
- 🚀 **Revenus : 10 000-13 000€/mois**
- 🚀 **Multi-pays opérationnel**

---

## 💰 SOURCES DE REVENUS (Triple Revenu)

### 1. Abonnements (cible : 70% des revenus)

| Formule | Prix | Cible | % users |
|---------|------|-------|---------|
| **Journalière** | 500 FCFA | Curieux, événementiel | 5% |
| **Hebdomadaire** | 2 500 FCFA | Testeurs, occasionnels | 15% |
| **Mensuelle** ⭐ | 8 000 FCFA | Réguliers (offre phare) | 50% |
| **Trimestrielle** 🔥 | 20 000 FCFA | Engagés | 25% |
| **Tier VIP** 💎 | 15 000 FCFA/mois | High-ticket (Phase 2) | 5% |

### 2. Affiliation Bookmakers (cible : 20% des revenus)

- **Bonus 7j premium** si inscription via lien tracké
- Commission : 30-50€ par inscription confirmée
- Bookmakers : Betwinner, 1xBet, Melbet (extensible)

### 3. B2B & Premium (cible : 10% des revenus, Phase 3)

- API publique pour autres apps (SaaS)
- Coaching personnalisé (5 000 FCFA/session)
- Concours sponsorisés
- Marketplace pronostiqueurs (commission)

---

## 🏆 DIFFÉRENCIATION CONCURRENTIELLE

| Critère | FootApp | Concurrents (BettingExpert, Tipster Pro, etc.) |
|---------|---------|----------------------------------------------|
| **Prix mensuel** | 8 000 FCFA (~12€) | 50-100€ |
| **Transparence** | Score 0-100 affiché | Opaque |
| **Algorithme** | IA + ML auto-apprenant | Statistique classique |
| **Auto-fill bookmakers** | ✅ Oui (15 sec) | ❌ Non |
| **Mobile Money** | ✅ Wave, OM, MTN, Moov | ❌ Carte bancaire only |
| **Combiné gratuit** | ✅ Bienvenue (1×) | ❌ |
| **Bonus bookmakers** | ✅ 7j premium | ❌ |
| **Facteur horaire** | ✅ Algo 8% | ❌ |
| **Fonctionnalités sociales** | ✅ Groupes amis | ❌ |
| **Dark mode** | ✅ | Variable |
| **Multi-langues** | ✅ FR/EN/AR | FR uniquement souvent |

---

## 🧭 PRINCIPES NON-NÉGOCIABLES

### Ce que FootApp **EST**
- ✅ Une aide à la décision basée sur la data
- ✅ Une app transparente sur ses limites
- ✅ Un service responsable (avertissements, jeu responsable)
- ✅ Une expérience mobile premium à prix accessible

### Ce que FootApp **N'EST PAS**
- ❌ Un bookmaker (on ne prend pas de paris)
- ❌ Une garantie de gain (aucun service ne peut)
- ❌ Une app pour mineurs (18+ obligatoire)
- ❌ Un outil de manipulation (pas de "tip miracle")

---

## 🎬 SCÉNARIO D'USAGE TYPIQUE

**8h00** - Mamadou se réveille, ouvre FootApp.
→ Notification : *"5 nouveaux pronostics + Combiné du jour disponible"*

**8h30** - Pendant le petit-déj, il consulte les pronostics.
→ Voit un match Real Madrid vs Barcelone, score de confiance **78%**.
→ Lit l'analyse détaillée (forme, H2H, blessures, xG).

**9h00** - En bus, il décide de parier sur le combiné premium (5 matchs, cote x12).
→ Clique "Parier maintenant" → WebView Betwinner s'ouvre.
→ **Auto-fill** : tous les matchs et le stake sont pré-remplis en 3 secondes.
→ Il confirme et place son pari (10 000 FCFA).

**21h00** - Notifications résultats : 4/5 matchs gagnés.
→ Il consulte ses statistiques.
→ Partage le résultat avec son groupe d'amis sur l'app.

**Lendemain** - Il invite 2 amis avec son code parrain.
→ Reçoit 7 jours premium en cadeau.

---

## 📊 KPIs DE SUIVI (Vision Globale)

### Top 5 KPIs à suivre quotidiennement

1. **DAU** (Daily Active Users)
2. **Taux de conversion gratuit → premium**
3. **Win rate algorithme** (sur 7 derniers jours)
4. **Inscriptions bookmakers/jour** (revenus affiliation)
5. **Churn quotidien**

### Top 5 KPIs hebdomadaires

1. **MRR** (Monthly Recurring Revenue)
2. **CAC** (Customer Acquisition Cost)
3. **LTV** (Lifetime Value)
4. **Ratio LTV/CAC** (doit être > 3)
5. **NPS** (Net Promoter Score)

---

## ✅ CRITÈRES DE SUCCÈS PHASE 1

L'application sera considérée comme un **MVP réussi** si, à la fin du mois 4 :

- [ ] L'algorithme atteint **≥60% de win rate** sur 100+ pronostics testés
- [ ] L'app fonctionne sur **Android (priorité)** sans crashs
- [ ] **Au moins 50 utilisateurs** sont actifs régulièrement
- [ ] **Au moins 5 abonnements payants** ont été vendus
- [ ] **Au moins 1 inscription bookmaker** a généré une commission
- [ ] Le **système de paiement Paydunya** fonctionne en production
- [ ] **0 incident de sécurité** majeur

Si ces critères sont atteints → **Phase 2 = scaling**.
Si pas atteints → **Pivot et itération** avant scaling.

---

## 🔗 DOCUMENTS LIÉS

- `02-BUDGET-ROADMAP.md` → Comment financer et planifier
- `04-RISQUES-ALERTES.md` → Ce qui peut foirer
- `ANNEXE-Marketing-Strategy.md` → Comment acquérir les users

---

*Fin du document - Vision validée et alignée avec les choix utilisateur*
