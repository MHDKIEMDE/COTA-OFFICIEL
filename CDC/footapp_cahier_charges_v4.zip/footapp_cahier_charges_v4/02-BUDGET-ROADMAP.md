# 02 - BUDGET & ROADMAP

> **Document fondamental #2** | Réalité financière + planning sprint par sprint.

---

## 💰 BUDGET TOTAL PROJET

### Budget Phase 1 - MVP (4 mois) : **4 870€** ✅

> **Contrainte respectée : < 5000€**
> **Mode : Solo dev + IA (pas de salaires de devs)**

| Poste | Détail | Coût |
|-------|--------|------|
| **APIs & Services** | API-Football, SMS OTP, Firebase | 240€ |
| **Hébergement** | VPS Hostinger KVM2 (4 mois) | 60€ |
| **Stores & Domaine** | Google Play (25€) + Apple Dev (99€) + Domaine (12€) | 136€ |
| **Outils ML** | Crédits API OpenAI/Claude pour ML assistance | 200€ |
| **Design** | Templates Figma + icônes (Flaticon Pro) | 100€ |
| **Légal** | Audit juridique Afrique Ouest + RGPD CGU | 800€ |
| **Marketing pré-launch** | Pages Facebook/Insta, contenu test | 300€ |
| **Tests devices** | 1 iPhone d'occasion (test iOS) | 200€ |
| **Buffer imprévus** | 15% de marge | 500€ |
| **Outils dev** | Cursor Pro (16 mois × 20€) | 80€ |
| **Stripe & Crypto setup** | Frais activation comptes | 50€ |
| **Beta testing** | Récompenses 20 beta testeurs | 200€ |
| **Influenceur test** | 1 micro-influenceur test | 150€ |
| **Audit sécurité** | Pen test léger (étudiant freelance) | 300€ |
| **Pubs Facebook test** | Budget test 50€/sem × 4 | 200€ |
| **Workshops/Formation** | Cours ML Football (Udemy) | 50€ |
| **Comptabilité** | Création société + premier bilan | 1305€ |
| **TOTAL Phase 1** | | **4 871€** |

> 💡 **Si budget vraiment serré** : on peut couper Légal (-800€), Comptabilité (-1305€) et Pen test (-300€) → **Budget réduit : ~2466€**. Mais risques juridiques accrus.

### Budget Phase 2 - Growth (Mois 5-8) : auto-financé

À partir du mois 5, les revenus doivent couvrir :

| Poste | Coût mensuel |
|-------|--------------|
| VPS upgrade (8GB RAM) | 30€ |
| API-Football (Standard plan) | 30€ |
| SMS OTP volume | 50€ |
| Email (SendGrid) | 10€ |
| S3 stockage (backup) | 5€ |
| Sentry Pro | 26€ |
| Marketing Facebook/Insta Ads | 300€ |
| Influenceurs micro (5/mois × 50€) | 250€ |
| **TOTAL** | **701€/mois** |

**Hypothèse** : 50 abonnements × 8000 FCFA = ~600€/mois minimum.
Avec 100 users mensuels actifs payants → couverture totale.

### Budget Phase 3 - Scale (Mois 9-12) : ~2000€/mois

Inclut équipe (1 freelance dev + 1 community manager) + marketing scaling.

---

## 📅 ROADMAP SPRINT PAR SPRINT

> **Méthodologie** : Sprints de **1 ou 2 semaines** maximum. Livraison testable à chaque fin de sprint.

### 🗓️ Vue d'ensemble Phase 1 (14 semaines)

```
Semaine 1-2   : SPRINT-01 - Setup Backend Laravel
Semaine 3     : SPRINT-02 - Auth (OTP + Facebook)
Semaine 4-5   : SPRINT-03 - Algorithme v3.0
Semaine 6-7   : SPRINT-04 - Multi-sources données ML
Semaine 8     : SPRINT-05 - Paiements
Semaine 9     : SPRINT-06 - Affiliation + Auto-fill
Semaine 10-11 : SPRINT-07 - Mobile App Core
Semaine 12    : SPRINT-08 - Mobile Premium + Carte gratter
Semaine 13    : SPRINT-09 - Dashboard Admin
Semaine 14    : SPRINT-10 - Tests + Déploiement + Beta
```

### 🎯 Détail des Sprints Phase 1

| # | Sprint | Durée | Livrables Clés | Doc dédié |
|---|--------|-------|---------------|-----------|
| 01 | Setup Backend | 2 sem | Laravel installé, BDD, structure | `SPRINT-01-Setup-Backend.md` |
| 02 | Auth | 1 sem | OTP SMS + Facebook + JWT | `SPRINT-02-Auth-OTP.md` |
| 03 | Algorithme v3 | 2 sem | 6 critères + scoring + tests historiques | `SPRINT-03-Algorithme-v3.md` |
| 04 | Données ML | 2 sem | Multi-sources + xG + ML basique | `SPRINT-04-Donnees-ML.md` |
| 05 | Paiements | 1 sem | Paydunya + Stripe + webhooks | `SPRINT-05-Paiements.md` |
| 06 | Affiliation | 1 sem | Tracking bookmakers + auto-fill scripts | `SPRINT-06-Affiliation.md` |
| 07 | Mobile Core | 2 sem | Flutter + auth + dashboard | `SPRINT-07-Mobile-Core.md` |
| 08 | Mobile Premium | 1 sem | Carte à gratter + paiement intégré | `SPRINT-08-Mobile-Premium.md` |
| 09 | Admin | 1 sem | Filament dashboard | `SPRINT-09-Admin-Dashboard.md` |
| 10 | Tests/Deploy | 1 sem | Tests + APK + Beta | `SPRINT-10-Tests-Deploy.md` |

---

## ⏱️ ESTIMATIONS TEMPS (Solo + IA)

### Hypothèses

- **6h/jour** de travail effectif
- **5j/semaine** (week-end repos)
- **30h/semaine** productives
- **IA assistance** : Cursor + Claude → x2 vélocité par rapport à dev manuel

### Calcul réaliste

| Sprint | Heures estimées | Si 30h/sem |
|--------|----------------|------------|
| 01 - Backend | 50h | 2 sem |
| 02 - Auth | 25h | 1 sem |
| 03 - Algo | 60h | 2 sem |
| 04 - Données ML | 60h | 2 sem |
| 05 - Paiements | 30h | 1 sem |
| 06 - Affiliation | 30h | 1 sem |
| 07 - Mobile Core | 60h | 2 sem |
| 08 - Mobile Premium | 30h | 1 sem |
| 09 - Admin | 30h | 1 sem |
| 10 - Tests/Deploy | 30h | 1 sem |
| **TOTAL** | **405h** | **14 sem** |

### ⚠️ Si tu travailles à temps partiel

| Disponibilité | Phase 1 réaliste |
|---------------|------------------|
| 30h/semaine (full time) | 14 semaines (3.5 mois) |
| 20h/semaine | 21 semaines (5 mois) |
| 10h/semaine (soirs/weekends) | 41 semaines (10 mois) ⚠️ |

**Recommandation** : Si tu es à 10h/sem, **revois drastiquement le scope** ou **trouve un cofondateur tech**.

---

## 💸 PROJECTION REVENUS (Réaliste)

### Hypothèses conservatrices

- Conversion gratuit → premium : **8%** (vs 10% objectif)
- Churn mensuel : **35%** (vs 30% objectif)
- CAC moyen : **3€/user payant**
- LTV moyen : **15€** (~2 mois d'abo moyen)

### Mois par Mois

| Mois | Users actifs | Premium | Revenus Abo | Affiliation | **Total** |
|------|-------------|---------|-------------|-------------|-----------|
| 1 | 0 | 0 | 0€ | 0€ | **0€** (dev) |
| 2 | 20 (beta) | 2 | 24€ | 0€ | **24€** |
| 3 | 50 | 5 | 60€ | 50€ | **110€** |
| 4 | 100 | 10 | 120€ | 100€ | **220€** (Launch !) |
| 5 | 200 | 20 | 240€ | 200€ | **440€** |
| 6 | 350 | 35 | 420€ | 400€ | **820€** |
| 7 | 500 | 50 | 600€ | 600€ | **1 200€** |
| 8 | 700 | 70 | 840€ | 800€ | **1 640€** ⚖️ Break-even |
| 9 | 1000 | 100 | 1 200€ | 1 000€ | **2 200€** |
| 10 | 1500 | 150 | 1 800€ | 1 500€ | **3 300€** |
| 11 | 2000 | 200 | 2 400€ | 2 000€ | **4 400€** |
| 12 | 2500 | 250 | 3 000€ | 2 500€ | **5 500€** |

### 📊 Projections Optimiste vs Pessimiste

| Scénario | Mois 6 | Mois 12 |
|----------|--------|---------|
| 🔴 Pessimiste | 400€ | 2 500€ |
| 🟡 Réaliste (ci-dessus) | 820€ | 5 500€ |
| 🟢 Optimiste | 1 500€ | 10 000€ |

> **Note** : Les chiffres optimistes du cahier précédent (4000€/mois au mois 6) étaient **trop optimistes** pour un solo dev en Afrique Ouest sans réseau établi. Cette nouvelle projection est plus prudente.

---

## 🎯 OBJECTIFS DE TRÉSORERIE

### Mois 1-4 : Investissement
- **Cash sortant** : -4 870€
- **Cash entrant** : +220€ (mois 4)
- **Net** : **-4 650€**

### Mois 5-8 : Croissance
- **Cash sortant** : -2 800€ (4 mois × 700€)
- **Cash entrant** : +4 100€
- **Net** : **+1 300€** ✅

### Mois 9-12 : Profitabilité
- **Cash sortant** : -8 000€ (équipe + marketing)
- **Cash entrant** : +15 400€
- **Net** : **+7 400€** 🎉

### Cumul fin année 1
- **Total investi** : ~7 700€
- **Total revenus** : ~14 720€
- **Profit net** : **+7 020€** ✅

---

## 🚨 SEUILS DE DÉCISION

### Si fin du mois 4 :
- ✅ Win rate algo > 55% → **CONTINUE** (objectif 60% au mois 6)
- ⚠️ Win rate algo 50-55% → **PIVOT ALGO** (revoir critères)
- 🔴 Win rate algo < 50% → **STOP & THINK** (modèle remis en cause)

### Si fin du mois 6 :
- ✅ Revenus > 700€ → **CONTINUE**
- ⚠️ Revenus 300-700€ → **OPTIMISER ACQUISITION**
- 🔴 Revenus < 300€ → **PIVOT MARKETING** ou abandon

### Si fin du mois 9 :
- ✅ Revenus > 2000€ → **SCALE Phase 3**
- ⚠️ Revenus 1000-2000€ → **CONTINUER PHASE 2**
- 🔴 Revenus < 1000€ → **REVOIR MODÈLE FONDAMENTAL**

---

## 🛠️ OUTILS RECOMMANDÉS POUR LE DEV SOLO

### Indispensables (dans le budget)

| Outil | Coût | Usage |
|-------|------|-------|
| **Cursor IDE** | 20€/mois | Dev assisté IA |
| **Claude Pro** | 18€/mois | Spec + architecture + debug |
| **GitHub** | Gratuit | Versioning + Actions CI/CD |
| **Postman** | Gratuit | Test API |
| **Figma** | Gratuit | Design UI |
| **Notion** | Gratuit | Specs + roadmap |
| **Linear** | Gratuit | Tickets/sprints |

### Optionnels mais utiles

| Outil | Coût | Usage |
|-------|------|-------|
| **GitHub Copilot** | 10€/mois | Auto-complétion |
| **Sentry** | Gratuit (10k events) | Monitoring erreurs |
| **PostHog Cloud** | Gratuit (1M events) | Analytics |

---

## 📈 STRATÉGIE D'ACQUISITION DE FONDS

### Si tu veux lever des fonds (Phase 2-3)

**Pré-seed** (~20 000-50 000€) à viser au **mois 6** si :
- ✅ MVP lancé
- ✅ Revenus mensuels > 500€
- ✅ 500+ users actifs
- ✅ Algorithme prouvé à 55%+

**Cibles potentielles** :
- Business Angels Afrique de l'Ouest (Orange Ventures, Wuri)
- Incubateurs (Jokkolabs Sénégal, Suguba Mali)
- Concours startup (Anzisha, Tony Elumelu Foundation)
- Plateformes : LaunchAfrica, AfricArena

**Préparation à anticiper** :
- Pitch deck 10 slides
- Business plan 3 ans
- Tableau de bord investisseurs (mensuel)
- Démo vidéo 2 min

> 📖 Détails : voir `ANNEXE-Marketing-Strategy.md`

---

## ✅ CHECKLIST DÉMARRAGE IMMÉDIAT

Avant le sprint 01, vérifier :

- [ ] Compte API-Football activé (plan Basic 15€/mois)
- [ ] VPS Hostinger commandé et configuré
- [ ] Domaine acheté (footapp.com ou .africa)
- [ ] Compte Paydunya créé (sandbox + prod)
- [ ] Compte Twilio/Termii pour SMS OTP
- [ ] Compte Firebase + projet créé
- [ ] Compte Google Play Developer (25€)
- [ ] Cursor IDE installé et configuré
- [ ] Claude Pro activé
- [ ] Repo GitHub créé (privé)
- [ ] Notion workspace setup
- [ ] Audit juridique commandé (en parallèle)

---

## 🔗 DOCUMENTS LIÉS

- `01-VISION-OBJECTIFS.md` → Le pourquoi
- `03-STACK-TECHNIQUE.md` → L'architecture
- `04-RISQUES-ALERTES.md` → Les pièges
- `SPRINT-01-Setup-Backend.md` → On y va !

---

*Budget validé pour < 5000€ | Roadmap réaliste solo + IA*
