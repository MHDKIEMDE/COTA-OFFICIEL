# 04 - RISQUES & ALERTES CRITIQUES

> **Document fondamental #4** | À lire avant de coder une ligne. Ce qui peut faire échouer le projet et comment l'éviter.

---

## 🚨 ALERTES CRITIQUES IDENTIFIÉES

### 🔴 ALERTE #1 - Gap Ambition vs Budget

**Problème** :
Tu as choisi des ambitions niveau "startup financée" :
- ML auto-apprenant
- Multi-sources données (xG, blessures, cotes)
- Tous championnats mondiaux
- 3 paiements (Paydunya + Stripe + Crypto)
- Site web SEO complet
- Pen testing + Bug bounty
- Multi-langues FR/EN/AR

**Mais** budget < 5000€ + dev solo.

**Coût réel de tout faire (agence)** : 25-40k€

**Mitigation appliquée dans ce cahier** :
- ✅ Phasage strict (P1 = essentiel, P2 = scaling, P3 = nice-to-have)
- ✅ ML simplifié au démarrage (règles + 1 modèle simple)
- ✅ 1 seule source de données au début (API-Football)
- ✅ Crypto reportée Phase 3
- ✅ Site web SEO Phase 2
- ✅ Bug bounty Phase 3
- ✅ FR uniquement Phase 1

**Action** : **Accepter de phaser** ou **trouver budget supplémentaire** (10-20k€).

---

### 🔴 ALERTE #2 - Algorithme à 60% est AMBITIEUX

**Problème** :
60% de win rate sur les paris sportifs est **très élevé**. Les meilleurs algorithmes professionnels (Pinnacle, etc.) sont autour de **55-58%** sur le long terme.

**Réalité du marché** :
- Algorithme amateur : 45-50%
- Algorithme moyen : 50-55%
- Algorithme professionnel : 55-60%
- Algorithme élite (avec ML + équipe data) : 60-63%

**Risque** : Si tu promets 60% et tu fais 52%, les utilisateurs partent.

**Mitigation** :
- ✅ **Ne JAMAIS communiquer un win rate avant de l'avoir prouvé** sur 100+ pronostics
- ✅ Afficher la **transparence totale** (win rate réel, même si bas)
- ✅ Commencer avec un objectif réaliste : **52-55% en MVP**, **58-60% au mois 12**
- ✅ Investir massivement en **données de qualité** (xG, blessures, compositions)
- ✅ Faire un **backtest rigoureux** avant de lancer

**Action critique** :
1. **Sprint 03** : développer l'algo de base
2. **Sprint 04** : backtest sur 1 an de données historiques
3. Si win rate < 55% → **itérer avant de lancer**
4. Si win rate > 55% → **lancer en bêta avec disclaimer**

---

### 🔴 ALERTE #3 - Légalité Paris en Afrique

**Problème** :
Les lois sur les paris/affiliation paris **changent rapidement** en Afrique de l'Ouest :

| Pays | Statut paris en ligne | Risque pour toi |
|------|----------------------|-----------------|
| 🇸🇳 Sénégal | Régulé (LONASE monopole) | ⚠️ Affiliation pourrait être illégale |
| 🇨🇮 Côte d'Ivoire | Régulé (LONACI) | ⚠️ Vérifier loi affiliation |
| 🇧🇫 Burkina Faso | Régulé (LONAB) | 🟢 Plus permissif |
| 🇲🇱 Mali | Peu régulé | 🟢 Tolérant |
| 🇫🇷 France | Strictement régulé (ANJ) | 🔴 Affiliation = besoin agrément |
| 🇧🇪 Belgique | Strictement régulé | 🔴 Idem |

**Risque** : ton app peut être bloquée du Play Store ou poursuivie pénalement dans certains pays.

**Mitigation OBLIGATOIRE** :
- ✅ **Audit juridique pays cibles** : ~500-800€ (4 pays)
- ✅ **Disclaimer juridique fort** : "+18", "Pariez avec modération"
- ✅ **Géoblocage** : bloquer l'accès aux pays interdits (France ANJ)
- ✅ **Mentions légales conformes** RGPD + loi locale
- ✅ **Ne pas faire de "promesses de gain"** dans le marketing

**Action immédiate** : commander l'audit juridique **AVANT** le sprint 06 (paiements + affiliation).

---

### 🔴 ALERTE #4 - Apple/Google Stores - Règles strictes

**Problème** :
Les apps de paris sportifs ont des règles ultra strictes sur les stores :

**Google Play** :
- ✅ Apps de **prédictions/conseils** : autorisées
- 🔴 Apps facilitant des **paris réels** : autorisations spéciales
- 🔴 Apps redirigeant vers bookmakers : **vérification supplémentaire**

**Apple App Store** (encore plus strict) :
- 🔴 Politique 1.6.4 : "Apps de gambling doivent être agréées"
- 🔴 Risque rejet **TRÈS ÉLEVÉ** si pas conforme

**Risque concret** : ton APK peut être rejeté → 2-4 semaines de retard.

**Mitigation** :
- ✅ **Lancer Android d'abord** (Play Store plus permissif)
- ✅ **Positionner comme "data analytics & football statistics"** (pas "betting tips")
- ✅ **Ne pas inclure de bouton "Parier" trop visible** dans le screenshot soumis
- ✅ **Avoir un disclaimer fort** dans la description
- ✅ **iOS** : reporter à Phase 2 après stabilisation Android
- ✅ **Plan B** : distribution APK directe via le site web

---

### 🔴 ALERTE #5 - Pas de KYC = Risque Fraude

**Problème** :
Tu as choisi "Pas de KYC". Ça simplifie l'inscription MAIS :
- 🔴 Paydunya peut bloquer les transactions > 100k FCFA sans KYC
- 🔴 Aucun recours si fraude (utilisateur fictif)
- 🔴 Risque d'utilisateurs mineurs (illégal)
- 🔴 Risque de fraude au parrainage (multi-comptes)

**Mitigation recommandée** :
- ✅ **Phase 1** : OTP SMS uniquement (déjà prévu) → suffisant pour MVP
- ✅ **Détection multi-comptes** : device fingerprinting (Phase 1)
- ✅ **Phase 2** : KYC progressif (vérification ID si transaction cumulée > 50k FCFA)
- ✅ **Phase 3** : KYC obligatoire pour Tier VIP

---

### 🟠 ALERTE #6 - Solo Dev = Burnout Risque

**Problème** :
14 semaines de dev intensif en solo + IA = **risque élevé de burnout** + erreurs + démotivation.

**Statistiques réelles** :
- 60% des projets solo échouent par démotivation
- 30% échouent par bugs critiques (pas assez de tests)
- 10% réussissent

**Mitigation** :
- ✅ **Pomodoro strict** : 25 min focus / 5 min pause
- ✅ **1 jour OFF par semaine** (vraiment)
- ✅ **Pas de codage > 8h/jour**
- ✅ **Rejoindre une communauté** : Discord Laravel France, Flutter Africa
- ✅ **Avoir un "accountability partner"** (ami à qui rendre des comptes)
- ✅ **Documenter en cours de route** (pas à la fin)
- ✅ **Beta testeurs dès la semaine 8** pour éviter l'isolement

---

### 🟠 ALERTE #7 - Dépendance API-Football

**Problème** :
Si API-Football a une panne, ton app **ne peut plus générer de pronostics**.

**Risques** :
- 🔴 Panne API → 0 pronostic du jour → users partent
- 🔴 Changement de tarifs (API-Football peut tripler ses prix)
- 🔴 Limites de requêtes atteintes (plan Basic = 100 req/jour)

**Mitigation** :
- ✅ **Cache agressif Redis** : 24h minimum sur les données matchs
- ✅ **Fallback API** : préparer code pour SofaScore ou Sportmonks (Phase 2)
- ✅ **Plan upgrade** : passer plan Standard (30€/mois) dès 200 users actifs
- ✅ **Stockage historique** : ne jamais perdre les données récupérées
- ✅ **Monitoring uptime** API externe (UptimeRobot)

---

### 🟠 ALERTE #8 - Concurrence Existante

**Problème** :
La concurrence est forte en Afrique :
- 1xBet Predictions (gratuit, intégré au bookmaker)
- Betwinner Tips
- BettingExpert (mondial)
- Tipster Pro
- Telegram channels gratuits

**Pourquoi tu peux gagner quand même** :
- ✅ **Mobile Money** (les concurrents utilisent CB)
- ✅ **Auto-fill bookmakers** (unique)
- ✅ **Transparence score 0-100** (unique)
- ✅ **Combiné gratuit bienvenue** (lead magnet)
- ✅ **Communauté locale francophone**
- ✅ **Prix accessible** (8000 FCFA vs 50€)

**Mitigation** :
- ✅ **Ne pas concurrencer les Telegram gratuits sur le prix** → différencier sur la qualité
- ✅ **Marketing local fort** (influenceurs Africains)
- ✅ **Communauté + UGC** (groupes amis = effet réseau)

---

### 🟠 ALERTE #9 - Conversion Premium est DURE

**Problème** :
Convertir 10% des users gratuits en premium est **ambitieux**. La moyenne du SaaS B2C est 2-5%.

**Pourquoi 10% est possible** :
- Prix accessible (8000 FCFA vs 50€ concurrents)
- ROI clair (utilisateur peut "gagner" plus que l'abo)
- Carte à gratter premium = teaser efficace
- Bonus 7j affiliation = test gratuit

**Mais** :
- 🔴 Si l'algo n'est pas > 55%, conversion sera 2-3%
- 🔴 Si l'UX est moyenne, conversion sera 3-5%
- 🔴 10% = nécessite tout : algo + UX + marketing

**Mitigation** :
- ✅ **A/B tester les prix** dès 100 users (test à 5000 / 8000 / 12000 FCFA)
- ✅ **Funnel optimisé** : afficher la valeur AVANT de demander payer
- ✅ **Trial premium 3 jours** automatique pour tout le monde
- ✅ **Reminders intelligents** : "Tu aurais gagné X cette semaine en premium"

---

### 🟠 ALERTE #10 - Marketing en Afrique = Cher et Lent

**Problème** :
Tu as choisi Facebook/Instagram + Google Ads + influenceurs (macro + micro).

**Coûts réels Afrique de l'Ouest** :
- CPM Facebook : 1-3€ (vs 5-10€ Europe)
- CPC Google "pronostic foot" : 0.30-0.80€
- Macro influenceur Afrique (50k+ followers) : 200-1000€/post
- Micro influenceur (5-20k followers) : 30-150€/post

**Budget marketing minimum recommandé** :
- 300€/mois Facebook Ads
- 200€/mois Google Ads
- 250€/mois influenceurs (5 micro)
- **Total : ~750€/mois** dès le mois 5

**Mitigation** :
- ✅ **Marketing organique d'abord** (TikTok, Telegram gratuit)
- ✅ **Partenariats échange de visibilité** (clubs amateurs = gratuit)
- ✅ **Concours mensuel 50k FCFA** = +1000 users gratuit (effet viral)
- ✅ **Budget Ads progressif** (commencer à 100€/mois mois 5)

---

## ⚠️ RISQUES TECHNIQUES SPÉCIFIQUES

### Risque T1 - Auto-fill bookmakers cassé

**Problème** : si Betwinner change son design, ton script auto-fill casse.

**Mitigation** :
- ✅ Monitoring Sentry sur erreurs auto-fill
- ✅ Fallback : deep link direct si script échoue
- ✅ Tests automatisés hebdomadaires
- ✅ Sélecteurs CSS multiples (redondance)

### Risque T2 - Saturation VPS

**Problème** : VPS Hostinger limité à ~500 users actifs.

**Mitigation** :
- ✅ Plan migration DigitalOcean documenté (Phase 2)
- ✅ Cache Redis agressif
- ✅ Optimisation DB queries (N+1 problem)

### Risque T3 - ML mal implémenté

**Problème** : ML mal fait = algo à 45% au lieu de 60%.

**Mitigation** :
- ✅ Commencer par règles métier (algo statique)
- ✅ Ajouter ML progressivement (mois 6+)
- ✅ Si possible : 1 freelance Data Scientist 1 jour/mois (~150€)
- ✅ Backtest obligatoire avant production

### Risque T4 - Crashes mobile

**Problème** : crash sur certains devices Android (fragmentation).

**Mitigation** :
- ✅ Test sur 5+ devices physiques (low-end inclus)
- ✅ Firebase Crashlytics dès le début
- ✅ Beta Play Store avant release publique

---

## 🛡️ PLAN DE GESTION DES RISQUES

### Matrice Risque/Probabilité

| Risque | Probabilité | Impact | Priorité |
|--------|-------------|--------|----------|
| Algorithme < 55% | Moyenne | Critique | 🔴 #1 |
| Légalité pays | Moyenne | Critique | 🔴 #2 |
| Burnout solo | Élevée | Élevé | 🔴 #3 |
| Rejet stores | Faible | Critique | 🟠 #4 |
| API-Football panne | Faible | Élevé | 🟠 #5 |
| Conversion < 5% | Élevée | Élevé | 🟠 #6 |
| Concurrence aggressive | Moyenne | Moyen | 🟢 #7 |
| Auto-fill cassé | Élevée | Moyen | 🟢 #8 |

### Plan de mitigation prioritaire

**Avant Sprint 01** (TODO immédiats) :
- [ ] Commander audit juridique (4 pays Afrique Ouest) → 500€
- [ ] Activer comptes API-Football, Paydunya, Firebase
- [ ] Acheter VPS Hostinger
- [ ] Setup Cursor + Claude Pro
- [ ] Créer planning hebdomadaire avec jour OFF

**Pendant Sprint 03 (Algorithme)** :
- [ ] Backtest sur 1 saison complète (PSG vs OM, Real vs Barça, etc.)
- [ ] Si win rate < 55% → arrêter et itérer
- [ ] Documenter chaque critère

**Avant Sprint 10 (Lancement)** :
- [ ] Audit juridique reçu et appliqué
- [ ] CGU + Politique confidentialité publiées
- [ ] Disclaimers visibles partout
- [ ] Beta testée par 20 personnes

---

## 📋 CHECKLIST RISQUES À VÉRIFIER MENSUELLEMENT

### Mois 1
- [ ] Audit juridique commandé
- [ ] Toutes APIs souscrites
- [ ] Burnout : combien d'heures/semaine ?

### Mois 2
- [ ] Algorithme en cours de développement
- [ ] Beta testeurs identifiés
- [ ] Trésorerie OK ?

### Mois 3
- [ ] Backtest algo OK ?
- [ ] Audit juridique reçu ?
- [ ] Stores soumissions préparées ?

### Mois 4 (LAUNCH)
- [ ] Win rate confirmé sur beta
- [ ] CGU/Politique en ligne
- [ ] Plan marketing prêt

### Mois 5+
- [ ] Conversion réelle vs objectif ?
- [ ] CAC vs LTV équilibré ?
- [ ] Aucun incident sécurité ?

---

## 🆘 PLAN B - SI ÇA TOURNE MAL

### Scénario : "Algorithme < 50%"

**Action** :
1. STOP, analyse pourquoi (data ? logique ? overfitting ?)
2. Investir dans 1 freelance Data Scientist (~500€)
3. Pivoter sur **transparence** : "Je vous donne mon algo, vous décidez"
4. Si vraiment impossible → pivot **agrégation pronostiqueurs externes**

### Scénario : "Aucune traction marketing"

**Action** :
1. Pivot sur Telegram (canal gratuit avec teaser)
2. Partenariats café/bars sportifs (offline)
3. Content marketing : YouTube analyses gratuites

### Scénario : "Pannes serveur fréquentes"

**Action** :
1. Migration immédiate DigitalOcean
2. CloudFlare devant pour caching
3. Read replicas MySQL

### Scénario : "Burnout / abandon"

**Action** :
1. Pause 2 semaines obligatoire
2. Trouver cofondateur tech (equity)
3. Si vraiment impossible → vendre le projet (5-15k€ sur Flippa)

---

## 🎯 SIGNAUX POSITIFS À CHERCHER

À l'inverse des risques, voici les signes que ça **marche** :

- ✅ Win rate algo > 55% en beta
- ✅ NPS > 30 dès les 50 premiers users
- ✅ Au moins 1 user qui parle de l'app spontanément (réseaux sociaux)
- ✅ Conversion > 5% sur les beta testeurs
- ✅ Au moins 1 inscription bookmaker via affiliation au mois 2
- ✅ Tu termines un sprint sur deux dans les délais
- ✅ Tu te lèves motivé le matin (vraiment)

---

## 🔗 DOCUMENTS LIÉS

- `01-VISION-OBJECTIFS.md` → Le pourquoi
- `02-BUDGET-ROADMAP.md` → Le quand
- `03-STACK-TECHNIQUE.md` → Le comment
- `ANNEXE-Securite-Conformite.md` → Sécurité légale détaillée

---

*Risques identifiés et mitigations prévues | À relire chaque mois*
