# 03 - STACK TECHNIQUE GLOBALE

> **Document fondamental #3** | Architecture choisie pour solo + IA + budget serré.

---

## 🏗️ STACK TECHNIQUE FINAL

### Vue d'ensemble

```
┌─────────────────────────────────────────────────────┐
│  📱 MOBILE APP (Flutter 3.24+)                       │
│  ├─ Riverpod (state management)                      │
│  ├─ Dio (HTTP client)                                │
│  ├─ Hive (cache local)                               │
│  └─ Firebase FCM (push notifications)                │
└─────────────────────────────────────────────────────┘
                       ↕ REST API + WebSockets
┌─────────────────────────────────────────────────────┐
│  ⚙️ BACKEND (Laravel 11+ - PHP 8.3+)                 │
│  ├─ Sanctum (auth tokens)                            │
│  ├─ Filament (admin dashboard)                       │
│  ├─ Scheduler (cron jobs)                            │
│  ├─ Horizon (queues)                                 │
│  └─ Telescope (debug, dev only)                      │
└─────────────────────────────────────────────────────┘
                       ↕
┌─────────────────────────────────────────────────────┐
│  🗄️ DATA LAYER                                        │
│  ├─ MySQL 8.0 (données principales)                  │
│  ├─ Redis (cache + sessions + queues)                │
│  └─ S3-compatible (backups + assets)                 │
└─────────────────────────────────────────────────────┘
                       ↕
┌─────────────────────────────────────────────────────┐
│  🤖 ML / DATA SCIENCE                                 │
│  ├─ Python 3.11+ (microservice séparé)               │
│  ├─ scikit-learn (modèles ML)                        │
│  ├─ pandas + numpy (manipulation data)               │
│  └─ FastAPI (exposer le modèle)                      │
└─────────────────────────────────────────────────────┘
                       ↕
┌─────────────────────────────────────────────────────┐
│  🌐 SERVICES EXTERNES                                 │
│  ├─ API-Football (données matchs)                    │
│  ├─ Paydunya (paiement Mobile Money)                 │
│  ├─ Stripe (paiement international)                  │
│  ├─ Twilio/Termii (SMS OTP)                          │
│  └─ Firebase (FCM, Analytics, Crashlytics)           │
└─────────────────────────────────────────────────────┘
```

---

## ⚙️ BACKEND - LARAVEL 11

### Pourquoi Laravel 11 ?

- ✅ **Mature** : framework PHP le plus utilisé
- ✅ **Écosystème riche** : Sanctum, Filament, Horizon, Telescope
- ✅ **Documentation excellente** : compréhensible par IA (Cursor/Claude)
- ✅ **Hosting facile** : marche sur tout VPS Linux
- ✅ **Communauté française** active
- ✅ **Idéal solo dev** : conventions claires, génération automatique

### Packages Composer essentiels

```json
{
  "require": {
    "php": "^8.3",
    "laravel/framework": "^11.0",
    "laravel/sanctum": "^4.0",
    "laravel/horizon": "^5.0",
    "filament/filament": "^3.2",
    "spatie/laravel-permission": "^6.0",
    "spatie/laravel-activitylog": "^4.8",
    "spatie/laravel-backup": "^9.0",
    "guzzlehttp/guzzle": "^7.8",
    "twilio/sdk": "^7.0",
    "predis/predis": "^2.2",
    "league/flysystem-aws-s3-v3": "^3.0",
    "barryvdh/laravel-debugbar": "^3.13",
    "sentry/sentry-laravel": "^4.0",
    "laravel/pulse": "^1.0",
    "laravel/socialite": "^5.10"
  }
}
```

### Architecture des dossiers

```
app/
├── Console/
│   └── Commands/        # Commandes artisan custom
├── Http/
│   ├── Controllers/
│   │   ├── Api/         # Controllers REST API
│   │   └── Webhooks/    # Webhooks Paydunya, Stripe
│   ├── Middleware/      # Auth, Premium, RateLimit
│   ├── Requests/        # Form Requests (validation)
│   └── Resources/       # API Resources (transformers)
├── Models/              # Eloquent Models
├── Services/            # Business logic
│   ├── Algorithm/       # Logique scoring
│   ├── Bookmaker/       # Affiliation
│   ├── ML/              # Wrapper Python ML
│   └── Notification/    # Push, SMS, Email
├── Jobs/                # 12+ Jobs schedulés
├── Listeners/           # Event listeners
├── Filament/            # Resources admin
└── Enums/               # Enums PHP 8.3
```

---

## 📱 MOBILE - FLUTTER 3.24+

### Pourquoi Flutter ?

- ✅ **Cross-platform** : 1 codebase = Android + iOS
- ✅ **Performance native** : Skia rendering
- ✅ **Hot reload** : dev rapide
- ✅ **Communauté massive** : packages pour tout
- ✅ **Idéal solo** : 1 dev = 2 plateformes
- ✅ **Tooling IA** : très bien supporté par Cursor/Copilot

### Packages pubspec.yaml essentiels

```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # State Management
  flutter_riverpod: ^2.5.0
  riverpod_annotation: ^2.3.0
  
  # HTTP & API
  dio: ^5.4.0
  retrofit: ^4.1.0
  
  # Cache & Storage
  hive: ^2.2.3
  hive_flutter: ^1.1.0
  shared_preferences: ^2.2.0
  
  # UI
  google_fonts: ^6.1.0
  flutter_svg: ^2.0.0
  cached_network_image: ^3.3.0
  shimmer: ^3.0.0
  lottie: ^3.0.0
  
  # Auth & Social
  firebase_auth: ^4.16.0
  firebase_core: ^2.24.0
  flutter_facebook_auth: ^6.0.0
  local_auth: ^2.1.7  # Biométrie
  
  # Notifications
  firebase_messaging: ^14.7.0
  flutter_local_notifications: ^16.3.0
  
  # WebView (auto-fill bookmakers)
  webview_flutter: ^4.4.0
  
  # Paiement
  url_launcher: ^6.2.0
  
  # Utils
  intl: ^0.19.0
  uuid: ^4.2.0
  collection: ^1.18.0
  
  # Analytics
  firebase_analytics: ^10.7.0
  firebase_crashlytics: ^3.4.0
  posthog_flutter: ^4.0.0
```

### Architecture Flutter (Clean Architecture)

```
lib/
├── core/
│   ├── api/             # Dio + Retrofit
│   ├── theme/           # Couleurs, typography, dark mode
│   ├── routing/         # GoRouter
│   └── utils/           # Helpers
├── data/
│   ├── models/          # JSON serializable
│   ├── repositories/    # Interface + impl
│   └── datasources/     # Remote + Local
├── domain/
│   ├── entities/        # Pure Dart classes
│   └── usecases/        # Business logic
├── presentation/
│   ├── screens/         # 12 écrans
│   ├── widgets/         # Composants réutilisables
│   └── providers/       # Riverpod providers
└── main.dart
```

---

## 🤖 MICROSERVICE ML - PYTHON

### Pourquoi un microservice séparé ?

- ✅ Python = standard pour ML (scikit-learn, TensorFlow)
- ✅ Découplage = scalabilité indépendante
- ✅ Permet de désactiver le ML sans impacter Laravel
- ✅ Facilite l'A/B testing (algo statique vs ML)

### Stack Python

```python
# requirements.txt
fastapi==0.110.0
uvicorn==0.27.0
scikit-learn==1.4.0
pandas==2.2.0
numpy==1.26.0
joblib==1.3.0
xgboost==2.0.0  # Boosting puissant
redis==5.0.0
python-dotenv==1.0.0
pytest==8.0.0
```

### Architecture

```
ml-service/
├── app/
│   ├── main.py              # FastAPI entry point
│   ├── models/
│   │   ├── predictor.py     # Modèle principal
│   │   ├── trainer.py       # Pipeline training
│   │   └── features.py      # Feature engineering
│   ├── data/
│   │   ├── fetcher.py       # Fetch depuis MySQL
│   │   └── preprocessor.py  # Nettoyage
│   └── api/
│       └── endpoints.py     # /predict, /retrain
├── notebooks/               # Jupyter pour exploration
├── tests/
└── trained_models/          # .pkl sauvegardés
```

### Communication Laravel ↔ Python

```
Laravel → HTTP POST → Python FastAPI
   ↓
   Body : { match_data: {...} }
   ↓
Python → Predict → Return score 0-100
   ↓
Laravel cache résultat dans Redis
```

> 📖 Détails ML complets : voir `ANNEXE-Algorithme-Detail.md`

---

## 🗄️ BASE DE DONNÉES - MySQL 8.0

### Tables principales (15 tables)

| Table | Description | Priorité |
|-------|-------------|----------|
| `users` | Utilisateurs | 🔴 Critique |
| `predictions` | Pronostics générés | 🔴 Critique |
| `matches` | Matchs football (cache API) | 🔴 Critique |
| `subscriptions` | Abonnements | 🔴 Critique |
| `payments` | Transactions | 🔴 Critique |
| `affiliations` | Inscriptions bookmakers | 🟠 Important |
| `referrals` | Parrainages | 🟠 Important |
| `feedbacks` | Support / bugs | 🟢 Standard |
| `combined_bets` | Combinés quotidiens | 🟠 Important |
| `notifications` | Historique notifs push | 🟢 Standard |
| `statistics` | Stats agrégées | 🟢 Standard |
| `promotions` | Codes promo bookmakers | 🟢 Standard |
| `user_preferences` | Préférences (langues, thèmes) | 🟢 Standard |
| `match_predictions_cache` | Cache scores ML | 🟠 Important |
| `audit_logs` | Logs sécurité (Spatie) | 🟢 Standard |

### Index essentiels (performance)

```sql
-- Performance lookup
CREATE INDEX idx_predictions_match_date ON predictions(match_date);
CREATE INDEX idx_predictions_status ON predictions(status);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_subscriptions_user_expires ON subscriptions(user_id, expires_at);
CREATE INDEX idx_matches_date_competition ON matches(match_date, competition_id);
```

> 📖 Schéma SQL complet : voir `ANNEXE-BDD-Schema.md`

---

## 🌐 INFRASTRUCTURE & HÉBERGEMENT

### Phase 1 - VPS Hostinger KVM2

| Composant | Spec |
|-----------|------|
| **CPU** | 4 vCPU |
| **RAM** | 8 GB |
| **Stockage** | 100 GB NVMe |
| **Bande passante** | 8 TB |
| **OS** | Ubuntu 22.04 LTS |
| **Coût** | ~15€/mois |

### Stack serveur

```
Nginx (reverse proxy + SSL Let's Encrypt)
  ├─ PHP 8.3-FPM (Laravel)
  ├─ Python 3.11 + Uvicorn (ML service)
  └─ Static files

Background:
  ├─ MySQL 8.0
  ├─ Redis 7.0
  ├─ Supervisor (queue workers)
  └─ Cron (Laravel scheduler)
```

### Phase 2+ - Migration recommandée

> ⚠️ **Limite VPS Hostinger** : ~500 utilisateurs actifs simultanés.
> Au-delà, migrer vers **DigitalOcean** :

| Plan | Spec | Coût |
|------|------|------|
| Basic Droplet | 4 GB / 2 vCPU | 24$/mois |
| Pro Droplet | 8 GB / 4 vCPU | 48$/mois |
| Standard | 16 GB / 8 vCPU | 96$/mois |

Avantages DO :
- ✅ Snapshots automatiques
- ✅ Load balancer disponible
- ✅ Managed Database (MySQL)
- ✅ Spaces (S3-compatible)
- ✅ Communauté + tutoriels

---

## 🔒 SÉCURITÉ - VUE D'ENSEMBLE

### Authentification

- **OTP SMS** : code 4 chiffres, validité 5 min
- **Facebook OAuth** : via Laravel Socialite
- **JWT Sanctum** : tokens 30 jours
- **Biométrie mobile** : empreinte/Face ID (optionnel)
- **Code PIN app** : 4-6 chiffres (optionnel)

### Protection API

- **Rate limiting** : 60 req/min/user
- **CORS** strict
- **CSRF protection** sur webhooks
- **Signature validation** sur callbacks paiement
- **HTTPS obligatoire** (Let's Encrypt)

### Données

- **Téléphone/email** chiffrés en BDD
- **Mots de passe** : bcrypt (cost 12)
- **OTP** : hashés (jamais en clair)
- **Backups quotidiens** : S3 chiffré

### Anti-fraude

- **Détection comptes multiples** : device fingerprinting
- **3D Secure** : sur paiements Stripe
- **Webhook signatures** : Paydunya + Stripe

> 📖 Détails sécurité : voir `ANNEXE-Securite-Conformite.md`

---

## 📊 OBSERVABILITÉ & MONITORING

### Outils gratuits/peu chers

| Outil | Type | Coût |
|-------|------|------|
| **Sentry** | Erreurs + crashes | Gratuit (10k events/mois) |
| **PostHog Cloud** | Analytics produit | Gratuit (1M events/mois) |
| **UptimeRobot** | Uptime monitoring | Gratuit |
| **Laravel Pulse** | Monitoring app | Gratuit |
| **Firebase Crashlytics** | Crashes mobile | Gratuit |
| **Metabase** | Dashboards BI | Gratuit (self-hosted) |

### Métriques essentielles à logger

**Backend** :
- Temps réponse API (p50, p95, p99)
- Taux d'erreur 5xx
- Queue jobs failed
- DB query slow (> 1s)
- Cache hit rate Redis

**Mobile** :
- Crash-free rate (> 99.5%)
- App startup time
- API call duration
- Frame rate (60 fps cible)

**Business** :
- DAU / MAU
- Conversion funnels
- Win rate algorithme
- Revenue per user

---

## 🚀 CI/CD - GitHub Actions

### Workflow Backend

```yaml
# .github/workflows/backend.yml
name: Backend CI/CD

on:
  push:
    branches: [main, develop]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup PHP
        uses: shivammathur/setup-php@v2
        with:
          php-version: '8.3'
      - name: Install dependencies
        run: composer install
      - name: Run tests
        run: php artisan test

  deploy:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to VPS
        run: |
          ssh user@vps "cd /var/www/footapp && git pull && composer install --no-dev && php artisan migrate --force && php artisan optimize"
```

### Workflow Mobile

```yaml
# .github/workflows/mobile.yml
name: Mobile CI/CD

on:
  push:
    branches: [main]

jobs:
  build-android:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.24.x'
      - run: flutter pub get
      - run: flutter test
      - run: flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: footapp-release.apk
          path: build/app/outputs/flutter-apk/app-release.apk
```

---

## 📦 OUTILS DEV (Solo + IA)

### Indispensables

| Outil | Rôle | Coût |
|-------|------|------|
| **Cursor IDE** | Dev assisté IA | 20€/mois |
| **Claude Pro** | Specs + debug + architecture | 18€/mois |
| **GitHub** | Versioning + Actions | Gratuit |
| **Docker** | Environnement reproductible | Gratuit |
| **Laravel Herd** | PHP local dev | Gratuit |
| **TablePlus** | GUI MySQL | Gratuit (limité) |
| **Postman** | Test API | Gratuit |
| **Figma** | Design + prototype | Gratuit |

### Workflow IA-assisté

1. **Spec** → écrite avec Claude (ce document)
2. **Architecture** → diagrammes via Mermaid + Claude
3. **Code** → généré par Cursor (Claude/GPT-4 inside)
4. **Tests** → générés par Cursor + revus manuellement
5. **Debug** → screenshots + Claude pour résoudre
6. **Documentation** → auto-générée depuis docstrings

---

## 🌍 INTERNATIONALISATION (i18n)

### Langues supportées (Phase 2)

- 🇫🇷 **Français** (par défaut)
- 🇬🇧 **English**
- 🇸🇦 **العربية** (Arabe, Maghreb)

### Implementation

**Backend** : Laravel `lang/` + JSON files
**Mobile** : `flutter_localizations` + ARB files

### Devises supportées

- **FCFA** (XOF) : Burkina, Sénégal, Mali, CI
- **EUR** : Europe
- **USD** : International
- **MAD/DZD/TND** : Maghreb (Phase 2)

---

## 🔗 DOCUMENTS LIÉS

- `01-VISION-OBJECTIFS.md` → Le pourquoi
- `02-BUDGET-ROADMAP.md` → Le quand et combien
- `04-RISQUES-ALERTES.md` → Les risques techniques
- `SPRINT-01-Setup-Backend.md` → Démarrage technique

---

*Stack validé pour solo dev + budget < 5000€ | Optimisée IA-friendly*
