# 🤖 MODULE - ML Avancé (Phase 3)

> **Phase** : 3 - Scale | **Durée** : 4 semaines (120h) | **Priorité** : 🟢 Tech avancé
> **Prérequis** : 1000+ users, données historiques solides, win rate stable

---

## 🎯 OBJECTIF

Passer du ML basique (régression logistique) à un système d'IA avancé :
- ✅ Modèles ensemble (XGBoost, LightGBM, CatBoost)
- ✅ Deep Learning (réseau de neurones)
- ✅ Re-training automatique hebdomadaire
- ✅ Feature engineering avancé (50+ features)
- ✅ Backtesting multi-périodes
- ✅ Détection de drift modèle
- ✅ Explicabilité (SHAP values)

**Win rate cible** : 60-65% (vs 55-58% en Phase 1).

---

## 🏗️ ARCHITECTURE

```
┌─────────────────────────────────────────────┐
│  Pipeline ML Avancé                          │
├─────────────────────────────────────────────┤
│  1. Data Collection (multi-sources)          │
│     ├─ API-Football                          │
│     ├─ SofaScore (xG)                        │
│     ├─ Understat                             │
│     ├─ Twitter sentiment (optionnel)         │
│     └─ Cotes bookmakers historiques          │
│                                              │
│  2. Feature Engineering (50+ features)       │
│     ├─ Statistiques basiques                 │
│     ├─ Forme rolling (5, 10, 15 matchs)      │
│     ├─ xG features                           │
│     ├─ Tendances temporelles                 │
│     ├─ Features interactions                 │
│     └─ Features ELO custom                   │
│                                              │
│  3. Modèles Ensemble                         │
│     ├─ XGBoost (gradient boosting)           │
│     ├─ LightGBM (rapide)                     │
│     ├─ Random Forest                         │
│     └─ Neural Network (Keras)                │
│                                              │
│  4. Stacking / Voting                        │
│     └─ Meta-learner final                    │
│                                              │
│  5. Production                               │
│     ├─ FastAPI (inference)                   │
│     ├─ Redis cache                           │
│     ├─ A/B testing                           │
│     └─ Monitoring                            │
└─────────────────────────────────────────────┘
```

---

## 📋 IMPLÉMENTATION (4 SEMAINES)

### Semaine 1 - Data Collection & Storage (30h)

#### Pipeline de collection enrichie

```python
# ml-service/app/data/collector.py
class FootballDataCollector:
    def __init__(self):
        self.sources = {
            'api_football': ApiFootballSource(),
            'understat': UnderstatSource(),
            'sofascore': SofaScoreSource(),  # via scraping ou API
        }
    
    def collect_match_features(self, match_id: int) -> dict:
        """Collecte TOUTES les features pour un match."""
        features = {}
        
        # Source 1: API-Football
        af_data = self.sources['api_football'].get_match(match_id)
        features.update(self._extract_basic_features(af_data))
        
        # Source 2: Understat (xG)
        understat_data = self.sources['understat'].get_match(match_id)
        features.update(self._extract_xg_features(understat_data))
        
        # Historique équipes (last 5, 10, 15 matches)
        for window in [5, 10, 15]:
            home_history = self._get_team_history(af_data['home_team'], window)
            away_history = self._get_team_history(af_data['away_team'], window)
            
            features.update({
                f'home_form_{window}': self._calc_form(home_history),
                f'away_form_{window}': self._calc_form(away_history),
                f'home_avg_goals_{window}': np.mean([m['home_goals'] for m in home_history]),
                f'away_avg_goals_{window}': np.mean([m['home_goals'] for m in away_history]),
                f'home_xg_avg_{window}': np.mean([m['xg'] for m in home_history if 'xg' in m]),
                f'away_xg_avg_{window}': np.mean([m['xg'] for m in away_history if 'xg' in m]),
            })
        
        # ELO custom
        features['home_elo'] = self._calculate_elo(af_data['home_team'])
        features['away_elo'] = self._calculate_elo(af_data['away_team'])
        features['elo_diff'] = features['home_elo'] - features['away_elo']
        
        return features
```

#### Système ELO custom

```python
class EloCalculator:
    """ELO rating dynamique pour les équipes."""
    
    INITIAL_RATING = 1500
    K_FACTOR = 32
    HOME_ADVANTAGE = 65
    
    def update_rating(self, home_elo, away_elo, result):
        """
        result: 1 = home win, 0.5 = draw, 0 = away win
        """
        expected_home = 1 / (1 + 10 ** ((away_elo - home_elo - self.HOME_ADVANTAGE) / 400))
        expected_away = 1 - expected_home
        
        new_home = home_elo + self.K_FACTOR * (result - expected_home)
        new_away = away_elo + self.K_FACTOR * ((1 - result) - expected_away)
        
        return new_home, new_away
```

### Semaine 2 - Modèles Ensemble (30h)

```python
# ml-service/app/models/ensemble_predictor.py
import xgboost as xgb
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
import joblib

class EnsemblePredictor:
    def __init__(self):
        self.models = {}
    
    def train(self, X_train, y_train, X_val, y_val):
        # XGBoost
        xgb_model = xgb.XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            objective='multi:softprob',
            num_class=3,
            eval_metric='mlogloss',
            early_stopping_rounds=20,
            random_state=42,
        )
        xgb_model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)
        self.models['xgboost'] = xgb_model
        
        # LightGBM
        lgb_model = lgb.LGBMClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            objective='multiclass',
            num_class=3,
            random_state=42,
        )
        lgb_model.fit(X_train, y_train, eval_set=[(X_val, y_val)], callbacks=[lgb.early_stopping(20)])
        self.models['lightgbm'] = lgb_model
        
        # Random Forest
        rf_model = RandomForestClassifier(
            n_estimators=200,
            max_depth=15,
            min_samples_split=10,
            random_state=42,
            n_jobs=-1,
        )
        rf_model.fit(X_train, y_train)
        self.models['random_forest'] = rf_model
        
        # Stacking final
        estimators = [
            ('xgb', xgb_model),
            ('lgb', lgb_model),
            ('rf', rf_model),
        ]
        
        stacking = StackingClassifier(
            estimators=estimators,
            final_estimator=LogisticRegression(max_iter=1000, multi_class='multinomial'),
            cv=5,
            n_jobs=-1,
        )
        stacking.fit(X_train, y_train)
        self.models['stacking'] = stacking
        
        # Évaluation
        for name, model in self.models.items():
            score = model.score(X_val, y_val)
            print(f"{name}: {score:.4f}")
    
    def predict(self, features: dict) -> dict:
        """Prédiction avec le modèle stacking."""
        X = pd.DataFrame([features])
        probas = self.models['stacking'].predict_proba(X)[0]
        
        return {
            'home_win_proba': float(probas[0]),
            'draw_proba': float(probas[1]),
            'away_win_proba': float(probas[2]),
            'predicted_class': int(np.argmax(probas)),
            'confidence': float(np.max(probas)) * 100,
        }
    
    def save(self, path: str):
        joblib.dump(self.models, path)
    
    def load(self, path: str):
        self.models = joblib.load(path)
```

### Semaine 3 - Re-training automatique + Drift detection (30h)

```python
# ml-service/app/training/auto_retrain.py
class AutoRetrainPipeline:
    def __init__(self, db_conn, mlflow_uri):
        self.db = db_conn
        # MLflow pour tracking des expériences
        mlflow.set_tracking_uri(mlflow_uri)
    
    def run(self):
        with mlflow.start_run():
            # 1. Charger nouvelles données (depuis dernière training)
            df = self._load_new_data()
            
            if len(df) < 100:
                print("Pas assez de nouvelles données, skip")
                return
            
            # 2. Préparer features
            X, y = self._prepare_features(df)
            
            # 3. Split temporel (pas random pour éviter data leakage)
            split_date = pd.Timestamp.now() - pd.Timedelta(days=30)
            train_mask = df['match_date'] < split_date
            X_train, X_val = X[train_mask], X[~train_mask]
            y_train, y_val = y[train_mask], y[~train_mask]
            
            # 4. Entraîner
            ensemble = EnsemblePredictor()
            ensemble.train(X_train, y_train, X_val, y_val)
            
            # 5. Évaluer
            val_score = ensemble.models['stacking'].score(X_val, y_val)
            
            # 6. Comparer au modèle actuel en production
            current_score = self._get_current_production_score()
            
            mlflow.log_metric('val_accuracy', val_score)
            mlflow.log_metric('current_prod_accuracy', current_score)
            
            # 7. Si nouveau modèle est meilleur, déployer
            if val_score > current_score + 0.01:  # +1% de gain min
                model_path = f'/opt/ml-service/trained_models/predictor_v{int(time.time())}.pkl'
                ensemble.save(model_path)
                
                # Update symlink "current"
                os.symlink(model_path, '/opt/ml-service/trained_models/current.pkl')
                
                # Restart FastAPI
                subprocess.run(['systemctl', 'restart', 'ml-service'])
                
                mlflow.log_artifact(model_path)
                print(f"✅ New model deployed: {val_score:.4f}")
            else:
                print(f"⚠️ New model not better ({val_score:.4f} vs {current_score:.4f})")
    
    def detect_drift(self):
        """Détecte si les performances actuelles divergent."""
        recent_predictions = self._load_recent_predictions(days=7)
        win_rate = recent_predictions['was_correct'].mean()
        
        # Alert si win rate descend sous 50% sur 7 jours
        if win_rate < 0.50:
            self._send_alert(f"⚠️ Drift détecté ! Win rate 7j : {win_rate:.2%}")
            # Auto-trigger retrain
            self.run()
```

**Schedule cron** :

```bash
# Re-train hebdomadaire (dimanche soir)
0 22 * * 0 cd /opt/ml-service && python -m app.training.auto_retrain

# Drift detection quotidien
0 3 * * * cd /opt/ml-service && python -m app.monitoring.drift_check
```

### Semaine 4 - Explicabilité + Production (30h)

```python
# Explainer SHAP pour comprendre les prédictions
import shap

class PredictionExplainer:
    def __init__(self, model, training_data):
        self.explainer = shap.TreeExplainer(model)
        self.feature_names = training_data.columns.tolist()
    
    def explain(self, features: dict) -> dict:
        X = pd.DataFrame([features])
        shap_values = self.explainer.shap_values(X)
        
        # Top 5 features qui poussent vers la prédiction
        importance = sorted(
            zip(self.feature_names, shap_values[0][0]),
            key=lambda x: abs(x[1]),
            reverse=True
        )[:5]
        
        return {
            'top_factors': [
                {
                    'feature': name,
                    'value': float(features[name]),
                    'impact': float(impact),
                    'direction': 'positive' if impact > 0 else 'negative',
                }
                for name, impact in importance
            ],
        }
```

**Endpoint enrichi** :

```python
@app.post("/predict/v2")
async def predict_v2(features: MatchFeatures):
    # Prédiction
    prediction = ensemble.predict(features.dict())
    
    # Explication
    explanation = explainer.explain(features.dict())
    
    return {
        **prediction,
        'explanation': explanation,
        'model_version': MODEL_VERSION,
    }
```

**UI Mobile** : afficher les top 3 facteurs influençant le score :

```
🎯 Pourquoi ce pronostic ?
✅ Forme récente domicile excellente (5V/5)
✅ xG domicile supérieur de 1.2
⚠️ Joueur clé blessé (impact moyen)
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Pipeline data avec 50+ features
- [ ] Modèle ensemble entraîné (XGBoost + LGB + RF + Stacking)
- [ ] Win rate validation > 60%
- [ ] Re-training automatique hebdo
- [ ] Drift detection quotidien
- [ ] MLflow tracking actif
- [ ] Explicabilité SHAP intégrée à l'API
- [ ] UI mobile montre les top facteurs

---

## 📊 ESTIMATION TEMPS

| Phase | Heures |
|-------|--------|
| Data collection enrichie | 30h |
| Modèles ensemble | 30h |
| Auto-retrain + drift | 30h |
| Explicabilité + Production | 30h |
| **TOTAL** | **120h** |

---

## 💰 BUDGET ML AVANCÉ

- VPS upgrade (16 GB RAM pour training) : +50€/mois
- MLflow self-hosted : gratuit
- Sources data premium (Sportmonks ou autres) : 50-100€/mois
- Freelance Data Scientist (validation/conseil) : ~500€ ponctuel

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-Marketplace-Pronostiqueurs.md`
