# ⚡ MODULE - Live Betting (Phase 3)

> **Phase** : 3 - Scale | **Durée** : 4 semaines (120h) | **Priorité** : 🟠 Tech challenge
> **Prérequis** : ML avancé en place, infrastructure scalable

---

## 🎯 OBJECTIF

Pronostics en temps réel pendant les matchs :
- ✅ Données live (score, possession, tirs, etc.)
- ✅ Prédictions actualisées toutes les 5 minutes
- ✅ WebSockets pour push instantané
- ✅ "Cash out" suggestions
- ✅ Notifications opportunités live

**Complexité** : ÉLEVÉE. Nécessite infrastructure robuste.

---

## ⚠️ ALERTES

🔴 **Coût API élevé** : Live data = 100-500€/mois supplémentaires
🔴 **Latence critique** : <2s end-to-end
🔴 **Volatilité ML** : modèles différents pour live vs pré-match

---

## 🏗️ ARCHITECTURE

```
┌──────────────────────────────────────────┐
│  API-Football Live (websocket/polling)   │
└──────────────────────────────────────────┘
              ↓ Update toutes les 30s
┌──────────────────────────────────────────┐
│  Laravel Service (live updater)          │
│  ├─ Update DB                            │
│  ├─ Trigger ML re-prediction             │
│  └─ Broadcast WebSocket (Reverb)         │
└──────────────────────────────────────────┘
              ↓
┌──────────────────────────────────────────┐
│  Mobile App (WebSocket subscriber)       │
│  └─ Display live updates instantly       │
└──────────────────────────────────────────┘
```

---

## 📋 IMPLÉMENTATION (résumé)

### Setup Reverb (WebSockets Laravel 11)

```bash
composer require laravel/reverb
php artisan reverb:install
```

### Modèle LiveMatch

```php
Schema::create('live_matches', function ($table) {
    $table->id();
    $table->foreignId('match_id')->constrained();
    $table->integer('home_score')->default(0);
    $table->integer('away_score')->default(0);
    $table->integer('minute');
    $table->json('events'); // [{type: 'goal', minute: 23, player: 'X'}]
    $table->json('stats'); // possession, shots, etc.
    $table->timestamp('updated_at');
});

Schema::create('live_predictions', function ($table) {
    $table->id();
    $table->foreignId('match_id')->constrained();
    $table->integer('minute');
    $table->json('next_goal_proba'); // {home: 0.4, away: 0.3, none: 0.3}
    $table->json('final_result_proba'); // {home_win: 0.5, draw: 0.2, away_win: 0.3}
    $table->json('over_under_25_proba');
    $table->timestamp('predicted_at');
});
```

### Service live updates

```php
class LiveMatchUpdater
{
    public function poll()
    {
        $liveMatches = FootballMatch::whereDate('match_date', today())
            ->where('match_date', '<=', now())
            ->where('status', '!=', 'FT')
            ->get();
        
        foreach ($liveMatches as $match) {
            $liveData = $this->apiService->getLiveData($match->external_id);
            
            $liveMatch = LiveMatch::updateOrCreate(
                ['match_id' => $match->id],
                [
                    'home_score' => $liveData['home_score'],
                    'away_score' => $liveData['away_score'],
                    'minute' => $liveData['minute'],
                    'events' => $liveData['events'],
                    'stats' => $liveData['stats'],
                ]
            );
            
            // Re-prédire
            $prediction = $this->mlService->predictLive($match, $liveData);
            
            LivePrediction::create([
                'match_id' => $match->id,
                'minute' => $liveData['minute'],
                ...$prediction,
            ]);
            
            // Broadcast
            broadcast(new LiveMatchUpdated($liveMatch, $prediction));
        }
    }
}
```

### Mobile WebSocket

```dart
// Package : pusher_channels_flutter (compatible Reverb)
final pusher = PusherChannelsFlutter.getInstance();

await pusher.init(
  apiKey: 'reverb_app_key',
  cluster: 'eu',
  authEndpoint: 'https://api.footapp.com/broadcasting/auth',
);

await pusher.subscribe(
  channelName: 'live-match.${match.id}',
  onEvent: (event) {
    if (event.eventName == 'LiveMatchUpdated') {
      final data = jsonDecode(event.data);
      // Update UI avec nouveau score + prédictions
    }
  },
);
```

### Notifications opportunités

```php
// Si la cote change drastiquement pendant le match
class DetectLiveOpportunitiesJob
{
    public function handle()
    {
        // Ex: équipe avec +85% chance gagner mais cote > 2.5 = opportunité
        $opportunities = LivePrediction::with('match')
            ->where('minute', '<', 80)
            ->where(function ($q) {
                $q->where('final_result_proba->home_win', '>', 0.85)
                  ->orWhere('final_result_proba->away_win', '>', 0.85);
            })
            ->get();
        
        foreach ($opportunities as $opp) {
            // Notifier les VIP en priorité
            User::where('subscription_type', 'vip')->each(function ($user) use ($opp) {
                $user->notify(new LiveOpportunityNotification($opp));
            });
        }
    }
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Polling live API toutes les 30s
- [ ] WebSocket fonctionne (Reverb)
- [ ] Re-prédiction ML toutes les 5 min
- [ ] UI mobile : scores en temps réel
- [ ] Notifications opportunités live
- [ ] Latence < 2s end-to-end

---

## 📊 ESTIMATION : 120h (4 sem)

---

## 🔗 → `MODULE-Multi-Sports.md`
