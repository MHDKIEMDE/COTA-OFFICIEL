# 🏀 MODULE - Multi-Sports (Phase 3)

> **Phase** : 3 - Scale | **Durée** : 3 semaines (90h) | **Priorité** : 🟢 Expansion produit
> **Prérequis** : App football mature, base d'utilisateurs solide

---

## 🎯 OBJECTIF

Étendre FootApp à d'autres sports populaires :
- ✅ 🏀 Basketball (NBA, EuroLeague)
- ✅ 🎾 Tennis (ATP, WTA, Grand Slams)
- ✅ ⚾ Cricket (IPL pour Afrique du Sud, Inde)
- ✅ 🏈 Football américain (NFL, optionnel)
- ✅ ⚽ E-sports (FIFA, optionnel)

**Impact** : +30% acquisition (touche nouveaux profils), +20% rétention.

---

## 🏗️ ARCHITECTURE

### Refactoring nécessaire

L'algorithme actuel est foot-specific. Il faut généraliser :

```php
// Avant
class FootballScoringService { ... }

// Après
abstract class SportScoringService
{
    abstract protected function getCriteria(): array;
    abstract protected function calculateBetTypes(): array;
    
    public function calculateScore(Match $match): float { ... }
}

class FootballScoringService extends SportScoringService { ... }
class BasketballScoringService extends SportScoringService { ... }
class TennisScoringService extends SportScoringService { ... }
```

### Critères par sport (différents !)

**Basketball** :
- Forme 5 derniers matchs (28%)
- H2H (15%)
- Domicile/Extérieur (15%)
- Points moyens marqués/encaissés (15%)
- Blessures joueurs clés (15%)
- Repos depuis dernier match (back-to-back -10%) (12%)

**Tennis** :
- Classement ATP/WTA (30%)
- H2H direct (25%)
- Surface (terre, dur, gazon) (20%)
- Forme 10 derniers matchs (15%)
- Distance parcourue (fatigue) (10%)

**Cricket** :
- Forme récente (25%)
- Lieu/conditions (terrain, météo) (20%)
- H2H (20%)
- Composition équipe (15%)
- Toss winner advantage (10%)
- Tournament context (10%)

### Migration tables

```php
// Étendre matches table
Schema::table('matches', function ($table) {
    $table->enum('sport', ['football', 'basketball', 'tennis', 'cricket'])->default('football');
    $table->json('sport_specific_data')->nullable();
});

// Compétitions multi-sports
Schema::table('competitions', function ($table) {
    $table->enum('sport', ['football', 'basketball', 'tennis', 'cricket'])->default('football');
});

// Predictions polymorphes
Schema::table('predictions', function ($table) {
    $table->string('sport')->default('football');
});
```

---

## 📋 IMPLÉMENTATION

### Semaine 1 (30h) - Refactoring + Basketball

#### Refactoring base

```php
// app/Services/Algorithm/Sports/AbstractSportScoring.php
abstract class AbstractSportScoring
{
    abstract public function getSportCode(): string;
    abstract public function getBetTypes(): array;
    abstract public function getCriteriaWeights(): array;
    
    public function calculateScore(Match $match): array
    {
        $weights = $this->getCriteriaWeights();
        $scores = [];
        
        foreach ($weights as $criterion => $weight) {
            $methodName = 'calculate' . str_replace('_', '', ucwords($criterion, '_'));
            $scores[$criterion] = $this->$methodName($match) * $weight;
        }
        
        return [
            'total_score' => array_sum($scores),
            'criteria' => $scores,
        ];
    }
}

// app/Services/Algorithm/Sports/BasketballScoring.php
class BasketballScoring extends AbstractSportScoring
{
    public function getSportCode(): string { return 'basketball'; }
    
    public function getBetTypes(): array
    {
        return ['match_winner', 'over_under_total_points', 'spread', 'first_half_winner'];
    }
    
    public function getCriteriaWeights(): array
    {
        return [
            'recent_form' => 28,
            'h2h' => 15,
            'home_away' => 15,
            'points_avg' => 15,
            'injuries_impact' => 15,
            'rest_days' => 12,
        ];
    }
    
    protected function calculateRestDays(Match $match): float
    {
        // Si équipe a joué hier (back-to-back), malus
        $homeLastMatch = $match->homeTeam->lastMatchBefore($match->match_date);
        $daysSince = $match->match_date->diffInDays($homeLastMatch->match_date);
        
        if ($daysSince === 1) return -10; // Back-to-back
        if ($daysSince === 2) return 0;
        return 5; // 3+ jours = bonus
    }
}
```

#### API NBA

API-Football couvre la NBA, sinon utiliser **TheRundown** ou **SportRadar**.

### Semaine 2 (30h) - Tennis

#### API Tennis : RapidAPI Tennis Live

```php
class TennisScoringService extends AbstractSportScoring
{
    public function getCriteriaWeights(): array
    {
        return [
            'ranking' => 30,
            'h2h' => 25,
            'surface_specific' => 20, // performance sur surface
            'recent_form' => 15,
            'fatigue' => 10,
        ];
    }
    
    protected function calculateSurfaceSpecific(Match $match): float
    {
        $surface = $match->venue['surface']; // 'clay', 'hard', 'grass'
        
        $homeWinRateSurface = $this->getPlayerWinRateOnSurface($match->homeTeam, $surface);
        $awayWinRateSurface = $this->getPlayerWinRateOnSurface($match->awayTeam, $surface);
        
        return ($homeWinRateSurface - $awayWinRateSurface) * 100;
    }
}
```

### Semaine 3 (30h) - Mobile UI Multi-sports

```dart
// lib/presentation/screens/dashboard/dashboard_screen.dart
class DashboardScreen extends ConsumerStatefulWidget {
  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  String _selectedSport = 'football';
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FootApp')),
      body: Column(
        children: [
          // Sport selector horizontal
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _SportChip(
                  label: '⚽ Football',
                  selected: _selectedSport == 'football',
                  onTap: () => setState(() => _selectedSport = 'football'),
                ),
                _SportChip(
                  label: '🏀 Basket',
                  selected: _selectedSport == 'basketball',
                  onTap: () => setState(() => _selectedSport = 'basketball'),
                ),
                _SportChip(
                  label: '🎾 Tennis',
                  selected: _selectedSport == 'tennis',
                  onTap: () => setState(() => _selectedSport = 'tennis'),
                ),
                _SportChip(
                  label: '🏏 Cricket',
                  selected: _selectedSport == 'cricket',
                  onTap: () => setState(() => _selectedSport = 'cricket'),
                ),
              ],
            ),
          ),
          
          Expanded(
            child: PredictionsList(sport: _selectedSport),
          ),
        ],
      ),
    );
  }
}
```

---

## 💰 IMPACT BUSINESS

### Acquisition

- **Football fans** : marché actuel
- **Basketball** : touche jeunes urbains (NBA culte en Afrique)
- **Tennis** : segment plus aisé, moins concurrencé
- **Cricket** : marché énorme Inde/Afrique du Sud (futur)

### Pricing

Pas de pricing différencié par sport en MVP. Tous les sports inclus dans le même abonnement → simplifie l'UX et augmente la valeur perçue.

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Architecture refactorée pour multi-sports
- [ ] Algorithme basketball fonctionnel (win rate > 55% backtest)
- [ ] Algorithme tennis fonctionnel (win rate > 60%)
- [ ] Algorithme cricket fonctionnel (basique)
- [ ] UI mobile avec sport selector
- [ ] Notifications par sport (préférences user)
- [ ] Stats par sport dans l'admin

---

## 📊 ESTIMATION : 90h (3 sem)

---

## 🔗 → `MODULE-Fantasy-Football.md`
