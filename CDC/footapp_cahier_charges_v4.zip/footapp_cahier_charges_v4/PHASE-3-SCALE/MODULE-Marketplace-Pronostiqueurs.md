# 🛒 MODULE - Marketplace Pronostiqueurs (Phase 3)

> **Phase** : 3 - Scale | **Durée** : 4 semaines (120h) | **Priorité** : 🟢 Business expansion
> **Prérequis** : 1500+ users, KYC en place, modération solide

---

## 🎯 OBJECTIF

Plateforme où des **tipsters humains** publient des pronostics payants, FootApp prend une commission :
- ✅ Profils tipsters vérifiés
- ✅ Système de notation/ranking
- ✅ Vente de pronostics individuels (500-3000 FCFA)
- ✅ Abonnements aux tipsters (5 000-20 000 FCFA/mois)
- ✅ Commission FootApp 30%
- ✅ Anti-fraude (KYC, modération)
- ✅ Stats publiques transparentes

**Cible** : 50 tipsters actifs, 200 ventes/mois, **revenus +5000€/mois**.

---

## ⚠️ ALERTES SPÉCIFIQUES

🔴 **KYC OBLIGATOIRE** : tipsters et acheteurs doivent être identifiés (légalité)
🔴 **Modération forte** : risque de scam/fake stats
🔴 **Légalité variable** : autorisé en France, mais à vérifier Afrique de l'Ouest
🔴 **Anti-fraude critique** : pronostics post-match interdits

---

## 📋 ARCHITECTURE

### Modèles

```php
Schema::create('tipster_profiles', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete()->unique();
    $table->string('display_name');
    $table->text('bio');
    $table->string('avatar_url')->nullable();
    $table->json('specialties'); // ['premier_league', 'over_under', ...]
    
    // KYC
    $table->enum('kyc_status', ['pending', 'verified', 'rejected'])->default('pending');
    $table->string('id_card_path')->nullable();
    $table->string('selfie_path')->nullable();
    $table->timestamp('verified_at')->nullable();
    
    // Stats publiques
    $table->integer('total_predictions')->default(0);
    $table->integer('won_predictions')->default(0);
    $table->decimal('win_rate', 5, 2)->default(0);
    $table->decimal('roi_30d', 5, 2)->default(0);
    $table->decimal('average_odds', 5, 2)->default(0);
    
    // Commercial
    $table->decimal('subscription_price', 10, 2)->nullable(); // FCFA/mois
    $table->integer('subscribers_count')->default(0);
    $table->decimal('total_earnings', 12, 2)->default(0);
    $table->decimal('total_payouts', 12, 2)->default(0);
    
    // Status
    $table->enum('status', ['active', 'suspended', 'banned'])->default('active');
    $table->integer('reports_count')->default(0);
    $table->timestamps();
});

Schema::create('tipster_predictions', function ($table) {
    $table->id();
    $table->foreignId('tipster_id')->constrained('tipster_profiles');
    $table->foreignId('match_id')->constrained();
    
    $table->string('bet_type');
    $table->string('bet_choice');
    $table->decimal('odds', 5, 2);
    $table->text('analysis');
    
    // Pricing
    $table->enum('access_type', ['subscribers_only', 'pay_per_view']);
    $table->decimal('individual_price', 10, 2)->nullable(); // si pay_per_view
    
    // Sécurité anti-fraude
    $table->timestamp('published_at');
    $table->timestamp('locked_at'); // 30 min avant le match (pas modifiable)
    $table->string('hash_signature'); // Hash signé pour preuve
    
    $table->enum('status', ['pending', 'won', 'lost', 'void'])->default('pending');
    $table->timestamp('settled_at')->nullable();
    
    $table->integer('purchases_count')->default(0);
    $table->timestamps();
});

Schema::create('tipster_subscriptions', function ($table) {
    $table->id();
    $table->foreignId('subscriber_user_id')->constrained('users');
    $table->foreignId('tipster_id')->constrained('tipster_profiles');
    $table->decimal('amount', 10, 2);
    $table->date('starts_at');
    $table->date('expires_at');
    $table->enum('status', ['active', 'expired', 'cancelled']);
    $table->timestamps();
});

Schema::create('tipster_pay_per_view', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('tipster_prediction_id')->constrained();
    $table->decimal('amount', 10, 2);
    $table->timestamp('purchased_at');
});
```

### Service Marketplace

```php
class MarketplaceService
{
    const PLATFORM_COMMISSION = 0.30; // 30% pour FootApp
    
    public function purchasePrediction(User $buyer, TipsterPrediction $prediction): array
    {
        // Vérifier que le match n'est pas commencé
        if ($prediction->match->match_date->isPast()) {
            throw new \Exception('Match déjà commencé, achat impossible');
        }
        
        // Vérifier déjà acheté
        $alreadyPurchased = TipsterPayPerView::where('user_id', $buyer->id)
            ->where('tipster_prediction_id', $prediction->id)
            ->exists();
        
        if ($alreadyPurchased) {
            throw new \Exception('Tu as déjà acheté ce pronostic');
        }
        
        // Créer la transaction
        $payment = $this->processPayment($buyer, $prediction->individual_price);
        
        TipsterPayPerView::create([
            'user_id' => $buyer->id,
            'tipster_prediction_id' => $prediction->id,
            'amount' => $prediction->individual_price,
            'purchased_at' => now(),
        ]);
        
        // Distribuer revenus
        $platformFee = $prediction->individual_price * self::PLATFORM_COMMISSION;
        $tipsterEarnings = $prediction->individual_price - $platformFee;
        
        $prediction->tipster->increment('total_earnings', $tipsterEarnings);
        $prediction->increment('purchases_count');
        
        return [
            'success' => true,
            'access_granted' => true,
            'prediction_data' => $prediction,
        ];
    }
    
    public function publishPrediction(TipsterProfile $tipster, array $data): TipsterPrediction
    {
        // Vérifier KYC
        if ($tipster->kyc_status !== 'verified') {
            throw new \Exception('KYC non vérifié, publication refusée');
        }
        
        // Vérifier match futur (sécurité anti-fraude)
        $match = FootballMatch::find($data['match_id']);
        if ($match->match_date->diffInMinutes(now()) < 30) {
            throw new \Exception('Trop tard ! Publication impossible < 30 min avant le match');
        }
        
        $prediction = TipsterPrediction::create([
            ...$data,
            'tipster_id' => $tipster->id,
            'published_at' => now(),
            'locked_at' => $match->match_date->copy()->subMinutes(30),
            'hash_signature' => $this->generateSignature($data),
        ]);
        
        return $prediction;
    }
    
    private function generateSignature(array $data): string
    {
        // Hash signé = preuve immuable de la prédiction
        $payload = json_encode($data) . config('app.key');
        return hash('sha256', $payload);
    }
}
```

### Vérification KYC

```php
class KycVerificationService
{
    public function submitKyc(User $user, array $documents)
    {
        $tipster = TipsterProfile::where('user_id', $user->id)->first()
            ?? TipsterProfile::create(['user_id' => $user->id, 'display_name' => $user->name]);
        
        // Upload documents
        $idPath = $documents['id_card']->store('kyc_documents', 'private');
        $selfiePath = $documents['selfie']->store('kyc_documents', 'private');
        
        $tipster->update([
            'id_card_path' => $idPath,
            'selfie_path' => $selfiePath,
            'kyc_status' => 'pending',
        ]);
        
        // Notifier admin
        Notification::route('mail', 'kyc@mhdservice.com')
            ->notify(new NewKycSubmissionNotification($tipster));
        
        return $tipster;
    }
}
```

### Modération automatique

```php
// Job détection anomalies
class ModerationCheckJob implements ShouldQueue
{
    public function handle()
    {
        // 1. Tipsters avec win rate suspect (>80% sur 30 jours)
        $suspicious = TipsterProfile::where('win_rate', '>', 80)
            ->where('total_predictions', '>', 30)
            ->get();
        
        foreach ($suspicious as $tipster) {
            // Audit manuel requis
            $this->flagForReview($tipster, 'unusually_high_winrate');
        }
        
        // 2. Plaintes utilisateurs
        $reported = TipsterProfile::where('reports_count', '>', 5)->get();
        foreach ($reported as $tipster) {
            $this->flagForReview($tipster, 'multiple_reports');
        }
        
        // 3. Tipsters inactifs (suspendre après 30j)
        TipsterProfile::where('status', 'active')
            ->whereDoesntHave('predictions', function ($q) {
                $q->where('created_at', '>', now()->subDays(30));
            })
            ->update(['status' => 'suspended']);
    }
}
```

### Mise à jour stats automatique

```php
// Job après chaque match terminé
class UpdateTipsterStatsJob implements ShouldQueue
{
    public function handle()
    {
        $tipsters = TipsterProfile::where('status', 'active')->get();
        
        foreach ($tipsters as $tipster) {
            $predictions = $tipster->predictions()
                ->whereIn('status', ['won', 'lost'])
                ->get();
            
            $won = $predictions->where('status', 'won')->count();
            $total = $predictions->count();
            
            // ROI 30 jours
            $recent = $tipster->predictions()
                ->whereIn('status', ['won', 'lost'])
                ->where('settled_at', '>', now()->subDays(30))
                ->get();
            
            $stake = 100; // virtuel
            $totalStaked = $recent->count() * $stake;
            $totalReturn = $recent->sum(function ($p) use ($stake) {
                return $p->status === 'won' ? $p->odds * $stake : 0;
            });
            
            $roi = $totalStaked > 0 
                ? (($totalReturn - $totalStaked) / $totalStaked) * 100
                : 0;
            
            $tipster->update([
                'total_predictions' => $total,
                'won_predictions' => $won,
                'win_rate' => $total > 0 ? round(($won / $total) * 100, 2) : 0,
                'roi_30d' => round($roi, 2),
                'average_odds' => $predictions->avg('odds') ?? 0,
            ]);
        }
    }
}
```

---

## 📱 UI MOBILE

```dart
// Liste des tipsters (ranking)
class TipstersDirectoryScreen extends ConsumerWidget {
  // Filters: win rate, ROI, prix
  // Sort: top performers, populaires, nouveaux
  // Cards avec stats publiques
}

// Profil tipster
class TipsterProfileScreen extends ConsumerStatefulWidget {
  // Header: avatar, bio, stats
  // Tab 1: Pronostics récents (avec lock si non abonné)
  // Tab 2: Historique stats
  // Tab 3: Avis
  // CTA: "S'abonner 8 000 FCFA/mois" ou "Acheter ce prono 500 FCFA"
}

// Devenir tipster
class BecomeTipsterScreen extends ConsumerStatefulWidget {
  // 1. Présentation gains (jusqu'à X FCFA/mois)
  // 2. KYC upload (CNI + selfie)
  // 3. Wait for verification
  // 4. Configure profile + pricing
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Profils tipsters avec KYC fonctionnel
- [ ] Achat pronostic individuel
- [ ] Abonnement à un tipster
- [ ] Stats auto-calculées toutes les heures
- [ ] Anti-fraude : impossible de publier < 30 min avant match
- [ ] Hash signature pour preuves
- [ ] Modération automatique des anomalies
- [ ] Système de paiement aux tipsters (KYC + virement)
- [ ] Reviews/ratings utilisateurs

---

## 💰 ÉCONOMIE

### Pour le tipster

- 70% des ventes
- Paiement mensuel (>10 000 FCFA min)
- Subscription récurrent

### Pour FootApp

- 30% commission
- 50 tipsters × 200 ventes × 1500 FCFA × 30% = **4.5M FCFA/mois (~6800€)**

---

## 📊 ESTIMATION TEMPS

| Phase | Heures |
|-------|--------|
| Modèles + KYC | 30h |
| Service Marketplace | 30h |
| Modération + Stats | 30h |
| UI Mobile | 30h |
| **TOTAL** | **120h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-API-Publique-B2B.md`
