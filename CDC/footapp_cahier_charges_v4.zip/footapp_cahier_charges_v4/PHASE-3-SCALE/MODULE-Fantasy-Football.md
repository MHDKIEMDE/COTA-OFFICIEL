# 🎮 MODULE - Fantasy Football (Phase 3)

> **Phase** : 3 - Scale | **Durée** : 6 semaines (180h) | **Priorité** : 🟢 Engagement long-terme
> **Prérequis** : 5000+ users, infrastructure scalable, équipe technique étoffée

---

## 🎯 OBJECTIF

Mode "Fantasy" intégré à FootApp :
- ✅ Création d'équipes virtuelles avec budget limité
- ✅ Compétitions privées entre amis
- ✅ Compétitions publiques mensuelles
- ✅ Cashprize via parrainage / abonnements premium
- ✅ Classements et leaderboards
- ✅ Intégration ML pour conseils

**Inspiration** : FPL (Fantasy Premier League), Sorare (mais sans NFT/blockchain en MVP).

---

## 📋 CONCEPT GAMIFIÉ

### Mécanique principale

1. **Budget** : 100M crédits virtuels par équipe
2. **Sélection** : 15 joueurs (gardien, défenseurs, milieux, attaquants)
3. **Captain** : 1 joueur × 2 points
4. **Vice-captain** : 1 joueur × 1.5 points si capitaine ne joue pas
5. **Transferts** : 1 gratuit/semaine, autres -4 points
6. **Points** : selon performance réelle (buts, assists, clean sheets, etc.)

### Compétitions

- **Public** : tous les users s'affrontent (gratuit)
- **Privée** : groupe d'amis (code d'invitation)
- **Premium** : payante (5 000 FCFA), prizepool réel
- **VIP** : exclusive aux Tier VIP

---

## 🏗️ ARCHITECTURE

### Modèles principaux

```php
Schema::create('fantasy_seasons', function ($table) {
    $table->id();
    $table->string('name'); // "Saison 2026 Premier League"
    $table->foreignId('competition_id')->constrained();
    $table->date('start_date');
    $table->date('end_date');
    $table->decimal('initial_budget', 10, 2)->default(100000000);
    $table->boolean('is_active')->default(true);
});

Schema::create('fantasy_players', function ($table) {
    $table->id();
    $table->foreignId('player_id')->constrained();
    $table->foreignId('fantasy_season_id')->constrained();
    $table->enum('position', ['GK', 'DEF', 'MID', 'FWD']);
    $table->decimal('price', 10, 2);
    $table->integer('total_points')->default(0);
    $table->integer('selected_by_count')->default(0);
});

Schema::create('fantasy_teams', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('fantasy_season_id')->constrained();
    $table->string('team_name');
    $table->json('current_squad'); // 15 player IDs
    $table->json('starting_xi'); // 11 player IDs
    $table->foreignId('captain_id')->nullable();
    $table->foreignId('vice_captain_id')->nullable();
    $table->decimal('budget_remaining', 10, 2);
    $table->integer('total_points')->default(0);
    $table->integer('overall_rank')->nullable();
    $table->integer('free_transfers_available')->default(1);
});

Schema::create('fantasy_gameweeks', function ($table) {
    $table->id();
    $table->foreignId('fantasy_season_id')->constrained();
    $table->integer('gameweek_number');
    $table->date('start_date');
    $table->date('end_date');
    $table->datetime('deadline');
    $table->boolean('is_finished')->default(false);
});

Schema::create('fantasy_team_gameweek', function ($table) {
    $table->id();
    $table->foreignId('fantasy_team_id')->constrained();
    $table->foreignId('gameweek_id')->constrained();
    $table->integer('points')->default(0);
    $table->integer('rank')->nullable();
    $table->json('squad_snapshot');
    $table->json('starting_xi_snapshot');
    $table->foreignId('captain_id')->nullable();
});

Schema::create('fantasy_leagues', function ($table) {
    $table->id();
    $table->string('name');
    $table->enum('type', ['public', 'private', 'premium', 'vip']);
    $table->string('invite_code', 8)->unique()->nullable();
    $table->foreignId('creator_user_id')->nullable()->constrained('users');
    $table->decimal('entry_fee', 10, 2)->default(0);
    $table->decimal('prize_pool', 10, 2)->default(0);
    $table->integer('max_members')->nullable();
    $table->foreignId('fantasy_season_id')->constrained();
});

Schema::create('fantasy_league_member', function ($table) {
    $table->id();
    $table->foreignId('league_id')->constrained('fantasy_leagues');
    $table->foreignId('team_id')->constrained('fantasy_teams');
    $table->integer('current_rank')->nullable();
    $table->timestamp('joined_at');
});
```

### Service principal

```php
class FantasyFootballService
{
    public function pickPlayer(FantasyTeam $team, int $playerId): array
    {
        $player = FantasyPlayer::find($playerId);
        
        // Vérifier budget
        if ($team->budget_remaining < $player->price) {
            throw new \Exception('Budget insuffisant');
        }
        
        // Vérifier nombre joueurs par équipe (max 3 par club réel)
        $teamPlayers = collect($team->current_squad)
            ->map(fn($id) => FantasyPlayer::find($id))
            ->filter();
        
        $sameClubCount = $teamPlayers
            ->where('player.team_id', $player->player->team_id)
            ->count();
        
        if ($sameClubCount >= 3) {
            throw new \Exception('Maximum 3 joueurs du même club');
        }
        
        // Vérifier composition (1 GK + 4 DEF + 4 MID + 3 FWD)
        $positions = $teamPlayers->groupBy('position')->map->count();
        $maxByPosition = ['GK' => 2, 'DEF' => 5, 'MID' => 5, 'FWD' => 3];
        
        if (($positions[$player->position] ?? 0) >= $maxByPosition[$player->position]) {
            throw new \Exception("Trop de {$player->position}");
        }
        
        // Ajouter au squad
        $squad = $team->current_squad;
        $squad[] = $playerId;
        $team->update([
            'current_squad' => $squad,
            'budget_remaining' => $team->budget_remaining - $player->price,
        ]);
        
        return ['success' => true, 'team' => $team->fresh()];
    }
    
    public function calculateGameweekPoints(FantasyTeam $team, FantasyGameweek $gameweek): int
    {
        $totalPoints = 0;
        $startingXi = $team->starting_xi;
        
        foreach ($startingXi as $playerId) {
            $points = $this->calculatePlayerPoints($playerId, $gameweek);
            
            if ($playerId === $team->captain_id) {
                $points *= 2;
            }
            
            $totalPoints += $points;
        }
        
        return $totalPoints;
    }
    
    private function calculatePlayerPoints(int $playerId, FantasyGameweek $gameweek): int
    {
        // Récupérer perfs réelles depuis API-Football
        $stats = $this->getPlayerStatsForGameweek($playerId, $gameweek);
        
        $points = 0;
        
        // Présence
        if ($stats['minutes_played'] >= 60) $points += 2;
        elseif ($stats['minutes_played'] > 0) $points += 1;
        
        // Buts (selon position)
        $position = $stats['position'];
        $goalPoints = match($position) {
            'GK', 'DEF' => 6,
            'MID' => 5,
            'FWD' => 4,
        };
        $points += $stats['goals'] * $goalPoints;
        
        // Passes décisives
        $points += $stats['assists'] * 3;
        
        // Clean sheet (GK et DEF)
        if (in_array($position, ['GK', 'DEF']) && $stats['clean_sheet']) {
            $points += 4;
        }
        
        // Cartons
        $points -= $stats['yellow_cards'] * 1;
        $points -= $stats['red_cards'] * 3;
        
        // Penalties (raté/sauvé pour GK)
        if ($position === 'GK' && $stats['penalty_saved']) $points += 5;
        if ($stats['penalty_missed']) $points -= 2;
        
        // Bonus (best players du match)
        $points += $stats['bonus_points'] ?? 0;
        
        return $points;
    }
}
```

---

## 📱 UI MOBILE

```dart
// Écran principal Fantasy
class FantasyHomeScreen extends ConsumerWidget {
  // Tab 1: Mon équipe (squad picker, formation)
  // Tab 2: Classement
  // Tab 3: Mes ligues
  // Tab 4: Statistiques
}

// Squad picker (drag & drop)
class SquadPickerScreen extends ConsumerStatefulWidget {
  // Terrain visuel (pitch)
  // Sélection joueurs par position
  // Indicateur budget restant
  // Bouton "Auto-fill" basé sur ML FootApp
}

// AI Auto-fill
class FantasyAutoFillButton extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ElevatedButton.icon(
      icon: const Icon(Icons.auto_awesome),
      label: const Text('Équipe optimale par IA'),
      onPressed: () async {
        // Appel à l'algo ML pour optimiser le squad
        final optimalSquad = await ref.read(fantasyAiProvider).suggestOptimalSquad(
          budget: 100000000,
          gameweek: currentGameweek,
        );
        // Pré-remplir l'équipe
      },
    );
  }
}
```

---

## 💰 MONÉTISATION

### Ligues Premium (5 000 FCFA entry)

- Compétition mensuelle
- Prizepool : 70% des entrées
- 30% commission FootApp

### Calcul ROI

- 200 participants × 5 000 FCFA = 1 000 000 FCFA
- Prizepool : 700 000 FCFA (top 10 récompensés)
- Commission FootApp : 300 000 FCFA (~450€/mois)

### Booster premium

- "Triple captain" : x3 au lieu de x2 (1 fois/saison)
- "Bench boost" : Tous les 15 joueurs comptent (1 fois/saison)
- "Free hit" : Refaire son équipe gratuitement (1 fois/saison)

→ Disponibles uniquement Premium FootApp.

---

## ✅ CRITÈRES DE VALIDATION

- [ ] User peut créer son équipe (15 joueurs)
- [ ] Validation budget + composition automatique
- [ ] Calcul points hebdomadaire automatique
- [ ] Classement public + privé
- [ ] Ligues d'amis avec invitation
- [ ] Ligues premium payantes
- [ ] AI auto-fill pour suggestion squad
- [ ] Prizepool distribution automatique

---

## 📊 ESTIMATION : 180h (6 sem)

---

## 🔗 PHASE 3 COMPLÈTE !

✅ Tous les modules Phase 3 documentés.

→ Passer aux **Annexes techniques** (`ANNEXE-Algorithme-Detail.md`, etc.)
