# 🔌 MODULE - API Publique B2B (Phase 3)

> **Phase** : 3 - Scale | **Durée** : 3 semaines (90h) | **Priorité** : 🟢 Revenu B2B
> **Prérequis** : Win rate stable > 60%, marque établie

---

## 🎯 OBJECTIF

API publique payante pour développeurs/sites tiers :
- ✅ API REST documentée (Swagger/OpenAPI)
- ✅ Plans tiered (Free, Pro, Enterprise)
- ✅ Rate limiting par plan
- ✅ Dashboard développeur self-service
- ✅ Webhooks pour résultats temps réel
- ✅ SLA et support

**Cible** : 10 clients B2B au mois 12 = **5 000-15 000€/mois MRR**.

---

## 📋 PLANS TARIFAIRES

| Plan | Prix/mois | Requêtes/jour | Features |
|------|-----------|---------------|----------|
| **Free** | 0€ | 100 | Pronos seuls |
| **Starter** | 49€ | 1 000 | + Stats basiques |
| **Pro** | 199€ | 10 000 | + Webhooks, ML scores |
| **Enterprise** | 999€+ | Illimité | + SLA 99.9%, support dédié |

---

## 🏗️ IMPLÉMENTATION

### Setup API Keys + Quotas

```php
Schema::create('api_keys', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->string('name'); // "Mon site web"
    $table->string('key', 64)->unique();
    $table->enum('plan', ['free', 'starter', 'pro', 'enterprise']);
    $table->integer('rate_limit_per_day');
    $table->timestamp('last_used_at')->nullable();
    $table->boolean('is_active')->default(true);
    $table->timestamps();
});

Schema::create('api_usage', function ($table) {
    $table->id();
    $table->foreignId('api_key_id')->constrained();
    $table->date('date');
    $table->integer('requests_count')->default(0);
    $table->json('endpoint_breakdown')->nullable();
});
```

### Middleware authentification + quota

```php
class ApiKeyAuth
{
    public function handle($request, Closure $next)
    {
        $key = $request->header('X-API-Key');
        if (!$key) abort(401, 'API key missing');
        
        $apiKey = ApiKey::where('key', $key)->where('is_active', true)->first();
        if (!$apiKey) abort(401, 'Invalid API key');
        
        // Check quota
        $usage = ApiUsage::firstOrCreate(
            ['api_key_id' => $apiKey->id, 'date' => today()],
            ['requests_count' => 0]
        );
        
        if ($usage->requests_count >= $apiKey->rate_limit_per_day) {
            abort(429, 'Rate limit exceeded for today');
        }
        
        $usage->increment('requests_count');
        $apiKey->update(['last_used_at' => now()]);
        
        $request->merge(['api_key' => $apiKey]);
        return $next($request);
    }
}
```

### Endpoints publics

```php
// routes/api.php (B2B)
Route::middleware('api.key')->prefix('public/v1')->group(function () {
    Route::get('/predictions/today', [PublicApiController::class, 'todayPredictions']);
    Route::get('/predictions/{id}', [PublicApiController::class, 'predictionDetail']);
    Route::get('/matches/today', [PublicApiController::class, 'todayMatches']);
    Route::get('/competitions', [PublicApiController::class, 'competitions']);
    Route::get('/teams/{id}/stats', [PublicApiController::class, 'teamStats']);
    
    // Pro plan only
    Route::middleware('api.plan:pro,enterprise')->group(function () {
        Route::get('/predictions/{id}/full-analysis', [PublicApiController::class, 'fullAnalysis']);
        Route::post('/webhooks/register', [PublicApiController::class, 'registerWebhook']);
    });
});
```

### Documentation Swagger

```bash
composer require darkaonline/l5-swagger
php artisan l5-swagger:generate
```

```php
/**
 * @OA\Get(
 *     path="/public/v1/predictions/today",
 *     summary="Get today's predictions",
 *     tags={"Predictions"},
 *     security={{"api_key": {}}},
 *     @OA\Response(
 *         response=200,
 *         description="List of today's predictions",
 *         @OA\JsonContent(
 *             @OA\Property(property="data", type="array", @OA\Items(ref="#/components/schemas/Prediction"))
 *         )
 *     )
 * )
 */
public function todayPredictions(Request $request) { ... }
```

### Dashboard développeur

UI web dédiée :
- Génération API keys
- Stats usage (graphiques)
- Logs requêtes récentes
- Documentation interactive
- Billing
- Webhook configuration

---

## ✅ CRITÈRES DE VALIDATION

- [ ] API keys génération + révocation
- [ ] Rate limiting par plan
- [ ] Documentation Swagger publique
- [ ] Dashboard dev fonctionnel
- [ ] Webhooks configurables (Pro+)
- [ ] Système billing automatique
- [ ] SLA monitoring (99.9% uptime)

---

## 📊 ESTIMATION TEMPS : 90h (3 sem)

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-Live-Betting.md`
