# 🔔 MODULE - Notifications Avancées

> **Phase** : 2 - Growth | **Durée** : 1 semaine (30h) | **Priorité** : 🟢 Engagement +25%
> **Prérequis** : Phase 1 lancée, FCM configuré

---

## 🎯 OBJECTIF

Système de notifications intelligent et personnalisé :
- ✅ Notifications smart (basées sur préférences)
- ✅ Segmentation avancée (par bookmaker, championnat)
- ✅ A/B testing des messages
- ✅ Opt-in granulaire (user choisit ce qu'il reçoit)
- ✅ Heures de notification respectées (DnD)
- ✅ Re-engagement users inactifs

**Impact attendu** : +25% engagement, -30% churn.

---

## 📋 IMPLÉMENTATION

### J1 (4h) - Préférences Notifications

```php
// Migration user_notification_preferences
Schema::create('user_notification_preferences', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    
    // Channels
    $table->boolean('push_enabled')->default(true);
    $table->boolean('email_enabled')->default(true);
    $table->boolean('sms_enabled')->default(false);
    
    // Types de notifs (granulaire)
    $table->boolean('new_predictions')->default(true);
    $table->boolean('combined_daily')->default(true);
    $table->boolean('match_results')->default(true);
    $table->boolean('subscription_reminders')->default(true);
    $table->boolean('promotions')->default(true);
    $table->boolean('challenges_reminders')->default(true);
    $table->boolean('contest_announcements')->default(true);
    
    // Filtres
    $table->json('preferred_competitions')->nullable(); // ['premier_league', 'la_liga']
    $table->json('preferred_bet_types')->nullable(); // ['1x2', 'btts']
    $table->integer('min_confidence_score')->default(60); // Seuil minimum pour notifier
    
    // Do Not Disturb
    $table->time('dnd_start')->default('22:00:00');
    $table->time('dnd_end')->default('07:00:00');
    $table->json('dnd_days')->nullable(); // jours OFF complets
    
    // Frequency cap
    $table->integer('max_notifications_per_day')->default(5);
});
```

### J2 (4h) - Service Smart Notifications

```php
// app/Services/Notification/SmartNotificationService.php
class SmartNotificationService
{
    public function shouldNotify(User $user, string $type, array $context = []): bool
    {
        $prefs = $user->notificationPreferences;
        
        // Désactivé par user
        if (!$prefs->push_enabled) return false;
        
        // Type désactivé
        if (!$prefs->{$type}) return false;
        
        // DnD actif
        if ($this->isInDndPeriod($prefs)) return false;
        
        // Filtres contextuels
        if ($type === 'new_predictions') {
            if (isset($context['confidence']) && $context['confidence'] < $prefs->min_confidence_score) {
                return false;
            }
            if (isset($context['competition']) && $prefs->preferred_competitions
                && !in_array($context['competition'], $prefs->preferred_competitions)) {
                return false;
            }
        }
        
        // Frequency cap
        $todayCount = NotificationLog::where('user_id', $user->id)
            ->whereDate('sent_at', today())
            ->count();
        if ($todayCount >= $prefs->max_notifications_per_day) return false;
        
        return true;
    }
    
    public function send(User $user, string $type, array $payload): bool
    {
        if (!$this->shouldNotify($user, $type, $payload)) {
            return false;
        }
        
        // Personnalisation message basée sur user
        $personalized = $this->personalizeMessage($user, $type, $payload);
        
        // Envoyer via FCM
        $sent = app(FcmService::class)->sendToUser($user, $personalized);
        
        // Log pour analytics
        NotificationLog::create([
            'user_id' => $user->id,
            'type' => $type,
            'title' => $personalized['title'],
            'body' => $personalized['body'],
            'payload' => $payload,
            'sent_at' => now(),
            'delivery_status' => $sent ? 'sent' : 'failed',
        ]);
        
        return $sent;
    }
    
    private function personalizeMessage(User $user, string $type, array $payload): array
    {
        $name = explode(' ', $user->name)[0];
        
        return match($type) {
            'new_predictions' => [
                'title' => "🔥 {$payload['count']} nouveaux pronostics, {$name} !",
                'body' => "Top match du jour : {$payload['top_match']} ({$payload['top_confidence']}% confiance)",
            ],
            'combined_daily' => [
                'title' => "💎 Combiné Premium prêt !",
                'body' => "5 matchs sélectionnés, cote totale x{$payload['total_odds']}",
            ],
            'match_results' => [
                'title' => $payload['won'] >= 3 ? "🏆 Excellente journée !" : "📊 Résultats du jour",
                'body' => "Bilan : {$payload['won']}/{$payload['total']} pronostics gagnants",
            ],
            'subscription_reminders' => match($payload['days_left']) {
                3 => [
                    'title' => "⏰ Ton abonnement expire bientôt",
                    'body' => "Plus que 3 jours pour renouveler. -10% si tu renouvelles aujourd'hui !",
                ],
                1 => [
                    'title' => "⚠️ Dernière chance",
                    'body' => "Ton premium expire demain. Ne rate pas les pronos !",
                ],
                0 => [
                    'title' => "❌ Premium expiré",
                    'body' => "Renouvelle pour reprendre l'accès complet.",
                ],
            },
            'inactive_user' => [
                'title' => "On t'a manqué, {$name} ? 👋",
                'body' => "Tu as raté {$payload['missed_predictions']} pronostics gagnants cette semaine !",
            ],
        };
    }
    
    private function isInDndPeriod($prefs): bool
    {
        $now = now();
        $start = Carbon::parse($prefs->dnd_start);
        $end = Carbon::parse($prefs->dnd_end);
        
        // Si DnD traverse minuit
        if ($start->gt($end)) {
            return $now->gte($start) || $now->lte($end);
        }
        return $now->between($start, $end);
    }
}
```

### J3 (4h) - Job Re-engagement

```php
// app/Jobs/ReengagementCampaignJob.php
class ReengagementCampaignJob implements ShouldQueue
{
    public function handle(SmartNotificationService $service)
    {
        // Users inactifs depuis 7 jours
        $inactive7d = User::where('last_login_at', '<', now()->subDays(7))
            ->where('last_login_at', '>', now()->subDays(14))
            ->get();
        
        foreach ($inactive7d as $user) {
            // Calculer pronostics ratés
            $missedWonPredictions = Prediction::where('status', 'won')
                ->where('created_at', '>', $user->last_login_at)
                ->count();
            
            $service->send($user, 'inactive_user', [
                'missed_predictions' => $missedWonPredictions,
            ]);
        }
        
        // Users inactifs 14j → email + offre spéciale
        $inactive14d = User::where('last_login_at', '<', now()->subDays(14))
            ->where('last_login_at', '>', now()->subDays(30))
            ->get();
        
        foreach ($inactive14d as $user) {
            $user->notify(new SpecialComebackOfferNotification($user));
        }
        
        // Users inactifs 30j+ → 1 dernière relance puis suppression liste
        $inactive30d = User::where('last_login_at', '<', now()->subDays(30))
            ->where('last_login_at', '>', now()->subDays(31))
            ->get();
        
        foreach ($inactive30d as $user) {
            $user->notify(new FinalComebackNotification($user));
        }
    }
}

// Schedule
$schedule->job(new ReengagementCampaignJob)->dailyAt('11:00');
```

### J4 (6h) - A/B Testing Notifications

```php
// migration ab_tests
Schema::create('ab_tests', function ($table) {
    $table->id();
    $table->string('name');
    $table->enum('type', ['notification', 'email', 'ui']);
    $table->json('variants'); // [{name: 'A', message: '...'}, {name: 'B', message: '...'}]
    $table->json('metrics'); // {sent: {A: 100, B: 100}, clicked: {A: 25, B: 32}}
    $table->boolean('is_active')->default(true);
    $table->timestamps();
});
```

```php
// app/Services/AB/AbTestService.php
class AbTestService
{
    public function getVariant(string $testName, User $user): array
    {
        $test = AbTest::where('name', $testName)->where('is_active', true)->first();
        if (!$test) return [];
        
        // Hash user_id pour répartition stable
        $bucket = crc32($user->id . $testName) % count($test->variants);
        return $test->variants[$bucket];
    }
    
    public function trackEvent(string $testName, User $user, string $event): void
    {
        $variant = $this->getVariant($testName, $user);
        if (empty($variant)) return;
        
        AbTest::where('name', $testName)->update([
            'metrics' => DB::raw("JSON_SET(metrics, '$.{$event}.{$variant['name']}', IFNULL(JSON_EXTRACT(metrics, '$.{$event}.{$variant['name']}'), 0) + 1)"),
        ]);
    }
}
```

**Exemple d'usage** :

```php
// Au moment d'envoyer une notif
$variant = $abTestService->getVariant('notification_combined_v1', $user);

$message = $variant['name'] === 'A' 
    ? "💎 Combiné Premium prêt !"
    : "🔥 Combiné gagnant disponible !";

// Tracking
$abTestService->trackEvent('notification_combined_v1', $user, 'sent');

// Quand user click
$abTestService->trackEvent('notification_combined_v1', $user, 'clicked');
```

### J5 (6h) - Notifications par Email (Sendgrid/SES)

```bash
composer require symfony/mailgun-mailer
# Ou SendGrid
composer require sendgrid/sendgrid
```

**Templates email essentiels** :

1. Welcome (J0 inscription)
2. Onboarding J+1 (tutoriel)
3. Onboarding J+3 (premier prono)
4. Subscription reminder J-3
5. Subscription expired
6. Comeback J+14 (offre)
7. Recap mensuel (stats personnelles)

```php
// app/Mail/MonthlyRecapMail.php
class MonthlyRecapMail extends Mailable
{
    public function __construct(public User $user, public array $stats) {}
    
    public function build(): self
    {
        return $this->subject("Ton mois sur FootApp - {$this->stats['won']} pronostics gagnants !")
            ->view('emails.monthly-recap')
            ->with([
                'user' => $this->user,
                'stats' => $this->stats,
            ]);
    }
}
```

### J6 (4h) - UI Préférences

```dart
// lib/presentation/screens/profile/notification_preferences_screen.dart
class NotificationPreferencesScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final prefs = ref.watch(notificationPreferencesProvider);
    
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: ListView(
        children: [
          // Channels
          _SectionHeader('Canaux'),
          _SwitchTile(
            title: 'Notifications push',
            value: prefs.pushEnabled,
            onChanged: (v) => ref.read(notifPrefsProvider.notifier).updatePush(v),
          ),
          _SwitchTile(title: 'Emails', value: prefs.emailEnabled, /*...*/),
          
          const Divider(),
          
          // Types
          _SectionHeader('Que veux-tu recevoir ?'),
          _SwitchTile(title: '🔥 Nouveaux pronostics', value: prefs.newPredictions),
          _SwitchTile(title: '💎 Combiné quotidien', value: prefs.combinedDaily),
          _SwitchTile(title: '📊 Résultats du jour', value: prefs.matchResults),
          _SwitchTile(title: '⏰ Rappels abonnement', value: prefs.subscriptionReminders),
          _SwitchTile(title: '🎁 Promotions et offres', value: prefs.promotions),
          
          const Divider(),
          
          // Filtres
          _SectionHeader('Filtres'),
          ListTile(
            title: const Text('Confiance minimum'),
            subtitle: Text('${prefs.minConfidenceScore}%'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showConfidenceSlider(context, ref, prefs.minConfidenceScore),
          ),
          ListTile(
            title: const Text('Championnats préférés'),
            subtitle: Text('${prefs.preferredCompetitions?.length ?? 0} sélectionnés'),
            onTap: () => context.push('/preferences/competitions'),
          ),
          
          const Divider(),
          
          // DnD
          _SectionHeader('Mode silencieux'),
          ListTile(
            title: const Text('Plage horaire'),
            subtitle: Text('${prefs.dndStart} - ${prefs.dndEnd}'),
            onTap: () => _showDndPicker(context, ref),
          ),
          
          // Frequency cap
          ListTile(
            title: const Text('Notifications par jour max'),
            subtitle: Text('${prefs.maxNotificationsPerDay}'),
          ),
        ],
      ),
    );
  }
}
```

### J7 (2h) - Analytics & Dashboard

```php
// Filament page : NotificationAnalytics
public function getStats(): array
{
    return [
        Stat::make('Notifications envoyées (24h)', NotificationLog::whereDate('sent_at', today())->count()),
        Stat::make('CTR moyen', $this->getCTR() . '%'),
        Stat::make('Désabonnements', User::where('push_enabled', false)->count()),
        Stat::make('A/B Tests actifs', AbTest::active()->count()),
    ];
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Préférences granulaires sauvegardées par user
- [ ] DnD respecté
- [ ] Frequency cap fonctionne (max 5 notifs/jour par défaut)
- [ ] Re-engagement automatique J+7, J+14, J+30
- [ ] A/B testing notifs avec tracking
- [ ] Email recap mensuel envoyé le 1er du mois
- [ ] UI Settings notifications complète
- [ ] Analytics dashboard CTR

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Préférences | 4h |
| Smart Service | 4h |
| Re-engagement | 4h |
| A/B Testing | 6h |
| Emails | 6h |
| UI | 4h |
| Analytics | 2h |
| **TOTAL** | **30h** |

---

## 🎯 KPIs

- CTR notifs push : **>15%** (vs 5% par défaut)
- Désabonnement : **<5%/mois**
- Re-engagement J+7 : **30%** des users reviennent
- Open rate emails : **>25%**

---

## 🔗 PROCHAINE ÉTAPE PHASE 3

✅ → `PHASE-3-SCALE/MODULE-ML-Avance.md`
