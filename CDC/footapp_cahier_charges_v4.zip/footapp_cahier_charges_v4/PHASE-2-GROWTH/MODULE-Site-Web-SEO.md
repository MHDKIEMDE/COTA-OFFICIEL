# 🌐 MODULE - Site Web SEO (Phase 2)

> **Phase** : 2 - Growth | **Durée** : 3 semaines (90h) | **Priorité** : 🟢 Acquisition gratuite
> **Prérequis** : MVP lancé

---

## 🎯 OBJECTIF

Site web vitrine + blog SEO pour acquisition organique :
- Site corporate (Next.js 14 + Tailwind)
- Blog avec articles optimisés SEO
- Landing pages par bookmaker/pays
- Comparateurs (cotes, bookmakers)
- Pages légales (CGU, Politique conf.)
- Intégration Google Analytics + Search Console

**Impact attendu** : 1 000-3 000 visiteurs/mois SEO en 6 mois → 30-90 inscriptions gratuites/mois.

---

## 🏗️ STACK

```
Next.js 14 (App Router) + Tailwind CSS
+ MDX (articles blog)
+ Vercel (hosting gratuit)
+ Plausible Analytics (privacy-friendly)
```

**Pourquoi Next.js** : SSR/SSG pour SEO optimal, gratuit sur Vercel, Markdown-friendly.

---

## 📂 STRUCTURE SITE

```
/                          → Landing principale
/pourquoi-footapp          → Argumentaire
/comment-ca-marche         → Tutoriel
/tarifs                    → Plans abo
/bookmakers                → Comparateur
  /betwinner               → Page dédiée
  /1xbet                   → Page dédiée
  /melbet                  → Page dédiée
/championnats              → Pages par compétition
  /premier-league
  /la-liga
  /serie-a
/blog                      → Articles SEO
  /comment-parier-football
  /strategies-pari-foot
  /pronostics-jour
/pays                      → Pages localisées
  /senegal
  /cote-ivoire
  /burkina-faso
/cgu
/politique-confidentialite
/contact
```

---

## ✍️ STRATÉGIE SEO

### Mots-clés cibles (Phase 2)

**Volume mensuel estimé Afrique francophone** :

| Mot-clé | Volume | Difficulté |
|---------|--------|------------|
| pronostic foot | 8 000 | Moyenne |
| pronostic football aujourd'hui | 5 000 | Moyenne |
| meilleur site pronostic foot | 3 000 | Élevée |
| pronostic foot gratuit | 4 000 | Moyenne |
| betwinner pronostic | 2 000 | Faible ✅ |
| 1xbet pronostic | 2 500 | Faible ✅ |
| application pronostic foot | 1 500 | Faible ✅ |
| pronostic Premier League | 6 000 | Élevée |
| pronostic Ligue 1 | 4 000 | Moyenne |

### Articles à produire (15 articles - 3 mois)

| Article | Mot-clé principal | Volume |
|---------|-------------------|--------|
| Comment parier au football : guide complet 2026 | comment parier football | 3 000 |
| Top 10 stratégies pari foot gagnantes | stratégies pari foot | 1 500 |
| Pronostics du jour - mis à jour quotidiennement | pronostic du jour | 5 000 |
| Comprendre les cotes bookmakers | comprendre cotes | 1 200 |
| Betwinner : avis et code promo 2026 | betwinner avis | 2 000 |
| 1xBet : guide d'inscription Afrique | 1xbet inscription | 1 800 |
| Wave / Orange Money pour parier en ligne | mobile money pari | 800 |
| Algorithme IA pari foot : ça marche vraiment ? | ia pari foot | 600 |
| ... |

### Format article SEO type

```markdown
# Comment parier au football : guide complet 2026

> Méta description : Découvre les meilleures stratégies pour parier au foot en 2026. Guide complet pour débutants : cotes, types de paris, gestion bankroll.

[Image hero]

## Sommaire
1. Comprendre les cotes
2. Types de paris populaires
3. Gestion de bankroll
4. Erreurs à éviter
5. Outils recommandés (FootApp ⭐)

## 1. Comprendre les cotes
...

## 5. Outils recommandés
[CTA FootApp avec screenshot]
```

---

## 🚀 IMPLÉMENTATION (3 SEMAINES)

### Semaine 1 - Setup Next.js + Pages principales (30h)

```bash
npx create-next-app@latest footapp-website --typescript --tailwind --app --src-dir
cd footapp-website
npm install gray-matter remark remark-html lucide-react
```

**Pages à créer en priorité** :
- Landing principale (avec CTA fort)
- Tarifs
- Comment ça marche
- CGU + Politique confidentialité

### Semaine 2 - Blog + SEO technique (30h)

- Setup MDX pour articles
- Sitemap.xml
- robots.txt
- Schema.org markup (Organization, BlogPosting)
- Open Graph + Twitter Cards
- Vercel deployment

### Semaine 3 - Contenu + Optimisations (30h)

- Rédiger 5 premiers articles
- Créer landing pages bookmakers
- Pages championnats
- Soumettre à Google Search Console
- Première campagne de backlinks

---

## 🔗 INTÉGRATION AVEC L'APP

### Bouton "Télécharger l'app"

Dans toutes les pages, CTA vers Play Store + téléchargement APK direct.

### API publique pour pronostics du jour

Endpoint public limité pour publier sur le site les **3 pronos du jour avec confiance < 70%** (les meilleurs restent dans l'app).

```php
// routes/api.php (public)
Route::get('/public/predictions/today', function () {
    return Prediction::with('match.homeTeam', 'match.awayTeam')
        ->whereDate('created_at', today())
        ->where('confidence_score', '<', 70)
        ->limit(3)
        ->get();
});
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Site déployé sur footapp.com (ou .africa)
- [ ] Lighthouse Score > 90 (Perf, SEO, A11y)
- [ ] 5 articles SEO publiés
- [ ] Sitemap soumis à Google Search Console
- [ ] Analytics installé (Plausible ou GA4)
- [ ] CGU + Politique en ligne
- [ ] Liens vers app/Play Store partout

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Setup Next.js + design | 30h |
| Blog + SEO technique | 30h |
| 5 articles + Pages bookmakers | 30h |
| **TOTAL** | **90h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-Multi-Langues.md`
