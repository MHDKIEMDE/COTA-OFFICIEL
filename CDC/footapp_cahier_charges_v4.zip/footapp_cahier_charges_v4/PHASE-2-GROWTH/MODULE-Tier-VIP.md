# 👑 MODULE - Tier VIP Premium

> **Phase** : 2 - Growth | **Durée** : 1 semaine (30h) | **Priorité** : 🔴 Revenus +30%
> **Prérequis** : MVP lancé, abonnements Mensuel & Trimestriel actifs

---

## 🎯 OBJECTIF

Créer un tier VIP haut de gamme à **15 000 FCFA/mois** pour les parieurs sérieux :
- ✅ Accès TOUS les pronostics (même < 50% confidence)
- ✅ Notifications **15 minutes avant** la sortie publique
- ✅ Combinés VIP exclusifs (haute cote x30+)
- ✅ Group WhatsApp privé avec analyses
- ✅ Stats avancées (xG, blessures, cotes en temps réel)
- ✅ Coaching mensuel inclus (1 session 30 min)
- ✅ Badge VIP visible dans l'app

**Cible** : 5% des premium = ~25 users payants à scale.
**Revenus additionnels** : 25 × 15 000 FCFA = **375 000 FCFA/mois (~570€)**.

---

## 📋 IMPLÉMENTATION

### J1 (4h) - Migration & Modèles

```php
// Migration vip_features
Schema::create('vip_predictions', function ($table) {
    $table->id();
    $table->foreignId('match_id')->constrained();
    $table->json('analysis_full'); // Analyse approfondie
    $table->json('xg_breakdown');
    $table->json('injuries_data');
    $table->json('odds_history'); // Évolution cotes
    $table->text('expert_commentary')->nullable();
    $table->timestamps();
});

Schema::create('vip_combineds', function ($table) {
    $table->id();
    $table->date('date');
    $table->json('matches');
    $table->decimal('total_odds', 8, 2); // x30+
    $table->decimal('confidence_avg', 5, 2);
    $table->enum('risk_level', ['safe', 'medium', 'high_risk']);
    $table->timestamps();
});

// Ajout colonne vip_expires_at sur users (déjà couvert par subscription_type='vip')
```

### J2 (4h) - Logique Premium VS VIP

```php
// app/Services/Subscription/SubscriptionService.php

public function getUserTier(User $user): string
{
    if (!$user->isPremiumActive()) return 'free';
    
    return match($user->subscription_type) {
        'vip' => 'vip',
        'monthly', 'quarterly', 'weekly', 'daily' => 'premium',
        default => 'free',
    };
}

// Middleware VIP
class EnsureVip
{
    public function handle($request, Closure $next)
    {
        if (app(SubscriptionService::class)->getUserTier($request->user()) !== 'vip') {
            return response()->json([
                'error' => 'VIP_REQUIRED',
                'message' => 'Cette fonctionnalité est réservée aux membres VIP',
                'upgrade_url' => '/subscription/vip',
            ], 403);
        }
        return $next($request);
    }
}
```

### J3 (4h) - Endpoints VIP

```php
// routes/api.php
Route::middleware(['auth:sanctum', 'vip'])->prefix('vip')->group(function () {
    Route::get('/predictions/all', [VipController::class, 'allPredictions']);
    Route::get('/combineds/today', [VipController::class, 'vipCombined']);
    Route::get('/predictions/{id}/full-analysis', [VipController::class, 'fullAnalysis']);
    Route::get('/whatsapp-link', [VipController::class, 'whatsappGroupLink']);
    Route::post('/coaching/request', [VipController::class, 'requestCoaching']);
});
```

```php
class VipController extends Controller
{
    public function allPredictions()
    {
        // Inclut MÊME les pronostics < 50% (rejetés pour les autres)
        return Prediction::with('match.homeTeam', 'match.awayTeam')
            ->whereDate('created_at', today())
            ->orderByDesc('confidence_score')
            ->get();
    }
    
    public function vipCombined()
    {
        return VipCombined::whereDate('date', today())->first();
    }
    
    public function fullAnalysis(int $predictionId)
    {
        $prediction = Prediction::findOrFail($predictionId);
        $vipData = VipPrediction::where('match_id', $prediction->match_id)->first();
        
        return [
            'prediction' => $prediction,
            'vip_data' => $vipData,
            'historical_h2h' => $this->getExtensiveH2H($prediction->match),
            'odds_evolution' => $this->getOddsEvolution($prediction->match),
        ];
    }
    
    public function whatsappGroupLink()
    {
        // Lien rotaté chaque mois pour sécurité
        return [
            'link' => config('services.whatsapp.vip_group_link'),
            'expires_at' => now()->endOfMonth(),
        ];
    }
}
```

### J4 (4h) - Combinés VIP haute cote

```php
// app/Services/Algorithm/VipCombinedGenerator.php
class VipCombinedGenerator
{
    public function generateForToday(): ?VipCombined
    {
        // Critères VIP : cotes plus hautes acceptées, mais confiance toujours >= 60%
        $eligible = Prediction::with('match')
            ->whereDate('created_at', today())
            ->where('confidence_score', '>=', 60)
            ->where('odds', '>=', 1.80)
            ->where('odds', '<=', 5.00)
            ->orderByDesc('confidence_score')
            ->get();
        
        if ($eligible->count() < 6) return null;
        
        // Sélectionner 6-8 matchs pour viser cote x30+
        $selected = $this->pickBestCombination($eligible, targetOdds: 30);
        
        $totalOdds = $selected->reduce(fn($acc, $p) => $acc * $p->odds, 1);
        
        return VipCombined::create([
            'date' => today(),
            'matches' => $selected->pluck('id')->toArray(),
            'total_odds' => $totalOdds,
            'confidence_avg' => $selected->avg('confidence_score'),
            'risk_level' => $totalOdds > 50 ? 'high_risk' : ($totalOdds > 30 ? 'medium' : 'safe'),
        ]);
    }
}
```

### J5 (6h) - Notifications VIP en avance

```php
// app/Jobs/SendVipNotificationsJob.php
class SendVipNotificationsJob implements ShouldQueue
{
    public function handle()
    {
        // Envoyé à 07h45 (15 min avant la sortie publique 08h00)
        $todayPredictions = Prediction::whereDate('created_at', today())
            ->where('confidence_score', '>=', 70)
            ->get();
        
        if ($todayPredictions->isEmpty()) return;
        
        $vipUsers = User::where('subscription_type', 'vip')
            ->where('subscription_expires_at', '>', now())
            ->get();
        
        foreach ($vipUsers as $user) {
            $user->notify(new VipEarlyAccessNotification($todayPredictions));
        }
    }
}

// Schedule
$schedule->job(new SendVipNotificationsJob)->dailyAt('07:45');
$schedule->job(new SendPremiumNotificationsJob)->dailyAt('08:00');
```

### J6 (4h) - Coaching System (basique)

```php
Schema::create('coaching_sessions', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->datetime('scheduled_at');
    $table->integer('duration_minutes')->default(30);
    $table->enum('status', ['requested', 'confirmed', 'completed', 'cancelled']);
    $table->text('notes')->nullable();
    $table->string('meet_link')->nullable(); // Google Meet / WhatsApp
    $table->timestamps();
});
```

```php
public function requestCoaching(Request $request)
{
    $request->validate([
        'preferred_date' => 'required|date|after:tomorrow',
        'topic' => 'required|string|max:500',
    ]);
    
    // 1 session/mois inclus dans VIP
    $thisMonth = CoachingSession::where('user_id', $request->user()->id)
        ->whereMonth('scheduled_at', now()->month)
        ->count();
    
    if ($thisMonth >= 1) {
        return response()->json([
            'error' => 'MONTHLY_LIMIT_REACHED',
            'message' => 'Tu as déjà 1 session ce mois-ci. Prochaine: ' . now()->addMonth()->startOfMonth()->format('d/m'),
        ], 422);
    }
    
    $session = CoachingSession::create([
        'user_id' => $request->user()->id,
        'scheduled_at' => $request->preferred_date,
        'status' => 'requested',
        'notes' => "Topic: {$request->topic}",
    ]);
    
    // Notifier admin (par email)
    Notification::route('mail', 'coaching@mhdservice.com')
        ->notify(new NewCoachingRequestNotification($session));
    
    return response()->json(['success' => true, 'session' => $session]);
}
```

### J7 (4h) - UI Mobile VIP

**Écran VIP Dashboard** :

```dart
class VipDashboardScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    
    if (user.subscriptionType != 'vip') {
      return const VipUpsellScreen();
    }
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('👑 Espace VIP'),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.premium, AppColors.premiumDark],
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header VIP
          _VipHeaderCard(user: user),
          
          const SizedBox(height: 24),
          
          // Combiné VIP du jour
          const _VipDailyCombined(),
          
          const SizedBox(height: 24),
          
          // Group WhatsApp
          _WhatsAppGroupCard(),
          
          const SizedBox(height: 24),
          
          // Coaching
          _CoachingCard(),
          
          const SizedBox(height: 24),
          
          // Tous les pronostics (full access)
          const _AllPredictionsList(),
        ],
      ),
    );
  }
}

class _VipUpsellScreen extends StatelessWidget {
  // Page de présentation des avantages VIP
  // CTA : "Devenir VIP - 15 000 FCFA/mois"
}
```

**Badge VIP** dans les autres écrans :

```dart
// Visible partout pour les VIP
class VipBadge extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isVip = ref.watch(currentUserProvider).subscriptionType == 'vip';
    if (!isVip) return const SizedBox.shrink();
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppColors.premium, AppColors.premiumDark]),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.star, size: 12, color: Colors.black),
          SizedBox(width: 4),
          Text('VIP', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.black)),
        ],
      ),
    );
  }
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Tier VIP achetable (15 000 FCFA/mois)
- [ ] Endpoints VIP protégés par middleware
- [ ] Combiné VIP haute cote généré quotidiennement
- [ ] Notifications VIP envoyées 15 min avant les autres
- [ ] Lien WhatsApp Group accessible aux VIP
- [ ] Système coaching : 1 session/mois max
- [ ] Badge VIP visible dans l'app
- [ ] Écran upsell VIP convaincant pour non-VIP

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Migration + Models | 4h |
| Logique tier + middleware | 4h |
| Endpoints VIP | 4h |
| Combinés VIP | 4h |
| Notifications avance | 4h |
| Coaching | 4h |
| UI Mobile VIP | 6h |
| **TOTAL** | **30h** |

---

## 🎯 KPIs VIP

- Conversion premium → VIP : **5-10%** (cible)
- Churn VIP : **< 20%/mois** (low si valeur perçue)
- NPS VIP : **> 60** (clients premium = ambassadeurs)

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-Coaching-Premium.md`
