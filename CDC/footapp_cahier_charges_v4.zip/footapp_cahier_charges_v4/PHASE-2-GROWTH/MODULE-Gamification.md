# 🎮 MODULE - Gamification (Phase 2)

> **Phase** : 2 - Growth | **Durée** : 2 semaines (60h) | **Priorité** : 🟢 RÉTENTION +30%
> **Prérequis** : Phase 1 lancée, 100+ users actifs

---

## 🎯 OBJECTIF DU MODULE

Augmenter la rétention via la gamification :
- ✅ Roue de la chance quotidienne (login bonus)
- ✅ Challenges hebdomadaires
- ✅ Système de niveaux et badges
- ✅ Concours mensuel 50 000 FCFA
- ✅ Cashback 10% pour parrainages

**Impact attendu** : +30% de rétention, +50% de fréquence d'usage.

---

## 🎰 1. ROUE DE LA CHANCE QUOTIDIENNE

### Concept

User se connecte quotidiennement → tour de roue gratuit → gagne :
- 1 pronostic premium gratuit (40%)
- Code promo bookmaker (25%)
- 10% off prochain abonnement (15%)
- 1 jour premium gratuit (10%)
- 1 semaine premium gratuit (8%)
- 1 mois premium gratuit (2%)

### Implémentation

**Backend** :

```php
// app/Models/DailySpin.php
class DailySpin extends Model
{
    protected $fillable = ['user_id', 'reward_type', 'reward_value', 'spun_at'];
    
    public static function canSpin(User $user): bool
    {
        $lastSpin = self::where('user_id', $user->id)->latest('spun_at')->first();
        if (!$lastSpin) return true;
        return $lastSpin->spun_at->isYesterday() || $lastSpin->spun_at->isBefore(now()->startOfDay());
    }
}

// app/Services/Gamification/DailySpinService.php
class DailySpinService
{
    private array $rewards = [
        ['type' => 'free_premium_pred', 'value' => 1, 'weight' => 40],
        ['type' => 'promo_code', 'value' => 'WHEEL10', 'weight' => 25],
        ['type' => 'subscription_discount', 'value' => 10, 'weight' => 15],
        ['type' => 'premium_day', 'value' => 1, 'weight' => 10],
        ['type' => 'premium_week', 'value' => 7, 'weight' => 8],
        ['type' => 'premium_month', 'value' => 30, 'weight' => 2],
    ];
    
    public function spin(User $user): array
    {
        if (!DailySpin::canSpin($user)) {
            throw new \Exception('Tu as déjà tourné aujourd\'hui');
        }
        
        $reward = $this->pickRewardWeighted();
        
        DailySpin::create([
            'user_id' => $user->id,
            'reward_type' => $reward['type'],
            'reward_value' => $reward['value'],
            'spun_at' => now(),
        ]);
        
        $this->grantReward($user, $reward);
        
        return $reward;
    }
    
    private function pickRewardWeighted(): array
    {
        $total = array_sum(array_column($this->rewards, 'weight'));
        $rand = rand(1, $total);
        
        $cumulative = 0;
        foreach ($this->rewards as $reward) {
            $cumulative += $reward['weight'];
            if ($rand <= $cumulative) return $reward;
        }
        
        return end($this->rewards);
    }
}
```

**Mobile** : utiliser le package `flutter_fortune_wheel`.

```dart
// lib/presentation/screens/gamification/daily_spin_screen.dart
import 'package:flutter_fortune_wheel/flutter_fortune_wheel.dart';

class DailySpinScreen extends StatefulWidget {
  // ... animation roue + appel API
  // Confetti à la victoire
}
```

---

## 🏆 2. CHALLENGES HEBDOMADAIRES

### Concept

3 challenges/semaine avec récompenses :
- "Consulte 10 pronostics" → 1 jour premium
- "Parle à un ami" (parrainage) → 3 jours premium
- "Atteins 5 jours de connexion consécutifs" → 7 jours premium

### Implémentation

```php
// migration challenges
Schema::create('challenges', function ($table) {
    $table->id();
    $table->string('name');
    $table->string('description');
    $table->enum('type', ['daily_login', 'predictions_view', 'referral', 'subscription']);
    $table->integer('target');
    $table->json('reward'); // {type: 'premium_days', value: 7}
    $table->date('start_date');
    $table->date('end_date');
    $table->boolean('is_active')->default(true);
});

// Pivot user_challenges
Schema::create('user_challenges', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('challenge_id')->constrained();
    $table->integer('progress')->default(0);
    $table->boolean('completed')->default(false);
    $table->timestamp('completed_at')->nullable();
    $table->boolean('reward_claimed')->default(false);
});
```

**Job pour update progress** :

```php
// Listener sur événements
class UpdateChallengeProgressListener
{
    public function handle(object $event): void
    {
        match (true) {
            $event instanceof PredictionViewed => $this->incrementProgress($event->user, 'predictions_view'),
            $event instanceof UserReferred => $this->incrementProgress($event->referrer, 'referral'),
            $event instanceof UserLoggedIn => $this->updateLoginStreak($event->user),
        };
    }
}
```

**UI Mobile** : carte challenges avec barre de progression.

---

## 🎖️ 3. SYSTÈME DE NIVEAUX & BADGES

### Niveaux (1 → 50)

| Niveau | XP requis | Titre | Avantage |
|--------|-----------|-------|----------|
| 1-5 | 0-500 | 🥉 Débutant | - |
| 6-15 | 500-3000 | 🥈 Habitué | -5% sur abos |
| 16-30 | 3000-15000 | 🥇 Expert | -10% + early access |
| 31-50 | 15000-50000 | 💎 Légende | -15% + badge VIP |

### Sources d'XP

- Login quotidien : +10 XP
- Consulter pronostic : +5 XP
- Premier pari (via auto-fill) : +50 XP
- Parrainage : +200 XP
- Achat abonnement : +500 XP
- Challenge complété : +100-300 XP

### Badges (collectibles)

| Badge | Condition |
|-------|-----------|
| 🌟 Premier pas | 1ère connexion |
| 🎯 Précis | 10 pronos consultés |
| 💰 Investisseur | 1er abonnement |
| 🤝 Recruteur | 1er parrainage |
| 👑 VIP | Tier VIP souscrit |
| 🔥 Streak Master | 30j connexions consécutives |
| 🏆 Legend | Niveau 50 atteint |

```php
// app/Services/Gamification/XpService.php
class XpService
{
    public function award(User $user, string $action, int $amount): void
    {
        $user->increment('xp', $amount);
        
        // Check level up
        $newLevel = $this->calculateLevel($user->xp);
        if ($newLevel > $user->level) {
            $user->update(['level' => $newLevel]);
            $user->notify(new LevelUpNotification($newLevel));
        }
        
        // Check badges
        $this->checkBadges($user);
    }
    
    private function calculateLevel(int $xp): int
    {
        // Formule progressive : XP requis = 100 * level^1.5
        for ($level = 1; $level <= 50; $level++) {
            $required = (int) (100 * pow($level, 1.5));
            if ($xp < $required) return $level - 1;
        }
        return 50;
    }
}
```

---

## 🎁 4. CONCOURS MENSUEL 50 000 FCFA

### Concept

Chaque mois, 1 utilisateur gagne **50 000 FCFA cash** parmi ceux qui ont participé.

### Conditions de participation (1 ticket par action)

- Connexion quotidienne du mois : +1 ticket / jour
- Achat abonnement (n'importe lequel) : +20 tickets
- Parrainage actif : +10 tickets / filleul
- Tour de roue quotidien : +1 ticket
- Challenge complété : +5 tickets

### Tirage

- 1er du mois suivant à 12h
- Live sur Facebook/Instagram (transparence)
- Annonce dans l'app + email + push

### Implémentation

```php
// migration contests + tickets
Schema::create('contests', function ($table) {
    $table->id();
    $table->string('month'); // '2026-05'
    $table->decimal('prize_amount', 10, 2);
    $table->string('currency')->default('XOF');
    $table->foreignId('winner_user_id')->nullable()->constrained('users');
    $table->timestamp('drawn_at')->nullable();
    $table->boolean('is_drawn')->default(false);
});

Schema::create('contest_tickets', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('contest_id')->constrained();
    $table->string('source'); // 'login', 'subscription', etc.
    $table->timestamp('earned_at');
});

// Job tirage automatique
class DrawMonthlyContestJob implements ShouldQueue
{
    public function handle()
    {
        $contest = Contest::where('month', now()->subMonth()->format('Y-m'))
            ->where('is_drawn', false)
            ->first();
        
        if (!$contest) return;
        
        // Tirage pondéré par nombre de tickets
        $tickets = ContestTicket::where('contest_id', $contest->id)
            ->select('user_id', \DB::raw('COUNT(*) as ticket_count'))
            ->groupBy('user_id')
            ->get();
        
        $weighted = collect();
        foreach ($tickets as $t) {
            for ($i = 0; $i < $t->ticket_count; $i++) {
                $weighted->push($t->user_id);
            }
        }
        
        $winnerId = $weighted->random();
        
        $contest->update([
            'winner_user_id' => $winnerId,
            'drawn_at' => now(),
            'is_drawn' => true,
        ]);
        
        // Notifier gagnant + tous les users
        User::find($winnerId)->notify(new ContestWonNotification($contest));
    }
}
```

---

## 💸 5. CASHBACK PARRAINAGE 10%

### Concept

Quand un filleul achète un abonnement, le parrain reçoit **10% en crédit FootApp** utilisable sur son prochain abonnement.

### Calcul

| Achat filleul | Cashback parrain |
|---------------|------------------|
| Hebdo (2500 FCFA) | 250 FCFA crédit |
| Mensuel (8000 FCFA) | 800 FCFA crédit |
| Trimestriel (20 000 FCFA) | 2 000 FCFA crédit |
| VIP (15 000 FCFA) | 1 500 FCFA crédit |

### Implémentation

```php
// migration user_credits
Schema::create('user_credits', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->decimal('amount', 10, 2);
    $table->string('currency')->default('XOF');
    $table->enum('source', ['cashback_referral', 'compensation', 'gift']);
    $table->foreignId('source_payment_id')->nullable();
    $table->boolean('is_used')->default(false);
    $table->timestamp('used_at')->nullable();
    $table->timestamp('expires_at')->nullable(); // 6 mois
});

// Listener sur paiement
class GrantReferralCashbackListener
{
    public function handle(SubscriptionActivated $event): void
    {
        $user = $event->subscription->user;
        if (!$user->referrer) return;
        
        // Cashback 10%
        $cashback = $event->subscription->amount * 0.10;
        
        UserCredit::create([
            'user_id' => $user->referrer->id,
            'amount' => $cashback,
            'source' => 'cashback_referral',
            'source_payment_id' => $event->subscription->payment_id,
            'expires_at' => now()->addMonths(6),
        ]);
        
        $user->referrer->notify(new CashbackEarnedNotification($cashback));
    }
}
```

**Application au checkout** : déduire le crédit disponible.

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Roue de la chance fonctionne avec animation fluide
- [ ] Cooldown 24h entre 2 spins respecté
- [ ] Récompenses correctement attribuées
- [ ] 3 challenges hebdo générés automatiquement
- [ ] Progression challenges trackée en temps réel
- [ ] Système XP/niveaux fonctionnel
- [ ] Badges débloqués automatiquement
- [ ] Concours mensuel : tickets attribués correctement
- [ ] Tirage automatique le 1er du mois
- [ ] Cashback parrainage 10% appliqué

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Roue de la chance | 12h |
| Challenges | 12h |
| Niveaux & Badges | 12h |
| Concours mensuel | 12h |
| Cashback | 8h |
| Tests + UI polish | 4h |
| **TOTAL** | **60h** |

---

## 🎯 KPIs À SURVEILLER

- DAU avant/après gamification
- Sessions/user/jour
- Taux de spin quotidien (cible >70%)
- Challenges complétés (cible >50%)
- Parrainages mensuels (vs avant cashback)

---

## 🔗 PROCHAINE ÉTAPE

✅ Module Gamification → `MODULE-Site-Web-SEO.md`
