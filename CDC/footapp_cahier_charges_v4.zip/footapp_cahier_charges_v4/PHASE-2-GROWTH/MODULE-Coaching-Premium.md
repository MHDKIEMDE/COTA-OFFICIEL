# 🎓 MODULE - Coaching Premium (Sessions 1-on-1)

> **Phase** : 2 - Growth | **Durée** : 2 semaines (60h) | **Priorité** : 🟢 High-ticket
> **Prérequis** : Tier VIP lancé, équipe d'au moins 1 expert disponible

---

## 🎯 OBJECTIF

Service de coaching personnalisé pour parieurs sérieux :
- ✅ Sessions 1-on-1 (30 min) à **5 000 FCFA**
- ✅ Pack 4 sessions/mois à **15 000 FCFA** (économie 25%)
- ✅ Audit bankroll personnalisé
- ✅ Stratégie de parieurs adaptée à chaque user
- ✅ Suivi de progression
- ✅ Inclus pour Tier VIP (1/mois)

**Revenu cible** : 30 sessions/mois × 5 000 = **150 000 FCFA (~230€)**.

---

## 📋 IMPLÉMENTATION

### Concept et Format

**Format de session** :

1. **Pré-session** (questionnaire envoyé par email) :
   - Bankroll actuelle
   - Historique paris (combien gagné/perdu)
   - Sports/championnats préférés
   - Objectifs (gagner régulièrement, occasionnel, etc.)

2. **Session 30 min** (Google Meet ou WhatsApp Video) :
   - 5 min : Tour de table objectifs
   - 15 min : Audit historique + stratégie
   - 10 min : Plan d'action 1 mois

3. **Post-session** :
   - Récap PDF envoyé par email
   - Group WhatsApp privé pour suivi
   - 1 follow-up 2 semaines plus tard

### J1-J3 (12h) - Modèles et Booking

```php
// Migrations
Schema::create('coaching_packages', function ($table) {
    $table->id();
    $table->string('name');
    $table->integer('sessions_count');
    $table->decimal('price_fcfa', 10, 2);
    $table->decimal('price_eur', 8, 2);
    $table->integer('validity_days')->default(30);
    $table->boolean('is_active')->default(true);
});

Schema::create('coaching_sessions', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('coach_id')->constrained('users');
    $table->foreignId('package_id')->nullable()->constrained('coaching_packages');
    $table->datetime('scheduled_at');
    $table->integer('duration_minutes')->default(30);
    $table->enum('status', ['requested', 'confirmed', 'completed', 'cancelled', 'no_show']);
    $table->string('meeting_link')->nullable();
    $table->text('pre_session_notes')->nullable();
    $table->text('post_session_notes')->nullable();
    $table->string('recap_pdf_path')->nullable();
    $table->integer('rating')->nullable(); // 1-5
    $table->text('user_feedback')->nullable();
    $table->timestamps();
});

Schema::create('coaching_credits', function ($table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->foreignId('package_id')->constrained();
    $table->foreignId('payment_id')->nullable()->constrained();
    $table->integer('credits_total');
    $table->integer('credits_used')->default(0);
    $table->timestamp('expires_at');
});
```

```php
// Seeder packages
DB::table('coaching_packages')->insert([
    [
        'name' => 'Session unique',
        'sessions_count' => 1,
        'price_fcfa' => 5000,
        'price_eur' => 7.50,
        'validity_days' => 14,
    ],
    [
        'name' => 'Pack 4 sessions',
        'sessions_count' => 4,
        'price_fcfa' => 15000,
        'price_eur' => 22.50,
        'validity_days' => 30,
    ],
    [
        'name' => 'Pack 12 sessions (3 mois)',
        'sessions_count' => 12,
        'price_fcfa' => 40000,
        'price_eur' => 60,
        'validity_days' => 90,
    ],
]);
```

### J4-J5 (8h) - Service Coaching

```php
// app/Services/Coaching/CoachingService.php
class CoachingService
{
    public function bookSession(User $user, array $data): CoachingSession
    {
        // Vérifier crédits disponibles
        $credits = CoachingCredit::where('user_id', $user->id)
            ->where('expires_at', '>', now())
            ->whereRaw('credits_used < credits_total')
            ->orderBy('expires_at')
            ->first();
        
        if (!$credits) {
            throw new \Exception('Aucun crédit coaching disponible. Achète un pack d\'abord.');
        }
        
        // Vérifier disponibilité créneau
        $existing = CoachingSession::where('coach_id', $data['coach_id'])
            ->where('scheduled_at', $data['scheduled_at'])
            ->whereIn('status', ['requested', 'confirmed'])
            ->exists();
        
        if ($existing) {
            throw new \Exception('Créneau non disponible');
        }
        
        $session = CoachingSession::create([
            'user_id' => $user->id,
            'coach_id' => $data['coach_id'],
            'package_id' => $credits->package_id,
            'scheduled_at' => $data['scheduled_at'],
            'status' => 'requested',
            'pre_session_notes' => $data['pre_session_notes'] ?? null,
        ]);
        
        // Décrémenter crédit (réservé)
        $credits->increment('credits_used');
        
        // Notifier coach + user
        $coach = User::find($data['coach_id']);
        $coach->notify(new NewCoachingBookingNotification($session));
        $user->notify(new CoachingBookingConfirmationNotification($session));
        
        return $session;
    }
    
    public function getAvailableSlots(int $coachId, string $date): array
    {
        // Slots disponibles : 9h-12h et 14h-18h, 30 min chacun
        $allSlots = [];
        $startTime = 9;
        $endTime = 18;
        
        for ($h = $startTime; $h < $endTime; $h++) {
            if ($h == 12) continue; // pause déjeuner
            $allSlots[] = sprintf('%02d:00', $h);
            $allSlots[] = sprintf('%02d:30', $h);
        }
        
        // Soustraire les slots déjà bookés
        $booked = CoachingSession::where('coach_id', $coachId)
            ->whereDate('scheduled_at', $date)
            ->whereIn('status', ['requested', 'confirmed'])
            ->get()
            ->map(fn($s) => $s->scheduled_at->format('H:i'))
            ->toArray();
        
        return array_values(array_diff($allSlots, $booked));
    }
}
```

### J6 (4h) - Génération PDF Recap

```bash
composer require barryvdh/laravel-dompdf
```

```php
// app/Services/Coaching/RecapPdfGenerator.php
class RecapPdfGenerator
{
    public function generate(CoachingSession $session): string
    {
        $pdf = Pdf::loadView('coaching.recap', [
            'session' => $session,
            'user' => $session->user,
            'coach' => $session->coach,
            'recommendations' => $this->getRecommendations($session),
        ]);
        
        $filename = "coaching_recap_{$session->id}.pdf";
        $path = "coaching_recaps/{$filename}";
        
        Storage::put("public/{$path}", $pdf->output());
        
        $session->update(['recap_pdf_path' => $path]);
        
        // Envoyer par email
        $session->user->notify(new CoachingRecapNotification($session, $path));
        
        return $path;
    }
}
```

```blade
{{-- resources/views/coaching/recap.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Récap Session Coaching - FootApp</title>
    <style>
        body { font-family: 'Helvetica', sans-serif; }
        .header { background: linear-gradient(135deg, #00BCD4, #0097A7); color: white; padding: 30px; }
        .section { margin: 20px 0; }
        .recommendation { background: #f5f5f5; padding: 15px; margin: 10px 0; border-left: 4px solid #00BCD4; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎓 Récap de ta session FootApp Coaching</h1>
        <p>Session du {{ $session->scheduled_at->format('d/m/Y à H:i') }}</p>
    </div>
    
    <div class="section">
        <h2>👤 Profil</h2>
        <p>Coach: {{ $coach->name }}</p>
        <p>Durée: {{ $session->duration_minutes }} minutes</p>
    </div>
    
    <div class="section">
        <h2>📝 Sujets abordés</h2>
        <p>{{ $session->post_session_notes }}</p>
    </div>
    
    <div class="section">
        <h2>🎯 Recommandations personnalisées</h2>
        @foreach($recommendations as $reco)
            <div class="recommendation">
                <h4>{{ $reco['title'] }}</h4>
                <p>{{ $reco['description'] }}</p>
            </div>
        @endforeach
    </div>
    
    <div class="section">
        <h2>📅 Prochaine étape</h2>
        <p>Follow-up dans 2 semaines pour mesurer les progrès.</p>
        <p>En attendant, suis tes paris dans l'app et applique les recommandations.</p>
    </div>
</body>
</html>
```

### J7-J8 (8h) - UI Mobile Booking

```dart
// lib/presentation/screens/coaching/coaching_home_screen.dart
class CoachingHomeScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final credits = ref.watch(coachingCreditsProvider);
    
    return Scaffold(
      appBar: AppBar(title: const Text('🎓 Coaching')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header
          _CoachingHeader(),
          
          const SizedBox(height: 24),
          
          // Crédits dispo
          credits.when(
            data: (c) => _CreditsCard(credits: c),
            loading: () => const ShimmerLoading(height: 100),
            error: (e, _) => const ErrorCard(),
          ),
          
          const SizedBox(height: 24),
          
          // Packages disponibles
          const Text('Choisis ton pack', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          
          _PackageCard(
            name: 'Session unique',
            price: 5000,
            description: 'Idéal pour découvrir',
            sessions: 1,
          ),
          _PackageCard(
            name: 'Pack 4 sessions',
            price: 15000,
            description: 'Suivi mensuel',
            sessions: 4,
            badge: '⭐ Populaire',
            discount: '-25%',
          ),
          _PackageCard(
            name: 'Pack 12 sessions',
            price: 40000,
            description: 'Transformation 3 mois',
            sessions: 12,
            badge: '🔥 Meilleure offre',
            discount: '-33%',
          ),
          
          const SizedBox(height: 24),
          
          // Mes sessions
          const Text('Mes sessions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const _MySessionsList(),
          
          // Si VIP
          if (ref.watch(currentUserProvider).subscriptionType == 'vip')
            const _VipFreeCoachingNote(),
        ],
      ),
    );
  }
}

class _BookingScreen extends ConsumerStatefulWidget {
  // Calendrier avec créneaux disponibles
  // Sélection coach (si plusieurs)
  // Pré-session questionnaire
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] 3 packages coaching achetables
- [ ] Système de crédits fonctionnel
- [ ] Booking calendrier avec créneaux dispo
- [ ] Notification automatique au coach
- [ ] Génération PDF recap après session
- [ ] Pré-session questionnaire envoyé par email
- [ ] Follow-up automatique J+14
- [ ] VIP : 1 session gratuite/mois fonctionne
- [ ] Rating après session

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Migrations + Seeders | 4h |
| Service Coaching | 8h |
| Booking system | 8h |
| PDF Generation | 4h |
| UI Mobile | 12h |
| Notifications + Tests | 8h |
| **TOTAL** | **44h** |

> Note : 2 sem si solo, 1.5 sem si freelance assistant

---

## 🎯 STRATÉGIE COACHING (Business)

### Recrutement coachs

- **Phase 1** : toi-même (gérable jusqu'à 30 sessions/mois)
- **Phase 2** : 1 freelance ex-bookmaker / parieur pro
- **Phase 3** : 3-5 coachs (équipe)

### Pricing testing

- A/B test : 5000 vs 7500 FCFA
- Pack 4 sessions : essayer 12000 / 15000 / 18000

### Funnel

1. Free user → "Découvre nos pronostics"
2. Premium user → "Améliore tes paris avec un coaching personnalisé"
3. VIP user → "1 coaching gratuit/mois inclus"

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-Notifications-Avancees.md`
