# 🌍 MODULE - Multi-Langues (FR/EN/AR)

> **Phase** : 2 - Growth | **Durée** : 1 semaine (30h) | **Priorité** : 🟢 Expansion
> **Prérequis** : MVP stable, expansion Maghreb planifiée

---

## 🎯 OBJECTIF

Internationaliser FootApp pour ouvrir Maghreb (Arabe) et Europe/International (Anglais) :
- ✅ Backend Laravel multi-langues
- ✅ Mobile Flutter avec ARB files
- ✅ Site web localisé
- ✅ Détection automatique de la langue
- ✅ Switch manuel dans Settings
- ✅ Support RTL (Right-to-Left) pour l'Arabe

**Marchés ouverts** : 🇲🇦 Maroc, 🇩🇿 Algérie, 🇹🇳 Tunisie, 🇪🇬 Égypte, 🇬🇧 UK, 🇺🇸 USA.

---

## 📋 IMPLÉMENTATION

### J1-J2 (12h) - Backend Laravel i18n

```bash
# Structure
lang/
├── fr/
│   ├── auth.php
│   ├── messages.php
│   ├── notifications.php
│   └── validation.php
├── en/
│   └── ...
└── ar/
    └── ...
```

**Configuration middleware** :

```php
// app/Http/Middleware/SetLocale.php
class SetLocale
{
    public function handle(Request $request, Closure $next)
    {
        $locale = $request->user()?->language 
            ?? $request->header('Accept-Language', 'fr');
        
        // Whitelist
        $supported = ['fr', 'en', 'ar'];
        $locale = in_array(substr($locale, 0, 2), $supported) 
            ? substr($locale, 0, 2) 
            : 'fr';
        
        app()->setLocale($locale);
        
        return $next($request);
    }
}

// bootstrap/app.php
->withMiddleware(function (Middleware $middleware) {
    $middleware->api(append: [SetLocale::class]);
})
```

**Endpoint pour changer langue** :

```php
// PATCH /api/v1/users/language
Route::patch('/users/language', function (Request $request) {
    $request->validate(['language' => 'required|in:fr,en,ar']);
    $request->user()->update(['language' => $request->language]);
    return response()->json(['success' => true]);
});
```

### J3 (4h) - Notifications multilingues

```php
class PredictionNotification extends Notification
{
    public function toFcm($notifiable)
    {
        $locale = $notifiable->language ?? 'fr';
        
        return [
            'title' => __('notifications.new_prediction.title', [], $locale),
            'body' => __('notifications.new_prediction.body', [
                'count' => $this->count,
            ], $locale),
        ];
    }
}
```

```php
// lang/fr/notifications.php
return [
    'new_prediction' => [
        'title' => '🔥 Nouveaux pronostics !',
        'body' => ':count nouveaux pronos disponibles',
    ],
];

// lang/en/notifications.php
return [
    'new_prediction' => [
        'title' => '🔥 New predictions!',
        'body' => ':count new predictions available',
    ],
];

// lang/ar/notifications.php
return [
    'new_prediction' => [
        'title' => '🔥 توقعات جديدة!',
        'body' => ':count توقعات جديدة متاحة',
    ],
];
```

### J4-J5 (12h) - Flutter Mobile i18n

```yaml
# pubspec.yaml
dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter
  intl: ^0.19.0
  
flutter:
  generate: true
```

```yaml
# l10n.yaml (à la racine)
arb-dir: lib/l10n
template-arb-file: app_fr.arb
output-localization-file: app_localizations.dart
```

**Fichiers ARB** :

```json
// lib/l10n/app_fr.arb
{
  "@@locale": "fr",
  "appTitle": "FootApp",
  "loginTitle": "Bienvenue 👋",
  "loginSubtitle": "Connecte-toi pour accéder aux pronostics",
  "phoneHint": "77 123 45 67",
  "sendOtpButton": "Recevoir le code",
  "loginWithFacebook": "Continuer avec Facebook",
  "predictionsToday": "Pronostics du jour",
  "confidenceLevel": "Confiance",
  "betType": "Pari",
  "odds": "Cote",
  "becomePremium": "Devenir Premium",
  "subscriptionExpiresIn": "{days, plural, =0{Expire aujourd'hui} =1{Expire demain} other{Expire dans {days} jours}}",
  "@subscriptionExpiresIn": {
    "placeholders": {
      "days": {"type": "int"}
    }
  }
}

// lib/l10n/app_en.arb
{
  "@@locale": "en",
  "appTitle": "FootApp",
  "loginTitle": "Welcome 👋",
  "loginSubtitle": "Login to access predictions",
  "phoneHint": "771 234 567",
  "sendOtpButton": "Receive code",
  "loginWithFacebook": "Continue with Facebook",
  "predictionsToday": "Today's predictions",
  "confidenceLevel": "Confidence",
  "betType": "Bet",
  "odds": "Odds",
  "becomePremium": "Go Premium",
  "subscriptionExpiresIn": "{days, plural, =0{Expires today} =1{Expires tomorrow} other{Expires in {days} days}}"
}

// lib/l10n/app_ar.arb
{
  "@@locale": "ar",
  "appTitle": "فوت آب",
  "loginTitle": "أهلاً بك 👋",
  "loginSubtitle": "سجّل الدخول للوصول إلى التوقعات",
  "phoneHint": "771 234 567",
  "sendOtpButton": "استلام الرمز",
  "loginWithFacebook": "المتابعة عبر فيسبوك",
  "predictionsToday": "توقعات اليوم",
  "confidenceLevel": "الثقة",
  "betType": "الرهان",
  "odds": "الاحتمال",
  "becomePremium": "اشتراك مميز",
  "subscriptionExpiresIn": "{days, plural, =0{ينتهي اليوم} =1{ينتهي غداً} other{ينتهي خلال {days} أيام}}"
}
```

**Configuration MaterialApp** :

```dart
// lib/main.dart
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:footapp/l10n/app_localizations.dart';

class FootApp extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    
    return MaterialApp.router(
      routerConfig: appRouter,
      theme: AppTheme.darkTheme,
      
      // i18n
      locale: locale,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('fr'),
        Locale('en'),
        Locale('ar'),
      ],
      
      // RTL/LTR auto
      builder: (context, child) {
        return Directionality(
          textDirection: locale.languageCode == 'ar' 
              ? TextDirection.rtl 
              : TextDirection.ltr,
          child: child!,
        );
      },
    );
  }
}
```

**Usage dans widgets** :

```dart
// Avant
Text('Pronostics du jour')

// Après
Text(AppLocalizations.of(context)!.predictionsToday)

// Avec paramètres
Text(AppLocalizations.of(context)!.subscriptionExpiresIn(daysLeft))
```

**Generate** :

```bash
flutter gen-l10n
```

### J6 (4h) - Provider Locale + Settings

```dart
// lib/presentation/providers/locale_provider.dart
class LocaleNotifier extends StateNotifier<Locale> {
  LocaleNotifier() : super(const Locale('fr')) {
    _loadSavedLocale();
  }
  
  Future<void> _loadSavedLocale() async {
    final saved = await LocalStorage.get<String>('app_locale');
    if (saved != null) {
      state = Locale(saved);
    }
  }
  
  Future<void> setLocale(String code) async {
    state = Locale(code);
    await LocalStorage.set('app_locale', code);
    
    // Sync avec backend
    try {
      await ApiClient.instance.patch('/users/language', data: {'language': code});
    } catch (_) {}
  }
}

final localeProvider = StateNotifierProvider<LocaleNotifier, Locale>(
  (ref) => LocaleNotifier(),
);
```

**UI Settings** :

```dart
// lib/presentation/screens/profile/language_screen.dart
class LanguageScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentLocale = ref.watch(localeProvider);
    
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.languageTitle)),
      body: ListView(
        children: [
          _buildLanguageTile(context, ref, 'fr', '🇫🇷 Français', currentLocale),
          _buildLanguageTile(context, ref, 'en', '🇬🇧 English', currentLocale),
          _buildLanguageTile(context, ref, 'ar', '🇸🇦 العربية', currentLocale),
        ],
      ),
    );
  }
}
```

### J7 (4h) - Tests RTL + Polish

**Points d'attention RTL Arabe** :

- ✅ Padding/margin : utiliser `EdgeInsetsDirectional.only(start:, end:)`
- ✅ Alignement texte : `TextAlign.start` (pas `left`)
- ✅ Icons directionnelles : flèches qui s'inversent
- ✅ Vidéos/images : ne pas miroiter
- ✅ Numéros : décider si garder format arabe (٠١٢٣) ou occidental (0123)

```dart
// Helper
class AppDirectionality {
  static bool isRTL(BuildContext context) =>
      Directionality.of(context) == TextDirection.rtl;
  
  static IconData backIcon(BuildContext context) =>
      isRTL(context) ? Icons.arrow_forward : Icons.arrow_back;
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] 3 langues complètes (FR, EN, AR)
- [ ] Détection auto langue système au premier launch
- [ ] Switch manuel dans Settings
- [ ] RTL Arabe fonctionne (tester sur device)
- [ ] Notifications push localisées
- [ ] Backend renvoie bien la bonne langue
- [ ] Site web traduit (au moins landing + tarifs)
- [ ] Pas de string hardcodée dans le code

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Backend i18n | 12h |
| Notifications multilingues | 4h |
| Flutter i18n + ARB | 12h |
| Tests RTL | 2h |
| **TOTAL** | **30h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ → `MODULE-Tier-VIP.md`
