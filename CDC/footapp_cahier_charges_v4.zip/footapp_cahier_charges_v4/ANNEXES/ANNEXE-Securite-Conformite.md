# 🔐 ANNEXE - Sécurité & Conformité

> **Référence légale et technique** | RGPD, sécurité, jeu responsable, audit juridique.

---

## ⚠️ AVERTISSEMENT IMPORTANT

Cette annexe **NE remplace PAS** un avis juridique professionnel. Avant le lancement, consulter un avocat spécialisé pour :
- Légalité des paris/affiliation dans chaque pays cible
- Conformité RGPD (utilisateurs UE)
- Validation des CGU
- Politique de confidentialité

**Budget recommandé** : 500-800€ pour audit juridique multi-pays Afrique de l'Ouest.

---

## 🛡️ SÉCURITÉ TECHNIQUE

### 1. Authentification

| Mesure | Implémentation |
|--------|----------------|
| Tokens API | Laravel Sanctum, expiration 30 jours |
| OTP | 4 chiffres, hashés (bcrypt), expire 5 min |
| Tentatives OTP | Max 5, blocage 15 min |
| Rate limiting SMS | 3/heure/numéro |
| Mot de passe (admin) | bcrypt cost 12 minimum |
| Biométrie/PIN | Optionnel côté mobile (local_auth) |

### 2. Protection des données

```php
// Données sensibles chiffrées en BDD (Laravel Encrypted Cast)
class User extends Model
{
    protected $casts = [
        'phone' => 'encrypted',
        'email' => 'encrypted',
        'facebook_id' => 'encrypted',
    ];
}
```

### 3. Communications

- ✅ **HTTPS obligatoire** : Let's Encrypt sur tous les domaines
- ✅ **HSTS header** : `Strict-Transport-Security: max-age=31536000`
- ✅ **TLS 1.3** uniquement (désactiver TLS 1.0/1.1)
- ✅ **Webhooks signés** : vérification HMAC pour Paydunya/Stripe

### 4. API Security

```php
// Headers de sécurité (middleware)
class SecureHeaders
{
    public function handle($request, Closure $next)
    {
        $response = $next($request);
        
        $response->headers->set('X-Frame-Options', 'DENY');
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('X-XSS-Protection', '1; mode=block');
        $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
        $response->headers->set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
        
        return $response;
    }
}
```

### 5. SQL Injection & XSS

- ✅ Eloquent ORM partout (paramétrage automatique)
- ✅ Validation Laravel sur **TOUS** les inputs
- ✅ Échappement Blade par défaut (`{{ }}`)
- ❌ **Jamais** de `DB::raw($input)` non préparé

### 6. Backups

```bash
# Quotidien : full backup BDD
0 3 * * * mysqldump --single-transaction footapp_prod | gzip > /backups/db-$(date +\%Y\%m\%d).sql.gz

# Hebdomadaire : full backup + fichiers
0 4 * * 0 tar czf /backups/full-$(date +\%Y\%m\%d).tar.gz /var/www /backups/db-*.sql.gz

# Upload S3 / Backblaze B2
0 5 * * * aws s3 sync /backups/ s3://footapp-backups/
```

**Rétention** : 7 jours daily, 4 semaines weekly, 12 mois monthly.

### 7. Monitoring

- **Sentry** : alertes erreurs > 10/min
- **UptimeRobot** : ping toutes les 5 min
- **Logs** : Laravel → fichiers + Sentry
- **Alertes Telegram/SMS** pour incidents critiques

### 8. Pen Test & Bug Bounty

- **Phase 1** : Audit basique avec OWASP ZAP (gratuit)
- **Phase 2** : Pen test pro (~1000€) avant scale
- **Phase 3** : Bug bounty sur HackerOne (récompenses 50-500€)

---

## 📜 RGPD (Règlement Général Protection Données)

### Applicable ?

**OUI** dès qu'un utilisateur européen utilise l'app, même hébergement Afrique.

### Droits utilisateurs

```php
// Endpoints obligatoires
Route::middleware('auth:sanctum')->group(function () {
    // Droit d'accès
    Route::get('/users/data-export', [GdprController::class, 'export']);
    
    // Droit de rectification (déjà PATCH /users/profile)
    
    // Droit à l'oubli
    Route::delete('/users/me', [GdprController::class, 'deleteAccount']);
    
    // Droit d'opposition
    Route::patch('/users/marketing-consent', [GdprController::class, 'updateConsent']);
});
```

### Implémentation export

```php
class GdprController extends Controller
{
    public function export(Request $request)
    {
        $user = $request->user();
        
        $data = [
            'personal_info' => $user->only(['name', 'phone', 'email', 'created_at']),
            'subscriptions' => $user->subscriptions,
            'payments' => $user->payments,
            'predictions_viewed' => $user->predictionsViewed,
            'feedbacks' => $user->feedbacks,
        ];
        
        return response()->json($data)
            ->header('Content-Disposition', 'attachment; filename=footapp-data-export.json');
    }
    
    public function deleteAccount(Request $request)
    {
        $user = $request->user();
        
        // Anonymiser plutôt que supprimer (obligations légales paiements)
        $user->update([
            'name' => 'Utilisateur supprimé',
            'phone' => 'deleted_' . $user->id,
            'email' => null,
            'facebook_id' => null,
            'is_blocked' => true,
        ]);
        
        // Supprimer données non essentielles
        $user->feedbacks()->delete();
        $user->notifications()->delete();
        
        // Tokens
        $user->tokens()->delete();
        
        return response()->json([
            'success' => true,
            'message' => 'Compte supprimé conformément au RGPD',
        ]);
    }
}
```

### Conservation des données

| Type donnée | Durée conservation | Justification |
|-------------|-------------------|---------------|
| Compte actif | Jusqu'à suppression | Service |
| Compte inactif >1 an | Anonymisation auto | RGPD |
| Logs techniques | 90 jours | Sécurité |
| Historique paiements | 5 ans | Obligations comptables |
| Notifications | 90 jours | Performance |
| Données analytics | 14 mois | GA4 par défaut |

### Consentement

**Popup obligatoire à la première ouverture** :

```
[POPUP CONSENTEMENT RGPD]

🛡️ Vie privée

Pour utiliser FootApp, nous collectons :
✅ Numéro de téléphone (authentification)
✅ Données d'usage (améliorer l'app)
✅ Préférences (personnalisation)

Nous NE vendons JAMAIS tes données.

[Voir politique de confidentialité]
[Voir CGU]

[ Accepter ]   [ Refuser ]
```

Si refus → fermer l'app (impossibilité d'utiliser).

### DPO (Data Protection Officer)

**Phase 1** : pas obligatoire (< 250 employés et pas de traitement à grande échelle)
**Phase 2+** : nommer un DPO contact (peut être externe).

Email DPO : `dpo@mhdservice.com`

---

## 🎰 JEU RESPONSABLE

### Disclaimers obligatoires (in-app)

#### À la première ouverture (after consent)

```
⚠️ AVERTISSEMENT IMPORTANT

FootApp est un outil d'aide à la décision basé sur des 
analyses statistiques. AUCUN PRONOSTIC N'EST GARANTI.

🔞 Réservé aux personnes majeures (18+)
⚖️ Vous êtes seul responsable de vos paris
💰 Pariez avec modération

Le jeu peut devenir dangereux :
• Endettement
• Isolement social
• Problèmes psychologiques

Si tu as un problème de jeu :
🇫🇷 Joueurs Info Service : 09 74 75 13 13 (gratuit)
🇸🇳 SOS Addictions : +221 33 824 71 71

[ J'ai compris (18+) ]
```

#### Footer permanent dans l'app

```
⚠️ Pronostics générés par algorithme. Pas de garantie de gain. 
Jouez avec modération. 18+
```

#### Avant chaque pari (auto-fill)

```
💰 Tu vas être redirigé vers [Bookmaker]

Rappels :
• Cet outil est statistique, pas magique
• N'investis JAMAIS plus que tu peux perdre
• Si tu joues plus de 10 000 FCFA/jour, fais une pause

[ Continuer ]   [ Annuler ]
```

### Limites recommandées (Phase 2)

```php
// Détection de comportements à risque
class ResponsibleGamblingService
{
    public function checkRiskBehavior(User $user): array
    {
        $alerts = [];
        
        // Plus de 5 paris/jour pendant 7 jours
        $dailyClicks = $user->predictionClicks()
            ->where('created_at', '>', now()->subDays(7))
            ->groupByRaw('DATE(created_at)')
            ->selectRaw('DATE(created_at) as day, COUNT(*) as count')
            ->get();
        
        if ($dailyClicks->avg('count') > 10) {
            $alerts[] = 'high_frequency_betting';
        }
        
        // Multiple abonnements en peu de temps (chase loss?)
        $recentPayments = $user->payments()
            ->where('status', 'completed')
            ->where('created_at', '>', now()->subDays(30))
            ->count();
        
        if ($recentPayments > 4) {
            $alerts[] = 'multiple_subscriptions_short_period';
        }
        
        return $alerts;
    }
    
    public function showResponsibleGamblingModal(User $user): void
    {
        // Notification doux : "Hey, on remarque que tu joues beaucoup..."
        $user->notify(new ResponsibleGamblingReminderNotification());
    }
}
```

### Auto-exclusion

Permettre à l'utilisateur de :
- Suspendre son compte 24h, 7j, 30j, 6 mois
- Bloquer définitivement les notifications de paris
- Ressources d'aide accessibles dans Profil > Aide

---

## ⚖️ LÉGALITÉ DES PARIS / AFFILIATION

### ⚠️ Statut par pays cible

#### Phase 1 - Afrique de l'Ouest

| Pays | Statut paris | Affiliation autorisée ? |
|------|-------------|-------------------------|
| 🇸🇳 Sénégal | Réglementé (LONASE monopole) | ⚠️ Zone grise |
| 🇨🇮 Côte d'Ivoire | Réglementé (LONACI) | ⚠️ Zone grise |
| 🇧🇫 Burkina Faso | Légal (LONAB) | ⚠️ Zone grise |
| 🇲🇱 Mali | Réglementé (PMU Mali) | ⚠️ Zone grise |

> 🔴 **Critique** : les bookmakers comme Betwinner/1xBet opèrent en zone grise dans ces pays. Audit juridique obligatoire avant lancement.

#### Phase 2 - Maghreb

| Pays | Statut |
|------|--------|
| 🇲🇦 Maroc | Interdit (sauf MDJS) |
| 🇩🇿 Algérie | Interdit (sauf PMU) |
| 🇹🇳 Tunisie | Réglementé (PMUT) |
| 🇪🇬 Égypte | Interdit |

> ⚠️ **Maghreb = très risqué**. Notre app pourrait être bloquée. Reporter Phase 2.5+ avec partenariat local.

#### Phase 3 - Europe

| Pays | Statut |
|------|--------|
| 🇫🇷 France | Affiliation légale via ANJ |
| 🇧🇪 Belgique | Affiliation légale (CJH) |
| 🇨🇭 Suisse | Affiliation légale (CFMJ) |

### Stratégie légale recommandée

#### Option A : "Outil d'analyse" (recommandé MVP)

Positionner FootApp comme **service d'analyse statistique**, pas comme courtier de paris :

✅ Description Play Store : "Application d'analyse de données sportives"
✅ Pas de bouton "Parier" trop visible
✅ Liens bookmakers en backend, pas mis en avant
✅ Algorithme = produit principal, paris = secondaire

**Avantage** : passe sous le radar des régulateurs, accepté par stores.

#### Option B : Partenariats officiels (Phase 2)

Devenir partenaire officiel d'un bookmaker régulé localement :
- Sénégal : 1XBet a une license partielle
- Burkina : démarches avec LONAB

Demande temps + investissement, mais sécurise long terme.

### Mentions légales obligatoires

**Footer site web + CGU** :

```
FootApp est édité par MHD SERVICE.
RCCM : [À OBTENIR avec création société]
SIREN : [Si France]
NINEA : [Si Sénégal]
Adresse : [À DÉFINIR]
Email : contact@mhdservice.com

FootApp ne propose PAS de paris en ligne.
Nous fournissons un outil d'analyse statistique.
Les paris sont effectués chez les bookmakers tiers.

🔞 Service réservé aux personnes majeures.
⚖️ Pariez de manière responsable.
```

---

## 📋 CGU (Conditions Générales d'Utilisation)

### Structure recommandée

1. **Définitions** (utilisateur, premium, pronostic, etc.)
2. **Acceptation des CGU**
3. **Inscription et compte** (conditions, âge minimum)
4. **Service fourni** (description précise)
5. **Avertissement sur les paris** (responsabilité utilisateur)
6. **Propriété intellectuelle** (algorithme = propriété MHD)
7. **Données personnelles** (renvoi vers politique conf.)
8. **Abonnements et paiements** (conditions, remboursements)
9. **Comportement utilisateur** (interdictions)
10. **Suspension/résiliation**
11. **Limitation de responsabilité**
12. **Litiges et droit applicable**
13. **Modifications des CGU**
14. **Contact**

### Clauses critiques

**Limitation de responsabilité** :

```
ARTICLE 11 - LIMITATION DE RESPONSABILITÉ

11.1 FootApp fournit des analyses statistiques. AUCUNE GARANTIE 
n'est fournie quant à l'exactitude des prédictions ou aux gains 
potentiels.

11.2 L'Utilisateur est SEUL RESPONSABLE :
- De ses décisions de paris
- Des gains ou pertes financières
- De sa conformité aux lois locales

11.3 MHD SERVICE ne pourra être tenu responsable :
- Des pertes liées aux paris
- D'interruption de service (cas de force majeure)
- D'erreurs ponctuelles dans les données

11.4 Le montant maximum d'indemnisation, en cas de faute prouvée 
de MHD SERVICE, est limité au montant payé par l'Utilisateur 
sur les 12 derniers mois.
```

**Droit applicable** :

```
ARTICLE 13 - DROIT APPLICABLE

Les présentes CGU sont soumises au droit [Sénégalais / Français selon société].

Tout litige relève de la compétence exclusive des tribunaux de 
[Dakar / Paris].

Avant toute action, l'Utilisateur s'engage à tenter une médiation 
amiable via : support@mhdservice.com
```

---

## 🔒 POLITIQUE DE CONFIDENTIALITÉ

### Sections obligatoires (RGPD)

1. **Identité du responsable** (MHD SERVICE)
2. **Données collectées** (liste exhaustive)
3. **Finalités du traitement**
4. **Bases légales** (consentement, contrat, intérêt légitime)
5. **Destinataires** (Paydunya, Twilio, FCM, etc.)
6. **Durée de conservation**
7. **Droits utilisateurs**
8. **Cookies** (si site web)
9. **Sécurité**
10. **Transferts internationaux**
11. **Contact DPO**

### Modèle simplifié

```markdown
# Politique de confidentialité - FootApp

## 1. Qui sommes-nous ?
MHD SERVICE, éditeur de FootApp.
Email : dpo@mhdservice.com

## 2. Quelles données collectons-nous ?

**Pour t'authentifier** :
- Numéro de téléphone
- Email (optionnel)
- Identifiant Facebook (si login Facebook)

**Pour le service** :
- Préférences (langue, championnats favoris)
- Historique consultation pronostics
- Préférence bookmaker

**Pour la facturation** :
- Transactions (montant, date, statut)
- Pas de stockage CB (géré par Stripe/Paydunya)

**Automatique** :
- Adresse IP (pour sécurité)
- Modèle device, OS, version app
- Données de crash (Sentry)

## 3. Pourquoi ?
- Te fournir le service
- Améliorer l'algorithme (anonymisé)
- Te contacter pour le support
- Respecter nos obligations légales

## 4. Avec qui partageons-nous ?
- Paydunya (paiements Mobile Money)
- Stripe (paiements CB)
- Twilio (SMS OTP)
- Firebase (notifications push)
- Sentry (logs erreurs)

Aucune donnée n'est vendue à des tiers.

## 5. Combien de temps ?
- Compte actif : tant que tu utilises l'app
- Compte inactif : suppression après 12 mois
- Logs : 90 jours
- Paiements : 5 ans (obligation comptable)

## 6. Tes droits
- Accès : voir toutes tes données
- Rectification : corriger
- Suppression : supprimer ton compte
- Opposition : refuser le marketing
- Portabilité : exporter en JSON

Pour exercer ces droits : Profil > Mes données

## 7. Sécurité
HTTPS partout, BDD chiffrée, mots de passe hashés.

## 8. Hébergement
VPS Hostinger en Europe (Lituanie - conformité RGPD ✅).

## 9. Modifications
Toute modification sera notifiée par email/push.

Dernière mise à jour : [DATE]
```

---

## 🛂 KYC (Know Your Customer)

### Quand obligatoire ?

- **Pas en MVP** (juste OTP suffit)
- **Phase 2 : KYC pour Tipsters** (marketplace)
- **Phase 2.5 : KYC progressif** si transactions > 100k FCFA

### Implémentation

```php
class KycService
{
    public function requestKyc(User $user, string $reason): void
    {
        $user->notify(new KycRequiredNotification($reason));
        
        $user->update(['kyc_status' => 'required']);
    }
    
    public function verifyDocuments(User $user, array $docs): bool
    {
        // Manuel par admin en MVP
        // Automatisable Phase 3 avec services type Onfido, Veriff
    }
}
```

---

## 🚨 PLAN INCIDENT SÉCURITÉ

### Procédure en cas de violation de données

1. **Détection** (Sentry alerte)
2. **Containment** : isoler le système compromis
3. **Évaluation** : volume + nature des données
4. **Notification** :
   - **CNIL** sous 72h (si > UE concernés)
   - **Utilisateurs** si risque élevé
5. **Correction** : patch + audit
6. **Documentation** : registre des violations

### Contacts d'urgence

| Service | Contact |
|---------|---------|
| Hostinger Support | priority support |
| Sentry on-call | (configuré) |
| Avocat | (à définir) |
| CNIL France | cnil.fr |

---

## 📊 AUDIT JURIDIQUE - TODO

### Avant lancement (Phase 0)

- [ ] Choix forme juridique (SARL/SAS/SUARL Sénégal)
- [ ] Consultation avocat spécialisé jeux/numérique
- [ ] Validation CGU + Politique Confidentialité
- [ ] Vérification légalité affiliation Burkina/Sénégal/CI/Mali
- [ ] Inscription RCCM/registres locaux
- [ ] Compte bancaire pro

### Budget audit recommandé

| Service | Coût |
|---------|------|
| Consultation initiale | 200€ |
| Rédaction CGU + PC | 300€ |
| Audit juridique multi-pays | 300€ |
| **TOTAL** | **800€** |

---

## ✅ CHECKLIST CONFORMITÉ AVANT LANCEMENT

- [ ] HTTPS sur tous les domaines
- [ ] Backups automatiques actifs
- [ ] Sentry configuré + alertes
- [ ] Données sensibles chiffrées en BDD
- [ ] Rate limiting actif
- [ ] CGU + PC validées par avocat
- [ ] Popup consentement RGPD
- [ ] Endpoints export/suppression données
- [ ] Disclaimers jeu responsable visibles
- [ ] Mentions légales footer
- [ ] DPO email actif
- [ ] Plan incident documenté
- [ ] Tests pen test basique passés
- [ ] Société créée + RCCM
- [ ] Compte bancaire pro

---

*Cette annexe est un guide. Pour la conformité légale réelle, **consulter un avocat avant lancement**.*

*Dernière mise à jour : Octobre 2025*
