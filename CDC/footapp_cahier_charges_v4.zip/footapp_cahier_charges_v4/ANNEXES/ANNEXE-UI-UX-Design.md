# 🎨 ANNEXE - UI/UX Design System

> **Référence design** | Charte graphique, design system, écrans clés.
> Inspiration : Linear (premium), Discord (engagement), Strava (gamification).

---

## 🎨 IDENTITÉ VISUELLE

### Logo

**Concept** : ballon stylisé avec courbes tech (IA/data)

**Variantes** :
- Logo + texte horizontal (header)
- Logo seul (icône app)
- Logo monochrome (footer)

**Tailles requises** :
- 1024×1024 (Play Store)
- 512×512 (Play Store hi-res icon)
- 192×192, 512×512 (PWA)
- 48×48 → 192×192 (Android adaptive)

### Palette de couleurs

#### Primary

```css
--primary: #00BCD4;          /* Cyan vif - Tech, trust */
--primary-dark: #0097A7;
--primary-light: #4DD0E1;
```

#### Accent

```css
--accent: #FF6B35;           /* Orange foot - Énergie, action */
--accent-light: #FF8C61;
```

#### Neutrals (Dark mode first)

```css
--background: #0F1419;       /* Background principal */
--surface: #1A1F2E;          /* Cards, modales */
--surface-light: #252B3D;    /* Cards hover */
--surface-elevated: #2D3548; /* Modal background */
```

#### Text

```css
--text-primary: #FFFFFF;
--text-secondary: #B0B7C3;
--text-tertiary: #6B7280;
--text-disabled: #4A5168;
```

#### Status

```css
--success: #10B981;          /* Vert - Won */
--error: #EF4444;            /* Rouge - Lost */
--warning: #F59E0B;          /* Jaune - Attention */
--info: #3B82F6;             /* Bleu - Info */
```

#### Confidence levels

```css
--conf-very-high: #10B981;   /* 85+ */
--conf-high: #60A5FA;        /* 70-84 */
--conf-medium: #F59E0B;      /* 60-69 */
--conf-low: #F97316;         /* 50-59 */
```

#### Premium

```css
--premium: #FFD700;          /* Or - Premium */
--premium-dark: #FBBF24;
--vip: linear-gradient(135deg, #FFD700, #FF6B35); /* Gold-orange gradient */
```

---

## 📐 TYPOGRAPHIE

### Font family

**Poppins** (Google Fonts) - moderne, lisible, multi-langues OK
+ **Cairo** pour l'arabe (RTL support natif)

```yaml
# pubspec.yaml
fonts:
  - family: Poppins
    fonts:
      - asset: assets/fonts/Poppins-Regular.ttf
      - asset: assets/fonts/Poppins-Medium.ttf
        weight: 500
      - asset: assets/fonts/Poppins-SemiBold.ttf
        weight: 600
      - asset: assets/fonts/Poppins-Bold.ttf
        weight: 700
```

### Échelle typographique

| Style | Taille | Weight | Usage |
|-------|--------|--------|-------|
| Display | 32px | Bold (700) | Hero titles |
| Heading 1 | 28px | Bold | Page titles |
| Heading 2 | 24px | SemiBold (600) | Section titles |
| Heading 3 | 20px | SemiBold | Card titles |
| Heading 4 | 18px | Medium (500) | Subsections |
| Body Large | 16px | Regular (400) | Paragraphes principaux |
| Body | 14px | Regular | Texte courant |
| Body Small | 12px | Regular | Captions, hints |
| Tiny | 10px | Medium | Badges, labels |

### Code Flutter

```dart
class AppTextStyles {
  static const display = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    height: 1.2,
    color: AppColors.textPrimary,
  );
  
  static const h1 = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    height: 1.3,
  );
  
  static const h2 = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    height: 1.3,
  );
  
  static const h3 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );
  
  static const bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.normal,
    height: 1.5,
  );
  
  static const body = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.normal,
    height: 1.5,
  );
  
  static const caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    height: 1.4,
    color: AppColors.textSecondary,
  );
  
  static const tiny = TextStyle(
    fontSize: 10,
    fontWeight: FontWeight.w500,
    letterSpacing: 0.5,
  );
}
```

---

## 📏 SPACING

Système basé sur **multiples de 4** :

```dart
class AppSpacing {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 16.0;
  static const lg = 24.0;
  static const xl = 32.0;
  static const xxl = 48.0;
}
```

### Usage standard

- Padding bouton : 16 horizontal × 12 vertical
- Padding carte : 16 partout
- Margin entre cartes : 12
- Margin entre sections : 24
- Margin entre groupes de sections : 32

---

## 🔘 COMPOSANTS

### Boutons

#### Primary (CTA principal)

```dart
ElevatedButton(
  style: ElevatedButton.styleFrom(
    backgroundColor: AppColors.primary,
    foregroundColor: Colors.black,
    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
    minimumSize: const Size(double.infinity, 56),
    textStyle: AppTextStyles.bodyLarge.copyWith(fontWeight: FontWeight.bold),
  ),
  child: const Text('Action'),
)
```

#### Secondary (outlined)

```dart
OutlinedButton(
  style: OutlinedButton.styleFrom(
    side: const BorderSide(color: AppColors.primary, width: 2),
    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
  ),
  child: const Text('Action secondaire'),
)
```

#### Premium (gradient or)

```dart
Container(
  decoration: BoxDecoration(
    gradient: const LinearGradient(
      colors: [AppColors.premium, AppColors.premiumDark],
    ),
    borderRadius: BorderRadius.circular(12),
  ),
  child: ElevatedButton(
    style: ElevatedButton.styleFrom(
      backgroundColor: Colors.transparent,
      shadowColor: Colors.transparent,
    ),
    child: const Text('Devenir Premium', style: TextStyle(color: Colors.black)),
  ),
)
```

#### Tailles

- Large : 56px height (CTA principal)
- Medium : 44px height (actions secondaires)
- Small : 36px height (actions tertiaires)
- Icon : 40×40 carré

### Cards

```dart
Card(
  elevation: 0,
  color: AppColors.surface,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(16),
  ),
  child: Padding(
    padding: const EdgeInsets.all(16),
    child: child,
  ),
)
```

**Variations** :
- Default : `surface` background
- Hover : `surfaceLight`
- Selected : border `primary` 2px
- Disabled : opacity 0.5

### Inputs

```dart
TextField(
  decoration: InputDecoration(
    filled: true,
    fillColor: AppColors.surface,
    contentPadding: const EdgeInsets.all(16),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: AppColors.primary, width: 2),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: AppColors.error, width: 1),
    ),
  ),
)
```

### Badges

```dart
class ConfidenceBadge extends StatelessWidget {
  final double score;
  
  Color get color {
    if (score >= 85) return AppColors.confVeryHigh;
    if (score >= 70) return AppColors.confHigh;
    if (score >= 60) return AppColors.confMedium;
    return AppColors.confLow;
  }
  
  String get stars {
    if (score >= 85) return '⭐⭐⭐⭐';
    if (score >= 70) return '⭐⭐⭐';
    if (score >= 60) return '⭐⭐';
    return '⭐';
  }
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(stars, style: const TextStyle(fontSize: 12)),
          const SizedBox(width: 4),
          Text(
            '${score.toInt()}%',
            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
```

---

## 🌑 DARK MODE / LIGHT MODE

**Décision** : Dark mode par défaut, light mode optionnel Phase 2.

**Pourquoi dark first** :
- Plus moderne (perçu premium)
- Économe batterie OLED
- Plus reposant pour le soir (usage principal des paris)
- Plus tendance dans les apps tech/finance

```dart
// Phase 2 : Toggle theme
class ThemeNotifier extends StateNotifier<ThemeMode> {
  ThemeNotifier() : super(ThemeMode.dark) {
    _loadSavedTheme();
  }
  
  void toggle() {
    state = state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    LocalStorage.set('theme_mode', state.name);
  }
}
```

---

## 🎯 ÉCRANS CLÉS

### 1. Onboarding

**Layout** :
- 4 slides full screen
- Lottie animations en haut (60% écran)
- Title + subtitle (centrés)
- Page indicator (dots)
- CTA "Suivant" (bottom, primary button)
- "Passer" (top right, text button)

**4 slides** :
1. 🤖 Pronostics IA → "Algorithme analysant 50+ critères"
2. ⚡ Auto-Fill → "Pariez en 15 secondes"
3. 💰 Mobile Money → "Wave, Orange Money sans CB"
4. 🎁 7 jours gratuits → "Inscris-toi sur un bookmaker partenaire"

### 2. Login

**Layout** :
- Logo (haut, 80px)
- Welcome text
- Phone input avec country picker (drapeau + code)
- Bouton "Recevoir le code" (CTA primary)
- Divider "OU"
- Bouton Facebook (outlined avec icône)
- Footer : "En continuant tu acceptes les CGU"

### 3. OTP Verification

**Layout** :
- Title : "Code envoyé"
- Subtitle : "Entre les 4 chiffres reçus au [phone]"
- 4 cases input (auto-focus next)
- Compteur "Renvoyer dans Xs" → bouton actif après
- "Modifier le numéro" en bas

### 4. Dashboard

**Layout** :
```
┌──────────────────────────┐
│ AppBar [FootApp] [🔔]    │
├──────────────────────────┤
│ [Bannière Premium] (si   │
│  user free)              │
├──────────────────────────┤
│ 💎 Combiné du jour       │
│ [Carte gratter ou révélé]│
├──────────────────────────┤
│ 🔥 Pronostics du jour    │
│ [Card 1]                 │
│ [Card 2]                 │
│ [Card 3] ...             │
├──────────────────────────┤
│ [Bottom Nav]             │
└──────────────────────────┘
```

### 5. Card Pronostic

```
┌─────────────────────────────┐
│ 🏆 Premier League    16h00  │
├─────────────────────────────┤
│ [Logo] Man City             │
│            VS               │
│ Luton Town [Logo]           │
├─────────────────────────────┤
│ Pari       Cote   Confiance │
│ City gagne 1.45   ⭐⭐⭐⭐    │
└─────────────────────────────┘
```

### 6. Détail Pronostic

```
┌─────────────────────────────┐
│ ← Détail du pronostic       │
├─────────────────────────────┤
│ [Match Header complet]      │
├─────────────────────────────┤
│ 🎯 Pourquoi ce pronostic ?  │
│ ✅ Forme excellente         │
│ ✅ Domicile +90% wins       │
│ ⚠️ 1 joueur clé absent      │
├─────────────────────────────┤
│ 📊 Stats détaillées         │
│ [Tableaux/graphiques]       │
├─────────────────────────────┤
│ [Bouton: Parier ⚡]          │
│ Bookmakers: BW | 1xBet | MB │
└─────────────────────────────┘
```

### 7. Carte à Gratter (Combiné Premium)

```
┌─────────────────────────────┐
│  🎰 Combiné du Jour         │
│                             │
│  Score : 73%                │
│                             │
│  [Texture scratch grise]    │
│                             │
│  Gratte pour découvrir      │
│                             │
└─────────────────────────────┘

(After 40% scratched)

┌─────────────────────────────┐
│ 🏆 Combiné Premium  73% ⭐   │
├─────────────────────────────┤
│ ✓ PSG vs OM      @1.95      │
│ ✓ Real vs Barça  @1.62      │
│ ✓ Bayern vs Dortm @1.75     │
│ ✓ Arsenal vs Che  @1.88     │
├─────────────────────────────┤
│ Cote totale    x12.85       │
│                             │
│ [Parier maintenant ⚡]       │
└─────────────────────────────┘
```

### 8. Subscription

```
┌─────────────────────────────┐
│ ← Devenir Premium           │
├─────────────────────────────┤
│ [Header gold gradient]      │
│ 🏆 Débloquez tout           │
├─────────────────────────────┤
│ ✓ Combinés quotidiens       │
│ ✓ Stats avancées            │
│ ✓ Notifications push        │
│ ✓ Sans publicité            │
├─────────────────────────────┤
│ Plans :                     │
│ ┌─────────────────────────┐ │
│ │ Hebdo   2500 F  357/jr  │ │
│ ├─────────────────────────┤ │
│ │ Mensuel ⭐ 8000 F   -25% │ │
│ │ Populaire               │ │
│ ├─────────────────────────┤ │
│ │ Trim 🔥 20000 F  -38%   │ │
│ ├─────────────────────────┤ │
│ │ VIP 👑  15000 F          │ │
│ └─────────────────────────┘ │
├─────────────────────────────┤
│ Paiement :                  │
│ ◉ Mobile Money              │
│ ○ Carte bancaire            │
├─────────────────────────────┤
│ [S'abonner 8000 FCFA]       │
└─────────────────────────────┘
```

### 9. Profile

```
┌─────────────────────────────┐
│ Profil                      │
├─────────────────────────────┤
│ [Avatar] Mamadou D.          │
│ +221 77 123 4567            │
│ 👑 VIP - Expire 15/05       │
│ Niv. 12 | 1 250 XP          │
├─────────────────────────────┤
│ ⭐ Mon abonnement            │
│ 🎁 Parrainage (3 filleuls)  │
│ 💰 Coaching                 │
│ 🌍 Langue                   │
│ 🔔 Notifications            │
│ ❓ FAQ / Support             │
│ 🚪 Déconnexion              │
└─────────────────────────────┘
```

### 10. Bottom Navigation

```
┌─────────────────────────────┐
│ [🏠]  [📊]  [🎰]  [👤]      │
│ Acc.  Stats Coaching Profil │
└─────────────────────────────┘
```

---

## 🎬 ANIMATIONS & MICRO-INTERACTIONS

### Transitions de page

```dart
// GoRouter custom transitions
GoRoute(
  path: '/prediction/:id',
  pageBuilder: (context, state) => CustomTransitionPage(
    child: PredictionDetailScreen(...),
    transitionsBuilder: (context, animation, _, child) {
      return SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
          parent: animation,
          curve: Curves.easeInOut,
        )),
        child: child,
      );
    },
  ),
)
```

### Loading states (Shimmer)

```dart
import 'package:shimmer/shimmer.dart';

class ShimmerLoadingCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.surface,
      highlightColor: AppColors.surfaceLight,
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }
}
```

### Confettis (Win, Spin, Achievement)

```dart
import 'package:confetti/confetti.dart';

ConfettiWidget(
  confettiController: _confettiController,
  blastDirectionality: BlastDirectionality.explosive,
  particleDrag: 0.05,
  emissionFrequency: 0.05,
  numberOfParticles: 50,
  gravity: 0.05,
  shouldLoop: false,
  colors: const [AppColors.primary, AppColors.accent, AppColors.premium],
)
```

### Haptic feedback

```dart
import 'package:flutter/services.dart';

// Léger : tap normal
HapticFeedback.lightImpact();

// Moyen : action importante (paiement)
HapticFeedback.mediumImpact();

// Fort : grosse action (win)
HapticFeedback.heavyImpact();

// Selection
HapticFeedback.selectionClick();
```

---

## 📱 RESPONSIVE & ADAPTATIONS

### Breakpoints (mobile)

- **Compact** : < 360px (low-end Android)
- **Medium** : 360-414px (standard)
- **Expanded** : > 414px (Pro phones)

### iPad / Tablet (Phase 2+)

- Layout 2 colonnes (master-detail)
- Plus de cartes par ligne
- Sidebar navigation (au lieu de bottom nav)

---

## 🌐 RTL SUPPORT (Arabe)

### Règles à respecter

```dart
// ❌ Mauvais
Padding(padding: EdgeInsets.only(left: 16, right: 8))
Icon(Icons.arrow_back)

// ✅ Bon
Padding(padding: EdgeInsetsDirectional.only(start: 16, end: 8))
Icon(AppDirectionality.isRTL(context) ? Icons.arrow_forward : Icons.arrow_back)
```

---

## 🖼️ ICONS

**Library** : `lucide_icons` (modernes, minimalistes)

```yaml
dependencies:
  lucide_icons: ^0.319.0
```

```dart
import 'package:lucide_icons/lucide_icons.dart';

Icon(LucideIcons.target)
Icon(LucideIcons.trophy)
Icon(LucideIcons.zap)
```

---

## 🎨 ASSETS REQUIS

### Lottie animations (gratuit sur lottiefiles.com)

- `ai_brain.json` - Onboarding 1
- `lightning.json` - Onboarding 2
- `mobile_money.json` - Onboarding 3
- `gift.json` - Onboarding 4
- `confetti.json` - Win
- `loading.json` - États de chargement
- `empty.json` - États vides

### Images

- Logo + variants
- Icônes adaptive Android
- Splash screens (chaque résolution)
- Banner Play Store (1024×500)
- 8 screenshots Play Store (1080×1920 chacun)

### Bookmaker logos

- Betwinner (PNG transparent)
- 1xBet
- Melbet

---

## 🛠️ OUTILS DESIGN RECOMMANDÉS

| Tool | Usage |
|------|-------|
| **Figma** | Design des écrans (gratuit) |
| **Lottiefiles** | Animations gratuites |
| **Coolors.co** | Palettes couleurs |
| **Google Fonts** | Polices |
| **Iconify** | Icônes |
| **Removebg** | Détourer images |
| **Squoosh** | Optimiser images |

---

## ✅ CHECKLIST DESIGN AVANT LANCEMENT

- [ ] Logo final + variants exportés
- [ ] Palette couleurs implémentée dans theme
- [ ] Typographie Poppins importée
- [ ] Tous les écrans designés sur Figma
- [ ] Onboarding (4 slides) avec Lottie
- [ ] Dark mode appliqué partout
- [ ] Composants réutilisables créés (boutons, cards, badges)
- [ ] Micro-interactions (haptic feedback, animations)
- [ ] States empty/error/loading designés
- [ ] Adaptive icons Android
- [ ] Splash screen
- [ ] 8 screenshots Play Store

---

*Design system FootApp v1.0 | Octobre 2025*
