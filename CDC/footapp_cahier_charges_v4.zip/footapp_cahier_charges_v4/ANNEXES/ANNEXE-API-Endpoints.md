# 🔌 ANNEXE - API Endpoints

> **Référence complète** des endpoints REST de l'API FootApp Backend
> Base URL : `https://api.footapp.com/api/v1`

---

## 🔐 AUTHENTIFICATION

Toutes les routes protégées requièrent un header :
```
Authorization: Bearer {access_token}
```

Le token est obtenu via OTP ou Facebook OAuth, expire après **30 jours**.

---

## 📋 SOMMAIRE DES ENDPOINTS

### Routes publiques
- [POST /auth/otp/send](#post-authotpsend)
- [POST /auth/otp/verify](#post-authotpverify)
- [POST /auth/facebook](#post-authfacebook)
- [POST /webhooks/paydunya](#post-webhookspaydunya)
- [POST /webhooks/stripe](#post-webhooksstripe)
- [GET /public/predictions/today](#get-publicpredictionstoday) (limité)

### Routes authentifiées
- **Auth** : logout, me, refresh
- **Predictions** : today, detail, history, combined
- **Payments** : checkout, history, plans
- **Affiliations** : url, check, promos, autofill
- **Profile** : me, update, language, fcm-token
- **Subscription** : current, history
- **Referral** : code, list, stats
- **Notifications** : preferences, list, mark-read
- **Feedback** : submit, list

### Routes Premium
- /predictions/premium-only
- /combineds/today

### Routes VIP (Phase 2)
- /vip/predictions/all
- /vip/combineds/today
- /vip/whatsapp-link

---

## 1️⃣ AUTH

### POST /auth/otp/send

**Description** : Envoie un code OTP par SMS au numéro de téléphone.

**Body** :
```json
{
  "phone": "+221771234567"
}
```

**Response 200** :
```json
{
  "success": true,
  "message": "Code envoyé",
  "expires_in": 300
}
```

**Response 422** :
```json
{
  "success": false,
  "errors": {
    "phone": ["Format invalide"]
  }
}
```

**Response 429** :
```json
{
  "success": false,
  "message": "Trop de tentatives. Réessaie dans 60 secondes."
}
```

**Rate limit** : 3 SMS / heure / numéro

---

### POST /auth/otp/verify

**Body** :
```json
{
  "phone": "+221771234567",
  "code": "1234"
}
```

**Response 200** :
```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "name": "Mamadou",
      "phone": "+221771234567",
      "is_premium": false,
      "subscription_expires_at": null,
      "language": "fr"
    },
    "access_token": "1|laravel_sanctum_...",
    "token_type": "Bearer"
  }
}
```

**Response 422** :
```json
{
  "success": false,
  "message": "Code invalide ou expiré"
}
```

---

### POST /auth/facebook

**Body** :
```json
{
  "facebook_token": "EAABwzLix...",
  "device_id": "uuid-device"
}
```

**Response 200** : idem OTP verify (renvoie user + token)

---

### POST /auth/logout 🔒

Headers : `Authorization: Bearer {token}`

**Response 200** :
```json
{
  "success": true,
  "message": "Déconnecté"
}
```

---

### GET /auth/me 🔒

**Response 200** :
```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Mamadou",
    "phone": "+221771234567",
    "email": null,
    "is_premium": true,
    "subscription_type": "monthly",
    "subscription_expires_at": "2026-06-01T00:00:00Z",
    "preferred_bookmaker": "betwinner",
    "language": "fr",
    "level": 5,
    "xp": 1250,
    "referrals_count": 3,
    "referral_code": "MAMADOU123"
  }
}
```

---

## 2️⃣ PREDICTIONS

### GET /predictions/today 🔒

**Query params** :
- `competition_id` (optional) : filtrer par championnat
- `min_confidence` (optional) : seuil minimum (default 50)
- `bet_type` (optional) : filtrer par type pari

**Response 200** :
```json
{
  "success": true,
  "data": [
    {
      "id": 1023,
      "match": {
        "id": 5012,
        "home_team": {"id": 1, "name": "PSG", "logo": "..."},
        "away_team": {"id": 2, "name": "Marseille", "logo": "..."},
        "competition": {"id": 1, "name": "Ligue 1", "logo": "..."},
        "match_date": "2026-05-02T20:00:00Z",
        "venue": "Parc des Princes"
      },
      "bet_type": "match_winner",
      "bet_choice": "1",
      "odds": 1.45,
      "confidence_score": 78.5,
      "confidence_level": "ÉLEVÉE",
      "is_premium_only": false,
      "analysis": "PSG en grande forme à domicile..."
    }
  ],
  "meta": {
    "total": 12,
    "premium_count": 5,
    "free_count": 7
  }
}
```

---

### GET /predictions/{id} 🔒

**Response 200** :
```json
{
  "success": true,
  "data": {
    "id": 1023,
    "match": {...},
    "bet_type": "match_winner",
    "bet_choice": "1",
    "odds": 1.45,
    "confidence_score": 78.5,
    "scoring_details": {
      "recent_form": {"score": 22.4, "details": "..."},
      "h2h": {"score": 13.8, "details": "..."},
      "home_away": {"score": 17.4, "details": "..."},
      "league_position": {"score": 13.0, "details": "..."},
      "goal_stats": {"score": 6.8, "details": "..."},
      "time_factor": {"score": 6.0, "details": "..."}
    },
    "analysis": "Analyse complète détaillée...",
    "bookmaker_links": {
      "betwinner": "https://...",
      "1xbet": "https://...",
      "melbet": "https://..."
    }
  }
}
```

---

### GET /predictions/history 🔒

**Query params** :
- `status` : pending, won, lost, void
- `from` : date YYYY-MM-DD
- `to` : date YYYY-MM-DD
- `page` : pagination

**Response 200** : Liste paginée avec stats globales

---

### GET /predictions/combined-daily 🔒

**Response 200** :
```json
{
  "success": true,
  "data": {
    "id": 45,
    "date": "2026-05-02",
    "type": "daily_premium",
    "predictions": [
      {...prediction objects...}
    ],
    "total_odds": 12.85,
    "confidence_avg": 76.3,
    "is_premium_only": true,
    "scratched": false
  }
}
```

**Response 403** (si free user) :
```json
{
  "error": "PREMIUM_REQUIRED",
  "scratch_card_available": true
}
```

---

### POST /combineds/{id}/scratch 🔒

Marque la carte comme grattée (pour analytics).

---

## 3️⃣ PAYMENTS

### POST /payments/checkout 🔒

**Body** :
```json
{
  "plan_type": "monthly",
  "gateway": "paydunya"
}
```

**Response 200** :
```json
{
  "success": true,
  "data": {
    "payment_url": "https://paydunya.com/checkout/...",
    "token": "test_HxKxw...",
    "expires_at": "2026-05-02T22:00:00Z"
  }
}
```

---

### GET /payments/plans

**Response 200** :
```json
{
  "success": true,
  "data": [
    {
      "type": "daily",
      "name": "Journalier",
      "price_fcfa": 500,
      "price_eur": 0.80,
      "duration_days": 1,
      "badge": null
    },
    {
      "type": "weekly",
      "name": "Hebdomadaire",
      "price_fcfa": 2500,
      "price_eur": 3.80,
      "duration_days": 7
    },
    {
      "type": "monthly",
      "name": "Mensuel",
      "price_fcfa": 8000,
      "price_eur": 12,
      "duration_days": 30,
      "badge": "Populaire"
    },
    {
      "type": "quarterly",
      "name": "Trimestriel",
      "price_fcfa": 20000,
      "price_eur": 30,
      "duration_days": 97,
      "badge": "Meilleure offre",
      "discount": "-33%"
    },
    {
      "type": "vip",
      "name": "VIP Premium",
      "price_fcfa": 15000,
      "price_eur": 23,
      "duration_days": 30,
      "badge": "VIP"
    }
  ]
}
```

---

### GET /payments/history 🔒

**Response 200** :
```json
{
  "success": true,
  "data": [
    {
      "id": 234,
      "amount": 8000,
      "currency": "XOF",
      "plan_type": "monthly",
      "gateway": "paydunya",
      "status": "completed",
      "paid_at": "2026-04-15T14:32:00Z"
    }
  ],
  "meta": {
    "current_page": 1,
    "total": 12
  }
}
```

---

## 4️⃣ AFFILIATIONS

### GET /affiliations/{bookmaker}/url 🔒

**Path params** : `bookmaker` ∈ {betwinner, 1xbet, melbet}

**Response 200** :
```json
{
  "success": true,
  "data": {
    "tracking_url": "https://betwinner.com/?tag=...",
    "bookmaker": "betwinner",
    "promos": [
      {
        "promo_code": "BWMHD200",
        "description": "100% bonus 1er dépôt jusqu'à 130 000 FCFA",
        "max_bonus": 130000
      }
    ]
  }
}
```

---

### POST /affiliations/{bookmaker}/check 🔒

Vérifier si l'inscription a été confirmée.

**Response 200** :
```json
{
  "success": true,
  "bonus_granted": true,
  "message": "🎁 7 jours premium activés !"
}
```

---

### GET /affiliations/{bookmaker}/promos

Public, retourne les promos actives.

---

### GET /betslip/autofill/{combined_id}/{bookmaker} 🔒

**Response 200** :
```json
{
  "success": true,
  "data": {
    "bookmaker_url": "https://...",
    "autofill_script": "(function(){...})();",
    "matches_count": 4
  }
}
```

---

### POST /betslip/autofill-result 🔒

**Body** :
```json
{
  "bookmaker": "betwinner",
  "success": true,
  "matches_filled": 4,
  "error": null
}
```

---

## 5️⃣ PROFILE

### PATCH /users/profile 🔒

**Body** (partial update) :
```json
{
  "name": "Mamadou Diop",
  "email": "mamadou@example.com"
}
```

---

### PATCH /users/language 🔒

**Body** :
```json
{
  "language": "ar"
}
```

---

### POST /users/fcm-token 🔒

**Body** :
```json
{
  "token": "fcm_token_xxx",
  "platform": "android"
}
```

---

### POST /users/preferred-bookmaker 🔒

**Body** :
```json
{
  "bookmaker": "betwinner",
  "has_account": true
}
```

---

## 6️⃣ SUBSCRIPTION

### GET /subscription/current 🔒

**Response 200** :
```json
{
  "success": true,
  "data": {
    "is_active": true,
    "plan_type": "monthly",
    "starts_at": "2026-04-15T00:00:00Z",
    "expires_at": "2026-05-15T00:00:00Z",
    "days_remaining": 13,
    "auto_renewal": false
  }
}
```

---

## 7️⃣ REFERRAL

### GET /referrals/me 🔒

**Response 200** :
```json
{
  "success": true,
  "data": {
    "referral_code": "MAMADOU123",
    "share_link": "https://footapp.com/r/MAMADOU123",
    "share_message": "Rejoins-moi sur FootApp...",
    "referrals_count": 3,
    "rewards_earned_days": 21,
    "next_milestone": {
      "count": 5,
      "reward": "1 mois premium"
    },
    "history": [
      {"name": "Awa K.", "joined_at": "2026-04-10", "rewarded": true},
      {"name": "Modou D.", "joined_at": "2026-04-15", "rewarded": true}
    ]
  }
}
```

---

## 8️⃣ NOTIFICATIONS

### GET /notifications/preferences 🔒

**Response 200** : objet préférences complet

---

### PATCH /notifications/preferences 🔒

**Body** : objet partiel des préférences

---

### GET /notifications 🔒

Liste des notifications reçues (paginée).

---

### POST /notifications/{id}/mark-read 🔒

---

## 9️⃣ FEEDBACK

### POST /feedback 🔒

**Body** (multipart) :
```
category: bug
description: "L'écran de paiement ne charge pas..."
screenshot: <file>
app_version: "1.0.5"
platform: "android"
```

**Response 200** :
```json
{
  "success": true,
  "data": {
    "id": 89,
    "status": "open",
    "ticket_number": "FOOT-89"
  }
}
```

---

## 🔟 WEBHOOKS

### POST /webhooks/paydunya

Envoi automatique par Paydunya après paiement.

**Body Paydunya** :
```json
{
  "data": {
    "invoice": {
      "token": "test_HxKxw...",
      "total_amount": 8000,
      "status": "completed"
    },
    "custom_data": {
      "user_id": 1,
      "plan_type": "monthly"
    }
  }
}
```

**Important** : signature vérifiée auprès de Paydunya avant validation.

---

### POST /webhooks/stripe

Body Stripe standard (event objects).

---

## 🎯 GAMIFICATION (Phase 2)

### POST /spin/daily 🔒

Tour de roue quotidien.

**Response 200** :
```json
{
  "success": true,
  "data": {
    "reward": {
      "type": "premium_day",
      "value": 1,
      "label": "1 jour premium gratuit !"
    },
    "next_spin_at": "2026-05-03T00:00:00Z"
  }
}
```

---

### GET /challenges/active 🔒

---

### POST /challenges/{id}/claim 🔒

Réclame la récompense d'un challenge complété.

---

## 👑 VIP (Phase 2)

### GET /vip/predictions/all 🔒 VIP

Tous les pronostics, même score < 50.

---

### GET /vip/combineds/today 🔒 VIP

Combiné VIP haute cote (x30+).

---

### GET /vip/whatsapp-link 🔒 VIP

**Response 200** :
```json
{
  "data": {
    "link": "https://chat.whatsapp.com/...",
    "expires_at": "2026-05-31T23:59:59Z"
  }
}
```

---

## 🤖 ML PREDICTION SERVICE (Internal - Python)

Microservice séparé sur port 8001.

### POST /predict (internal)

**Body** :
```json
{
  "home_form_points": 22.5,
  "away_form_points": 2.5,
  "h2h_diff": 3,
  "home_position": 1,
  "away_position": 18,
  "home_xg_avg": 2.3,
  "away_xg_avg": 0.9,
  "match_hour": 16,
  "home_injuries_impact": 1,
  "away_injuries_impact": 5
}
```

**Response 200** :
```json
{
  "win_proba_home": 0.85,
  "win_proba_draw": 0.10,
  "win_proba_away": 0.05,
  "confidence": 85.0,
  "recommended_bet": "1"
}
```

---

## 📊 ADMIN (Filament)

Pas exposé en API REST, accessible uniquement via dashboard web.

URL : `https://api.footapp.com/admin`

---

## ⚙️ HEADERS COMMUNS

### Request

```http
Content-Type: application/json
Accept: application/json
Authorization: Bearer {token}
Accept-Language: fr-FR
X-App-Version: 1.0.5
X-Platform: android
X-Device-Id: uuid-...
```

### Response

```http
Content-Type: application/json
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59
X-Request-Id: uuid-...
```

---

## 📈 RATE LIMITING

| Endpoint | Limit |
|----------|-------|
| `/auth/otp/send` | 3 / heure / phone |
| `/auth/otp/verify` | 5 / 10 min / phone |
| `/predictions/*` | 60 / minute / user |
| `/payments/checkout` | 5 / heure / user |
| Default authenticated | 60 / minute / user |
| Default public | 30 / minute / IP |

---

## 🔍 CODES ERREUR STANDARDISÉS

| Code | Description |
|------|-------------|
| `AUTH_REQUIRED` | Token manquant |
| `AUTH_INVALID` | Token invalide/expiré |
| `PREMIUM_REQUIRED` | Fonctionnalité premium |
| `VIP_REQUIRED` | Fonctionnalité VIP |
| `RATE_LIMITED` | Trop de requêtes |
| `VALIDATION_ERROR` | Données invalides |
| `RESOURCE_NOT_FOUND` | Ressource introuvable |
| `INTERNAL_ERROR` | Erreur serveur |
| `MAINTENANCE` | Maintenance en cours |

---

## 🛠️ DOCUMENTATION SWAGGER

URL : `https://api.footapp.com/api/documentation` (Phase 3 quand API publique)

Générer :
```bash
composer require darkaonline/l5-swagger
php artisan l5-swagger:generate
```

---

## 🧪 ENVIRONNEMENTS

| Env | Base URL |
|-----|----------|
| Local | `http://localhost:8000/api/v1` |
| Staging | `https://staging-api.footapp.com/api/v1` |
| Prod | `https://api.footapp.com/api/v1` |

---

## 📝 EXEMPLES cURL

### OTP send + verify

```bash
# Send
curl -X POST https://api.footapp.com/api/v1/auth/otp/send \
  -H "Content-Type: application/json" \
  -d '{"phone":"+221771234567"}'

# Verify
curl -X POST https://api.footapp.com/api/v1/auth/otp/verify \
  -H "Content-Type: application/json" \
  -d '{"phone":"+221771234567","code":"1234"}'
```

### Get today predictions

```bash
curl -X GET https://api.footapp.com/api/v1/predictions/today \
  -H "Authorization: Bearer xxx"
```

---

*API Endpoints documentés v1.0 | Phase 1 + 2*
