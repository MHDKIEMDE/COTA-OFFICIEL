# 🗄️ ANNEXE - Schéma Base de Données

> **Référence SQL complète** | Toutes les tables, relations, index, contraintes.

---

## 📊 VUE D'ENSEMBLE

### Tables Phase 1 (15 tables)

```
users (utilisateurs)
├── subscriptions (abonnements)
├── payments (paiements)
├── affiliations (tracking bookmakers)
├── referrals (parrainages)
├── feedbacks (support)
├── notifications_log (historique notifs)
└── user_preferences (préférences notifs/langue)

competitions (championnats)
├── teams (équipes)
└── matches (matchs)
    ├── predictions (pronostics)
    ├── combined_bets (combinés)
    └── match_statistics (cache stats)

promotions (codes promo bookmakers)
statistics (stats agrégées)
```

---

## 1️⃣ USERS

```sql
CREATE TABLE `users` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NULL UNIQUE,
    `email_verified_at` TIMESTAMP NULL,
    `password` VARCHAR(255) NULL,
    
    -- Auth phone/social
    `phone` VARCHAR(20) NULL UNIQUE,
    `country_code` VARCHAR(2) NULL,
    `facebook_id` VARCHAR(255) NULL UNIQUE,
    
    -- OTP
    `otp_code` VARCHAR(255) NULL,
    `otp_expires_at` TIMESTAMP NULL,
    `otp_attempts` INT NOT NULL DEFAULT 0,
    
    -- Premium
    `is_premium` BOOLEAN NOT NULL DEFAULT false,
    `subscription_type` VARCHAR(50) NULL,
    `subscription_expires_at` TIMESTAMP NULL,
    
    -- Référral
    `referral_code` VARCHAR(10) NULL UNIQUE,
    `referred_by` BIGINT UNSIGNED NULL,
    `referrals_count` INT NOT NULL DEFAULT 0,
    
    -- Bookmaker preference
    `preferred_bookmaker` VARCHAR(50) NULL,
    `bookmaker_account_id` VARCHAR(255) NULL,
    `bookmaker_selected_at` TIMESTAMP NULL,
    
    -- Métadonnées
    `language` VARCHAR(5) NOT NULL DEFAULT 'fr',
    `device_id` VARCHAR(255) NULL,
    `fcm_tokens` JSON NULL,
    `is_blocked` BOOLEAN NOT NULL DEFAULT false,
    `is_admin` BOOLEAN NOT NULL DEFAULT false,
    `last_login_at` TIMESTAMP NULL,
    
    -- Gamification (Phase 2)
    `xp` INT NOT NULL DEFAULT 0,
    `level` INT NOT NULL DEFAULT 1,
    `badges` JSON NULL,
    
    `remember_token` VARCHAR(100) NULL,
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    `deleted_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    
    INDEX `idx_premium_expires` (`is_premium`, `subscription_expires_at`),
    INDEX `idx_phone` (`phone`),
    INDEX `idx_referral_code` (`referral_code`),
    INDEX `idx_last_login` (`last_login_at`),
    
    FOREIGN KEY (`referred_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 2️⃣ COMPETITIONS

```sql
CREATE TABLE `competitions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `external_id` BIGINT NOT NULL UNIQUE, -- API-Football ID
    `name` VARCHAR(255) NOT NULL,
    `country` VARCHAR(255) NULL,
    `country_code` VARCHAR(2) NULL,
    `logo` TEXT NULL,
    `season` INT NOT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `tier` ENUM('top', 'standard', 'low') NOT NULL DEFAULT 'standard',
    `sport` VARCHAR(50) NOT NULL DEFAULT 'football', -- Phase 3
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_external_id` (`external_id`),
    INDEX `idx_active_tier` (`is_active`, `tier`)
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 3️⃣ TEAMS

```sql
CREATE TABLE `teams` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `external_id` BIGINT NOT NULL UNIQUE,
    `name` VARCHAR(255) NOT NULL,
    `code` VARCHAR(10) NULL,
    `logo` TEXT NULL,
    `country` VARCHAR(255) NULL,
    `founded` INT NULL,
    
    -- Stats agrégées (cache)
    `current_position` INT NULL,
    `current_form` VARCHAR(10) NULL, -- ex: "WWLDW"
    `total_matches_played` INT NULL,
    `wins` INT NULL,
    `draws` INT NULL,
    `losses` INT NULL,
    `goals_for` INT NULL,
    `goals_against` INT NULL,
    `clean_sheets_count` INT NULL,
    `home_wins_pct` DECIMAL(5,2) NULL,
    `away_wins_pct` DECIMAL(5,2) NULL,
    `last_stats_update` TIMESTAMP NULL,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_external_id` (`external_id`)
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 4️⃣ MATCHES

```sql
CREATE TABLE `matches` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `external_id` BIGINT NOT NULL UNIQUE,
    `competition_id` BIGINT UNSIGNED NOT NULL,
    `home_team_id` BIGINT UNSIGNED NOT NULL,
    `away_team_id` BIGINT UNSIGNED NOT NULL,
    
    `match_date` TIMESTAMP NOT NULL,
    `venue` VARCHAR(255) NULL,
    `referee` VARCHAR(255) NULL,
    
    -- Status
    `status` VARCHAR(20) NOT NULL DEFAULT 'NS', -- NS, 1H, HT, 2H, FT, AET, PEN, etc.
    `status_long` VARCHAR(255) NULL,
    `elapsed_minutes` INT NULL,
    
    -- Résultat
    `home_score` INT NULL,
    `away_score` INT NULL,
    `home_halftime_score` INT NULL,
    `away_halftime_score` INT NULL,
    
    -- Stats détaillées (JSON pour flexibilité)
    `match_stats` JSON NULL, -- possession, tirs, corners, etc.
    `xg_data` JSON NULL,     -- xG home/away (Phase 2)
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_external_id` (`external_id`),
    INDEX `idx_match_date` (`match_date`),
    INDEX `idx_status` (`status`),
    INDEX `idx_competition_date` (`competition_id`, `match_date`),
    
    FOREIGN KEY (`competition_id`) REFERENCES `competitions`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`home_team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`away_team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 5️⃣ PREDICTIONS

```sql
CREATE TABLE `predictions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `match_id` BIGINT UNSIGNED NOT NULL,
    
    -- Type de pari
    `bet_type` ENUM(
        'match_winner', 'over_under', 'btts',
        'double_chance', 'handicap', 'exact_score',
        'on_target', 'corners', 'first_half_winner'
    ) NOT NULL,
    `bet_choice` VARCHAR(50) NOT NULL, -- '1', 'X', '2', 'Over 2.5', 'BTTS_yes', etc.
    `odds` DECIMAL(5,2) NOT NULL,
    
    -- Scoring
    `confidence_score` DECIMAL(5,2) NOT NULL,
    `scoring_details` JSON NOT NULL, -- détail des 6 critères
    `analysis` TEXT NULL,
    `algorithm_version` VARCHAR(10) NOT NULL DEFAULT 'v3.0',
    
    -- Status
    `status` ENUM('pending', 'won', 'lost', 'void', 'cancelled') NOT NULL DEFAULT 'pending',
    `settled_at` TIMESTAMP NULL,
    
    -- Visibilité
    `is_premium_only` BOOLEAN NOT NULL DEFAULT false,
    `is_featured` BOOLEAN NOT NULL DEFAULT false,
    `is_published` BOOLEAN NOT NULL DEFAULT true,
    
    -- Affiliation tracking
    `bookmaker_links` JSON NULL,
    `clicks_count` INT NOT NULL DEFAULT 0,
    `views_count` INT NOT NULL DEFAULT 0,
    
    -- ML hybrid (Phase 2)
    `ml_score` DECIMAL(5,2) NULL,
    `ml_model_version` VARCHAR(50) NULL,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_status_created` (`status`, `created_at`),
    INDEX `idx_confidence` (`confidence_score`),
    INDEX `idx_premium_only` (`is_premium_only`),
    INDEX `idx_match_status` (`match_id`, `status`),
    
    FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 6️⃣ COMBINED_BETS

```sql
CREATE TABLE `combined_bets` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `date` DATE NOT NULL,
    `type` ENUM('daily_premium', 'welcome_bonus', 'vip') NOT NULL DEFAULT 'daily_premium',
    
    `prediction_ids` JSON NOT NULL, -- array of prediction IDs
    `total_odds` DECIMAL(8,2) NOT NULL,
    `confidence_avg` DECIMAL(5,2) NOT NULL,
    
    `is_premium_only` BOOLEAN NOT NULL DEFAULT true,
    `is_published` BOOLEAN NOT NULL DEFAULT true,
    
    -- Status (selon résultats des matchs)
    `status` ENUM('pending', 'won', 'lost', 'partial', 'void') NOT NULL DEFAULT 'pending',
    `settled_at` TIMESTAMP NULL,
    
    -- Carte à gratter
    `scratched_count` INT NOT NULL DEFAULT 0,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_date_type` (`date`, `type`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 7️⃣ SUBSCRIPTIONS

```sql
CREATE TABLE `subscriptions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `payment_id` BIGINT UNSIGNED NULL,
    
    `plan_type` ENUM('daily', 'weekly', 'monthly', 'quarterly', 'vip', 'affiliate_bonus') NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `currency` VARCHAR(3) NOT NULL DEFAULT 'XOF',
    
    `starts_at` TIMESTAMP NOT NULL,
    `expires_at` TIMESTAMP NOT NULL,
    
    `status` ENUM('active', 'expired', 'cancelled') NOT NULL DEFAULT 'active',
    `cancellation_reason` TEXT NULL,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_user_status` (`user_id`, `status`),
    INDEX `idx_expires` (`expires_at`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`payment_id`) REFERENCES `payments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 8️⃣ PAYMENTS

```sql
CREATE TABLE `payments` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    
    `gateway` ENUM('paydunya', 'stripe', 'wave', 'om', 'crypto') NOT NULL,
    `gateway_token` VARCHAR(255) NULL UNIQUE,
    `gateway_transaction_id` VARCHAR(255) NULL,
    
    `amount` DECIMAL(10,2) NOT NULL,
    `currency` VARCHAR(3) NOT NULL DEFAULT 'XOF',
    `plan_type` VARCHAR(50) NULL,
    
    `status` ENUM('pending', 'completed', 'failed', 'refunded', 'cancelled') NOT NULL DEFAULT 'pending',
    `paid_at` TIMESTAMP NULL,
    `failed_at` TIMESTAMP NULL,
    `failure_reason` TEXT NULL,
    
    `metadata` JSON NULL,
    `gateway_response` JSON NULL,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_user_status` (`user_id`, `status`),
    INDEX `idx_gateway_token` (`gateway_token`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 9️⃣ AFFILIATIONS

```sql
CREATE TABLE `affiliations` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    
    `bookmaker` ENUM('betwinner', '1xbet', 'melbet') NOT NULL,
    `tracking_id` VARCHAR(255) NOT NULL UNIQUE,
    `tracking_url` TEXT NOT NULL,
    
    -- Tracking événements
    `clicked_at` TIMESTAMP NULL,
    `signup_started_at` TIMESTAMP NULL,
    `signup_completed_at` TIMESTAMP NULL,
    `first_deposit_at` TIMESTAMP NULL,
    `first_deposit_amount` DECIMAL(10,2) NULL,
    
    -- Récompense
    `premium_granted` BOOLEAN NOT NULL DEFAULT false,
    `premium_granted_at` TIMESTAMP NULL,
    `premium_days_granted` INT NOT NULL DEFAULT 7,
    
    -- Commission
    `estimated_commission` DECIMAL(10,2) NULL,
    `commission_confirmed` BOOLEAN NOT NULL DEFAULT false,
    `metadata` JSON NULL,
    
    `status` ENUM('pending', 'clicked', 'registered', 'deposited', 'expired') NOT NULL DEFAULT 'pending',
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_user_status` (`user_id`, `status`),
    INDEX `idx_tracking_id` (`tracking_id`),
    INDEX `idx_bookmaker_status` (`bookmaker`, `status`),
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 🔟 PROMOTIONS

```sql
CREATE TABLE `promotions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `bookmaker` ENUM('betwinner', '1xbet', 'melbet') NOT NULL,
    `promo_code` VARCHAR(50) NOT NULL,
    `description` TEXT NOT NULL,
    
    `bonus_type` ENUM('first_deposit', 'free_bet', 'cashback', 'odds_boost') NOT NULL,
    `bonus_amount` DECIMAL(10,2) NULL,
    `bonus_percentage` INT NULL,
    `min_deposit` DECIMAL(10,2) NULL,
    `max_bonus` DECIMAL(10,2) NULL,
    `terms` TEXT NULL,
    
    `valid_from` TIMESTAMP NULL,
    `valid_until` TIMESTAMP NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `priority` INT NOT NULL DEFAULT 1,
    
    `targeting` JSON NULL, -- pays, langue, etc.
    
    -- Stats
    `views_count` INT NOT NULL DEFAULT 0,
    `clicks_count` INT NOT NULL DEFAULT 0,
    `conversions_count` INT NOT NULL DEFAULT 0,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    PRIMARY KEY (`id`),
    INDEX `idx_active_priority` (`is_active`, `priority`),
    INDEX `idx_bookmaker_active` (`bookmaker`, `is_active`)
) ENGINE=InnoDB CHARSET=utf8mb4;
```

---

## 1️⃣1️⃣ AUTRES TABLES (résumé)

### REFERRALS

```sql
CREATE TABLE `referrals` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `referrer_user_id` BIGINT UNSIGNED NOT NULL,
    `referred_user_id` BIGINT UNSIGNED NOT NULL,
    `referral_code` VARCHAR(20) NOT NULL,
    `status` ENUM('pending', 'confirmed', 'rewarded') NOT NULL DEFAULT 'pending',
    `reward_granted` BOOLEAN NOT NULL DEFAULT false,
    `reward_days` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NULL,
    
    INDEX `idx_referrer` (`referrer_user_id`),
    UNIQUE KEY `unique_referred` (`referred_user_id`),
    FOREIGN KEY (`referrer_user_id`) REFERENCES `users`(`id`),
    FOREIGN KEY (`referred_user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB;
```

### FEEDBACKS

```sql
CREATE TABLE `feedbacks` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `category` ENUM('bug', 'question', 'suggestion', 'other') NOT NULL,
    `description` TEXT NOT NULL,
    `screenshot_path` VARCHAR(500) NULL,
    `app_version` VARCHAR(20) NULL,
    `platform` VARCHAR(20) NULL,
    `status` ENUM('open', 'in_progress', 'resolved', 'closed') NOT NULL DEFAULT 'open',
    `admin_response` TEXT NULL,
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    INDEX `idx_user_status` (`user_id`, `status`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB;
```

### NOTIFICATIONS_LOG

```sql
CREATE TABLE `notifications_log` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `type` VARCHAR(100) NOT NULL,
    `title` VARCHAR(255) NULL,
    `body` TEXT NULL,
    `payload` JSON NULL,
    `delivery_status` ENUM('sent', 'delivered', 'failed', 'opened') NOT NULL DEFAULT 'sent',
    `sent_at` TIMESTAMP NOT NULL,
    `opened_at` TIMESTAMP NULL,
    
    INDEX `idx_user_sent` (`user_id`, `sent_at`),
    INDEX `idx_type_sent` (`type`, `sent_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;
```

### USER_PREFERENCES

```sql
CREATE TABLE `user_notification_preferences` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL UNIQUE,
    
    `push_enabled` BOOLEAN NOT NULL DEFAULT true,
    `email_enabled` BOOLEAN NOT NULL DEFAULT true,
    `sms_enabled` BOOLEAN NOT NULL DEFAULT false,
    
    `new_predictions` BOOLEAN NOT NULL DEFAULT true,
    `combined_daily` BOOLEAN NOT NULL DEFAULT true,
    `match_results` BOOLEAN NOT NULL DEFAULT true,
    `subscription_reminders` BOOLEAN NOT NULL DEFAULT true,
    `promotions` BOOLEAN NOT NULL DEFAULT true,
    `challenges_reminders` BOOLEAN NOT NULL DEFAULT true,
    `contest_announcements` BOOLEAN NOT NULL DEFAULT true,
    
    `preferred_competitions` JSON NULL,
    `preferred_bet_types` JSON NULL,
    `min_confidence_score` INT NOT NULL DEFAULT 60,
    
    `dnd_start` TIME NOT NULL DEFAULT '22:00:00',
    `dnd_end` TIME NOT NULL DEFAULT '07:00:00',
    `dnd_days` JSON NULL,
    
    `max_notifications_per_day` INT NOT NULL DEFAULT 5,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;
```

### STATISTICS (agrégations)

```sql
CREATE TABLE `statistics` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `date` DATE NOT NULL UNIQUE,
    
    `total_predictions` INT NOT NULL DEFAULT 0,
    `won_predictions` INT NOT NULL DEFAULT 0,
    `lost_predictions` INT NOT NULL DEFAULT 0,
    `void_predictions` INT NOT NULL DEFAULT 0,
    
    `win_rate` DECIMAL(5,2) NULL,
    `roi` DECIMAL(8,2) NULL,
    
    -- Par niveau confiance
    `stats_by_confidence` JSON NULL,
    
    -- Users
    `daily_active_users` INT NULL,
    `new_signups` INT NULL,
    `premium_active` INT NULL,
    
    -- Revenus
    `revenue_subscriptions` DECIMAL(12,2) NULL,
    `revenue_affiliations` DECIMAL(12,2) NULL,
    `total_revenue` DECIMAL(12,2) NULL,
    
    -- Performance
    `predictions_clicks` INT NULL,
    `auto_fill_attempts` INT NULL,
    `auto_fill_success_rate` DECIMAL(5,2) NULL,
    
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    INDEX `idx_date` (`date`)
) ENGINE=InnoDB;
```

### MATCH_STATISTICS_CACHE

```sql
CREATE TABLE `match_statistics_cache` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `match_id` BIGINT UNSIGNED NOT NULL UNIQUE,
    
    -- Pour le scoring
    `home_form_points` DECIMAL(5,2) NULL,
    `away_form_points` DECIMAL(5,2) NULL,
    `h2h_diff` INT NULL,
    `home_position` INT NULL,
    `away_position` INT NULL,
    `home_xg_avg` DECIMAL(5,2) NULL,
    `away_xg_avg` DECIMAL(5,2) NULL,
    `home_injuries_impact` DECIMAL(5,2) NULL,
    `away_injuries_impact` DECIMAL(5,2) NULL,
    `bookmaker_odds` JSON NULL,
    
    `last_calculated_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP NULL,
    
    FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;
```

---

## 🔍 INDEX RECOMMANDÉS POUR PERFORMANCE

```sql
-- Requêtes fréquentes
CREATE INDEX idx_predictions_today ON predictions(created_at, status);
CREATE INDEX idx_users_active_premium ON users(is_premium, last_login_at);
CREATE INDEX idx_payments_user_status_date ON payments(user_id, status, created_at);
CREATE INDEX idx_matches_today_status ON matches(match_date, status);

-- Pour le backtest
CREATE INDEX idx_predictions_status_settled ON predictions(status, settled_at);

-- Pour les jobs
CREATE INDEX idx_users_subscription_expiring ON users(is_premium, subscription_expires_at) WHERE is_premium = true;
```

---

## 📊 ESTIMATIONS VOLUMES

### Année 1 (estimation)

| Table | Lignes estimées |
|-------|-----------------|
| users | 5 000 |
| matches | 20 000 (saisons multiples) |
| predictions | 10 000 |
| combined_bets | 365 |
| subscriptions | 2 000 |
| payments | 3 000 |
| affiliations | 1 500 |
| notifications_log | 500 000 (TTL 90j) |

**Taille totale estimée** : ~500 MB → tient largement sur VPS.

### Année 3 (scale)

- ~50 000 users
- ~5M notifications_log → cleanup nécessaire
- ~50 000 predictions
- → Migration vers DB managed (DigitalOcean Managed MySQL)

---

## 🧹 MAINTENANCE

### Jobs de nettoyage

```sql
-- Nettoyer OTP expirés (toutes les 6h)
DELETE FROM users 
WHERE otp_code IS NOT NULL 
  AND otp_expires_at < NOW() - INTERVAL 1 DAY;

-- Nettoyer notifications anciennes (TTL 90j)
DELETE FROM notifications_log 
WHERE sent_at < NOW() - INTERVAL 90 DAY;

-- Cleanup paiements failed > 30j
UPDATE payments SET status = 'cancelled'
WHERE status = 'pending' AND created_at < NOW() - INTERVAL 30 DAY;
```

### Backup strategy

```bash
# Daily full backup
mysqldump --single-transaction --routines --triggers --all-databases \
  | gzip > /backups/footapp-$(date +%Y%m%d).sql.gz

# Upload S3
aws s3 cp /backups/ s3://footapp-backups/ --recursive
```

---

*Schéma SQL complet | Adapté pour Laravel 11 migrations*
