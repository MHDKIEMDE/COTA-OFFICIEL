# 🔐 SPRINT 02 - Authentification (OTP + Facebook)

> **Phase** : 1 - MVP | **Durée** : 1 semaine (25h) | **Priorité** : 🔴 CRITIQUE
> **Prérequis** : Sprint 01 terminé

---

## 🎯 OBJECTIF DU SPRINT

Implémenter le système d'authentification complet **sans mot de passe** :
- ✅ OTP par SMS (Twilio ou Termii)
- ✅ Login Facebook OAuth
- ✅ Génération tokens Sanctum
- ✅ Rate limiting anti-spam
- ✅ Code de parrainage à l'inscription
- ✅ Gestion device & FCM token

**Livrable final** : API d'auth complète, testée, prête à être consommée par Flutter.

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Setup Twilio/Termii pour SMS

#### Option A : Twilio (international)

```php
// config/services.php
'twilio' => [
    'sid' => env('TWILIO_SID'),
    'token' => env('TWILIO_TOKEN'),
    'from' => env('TWILIO_FROM'),
],
```

```php
// app/Services/Notification/SmsService.php
namespace App\Services\Notification;

use Twilio\Rest\Client;
use Illuminate\Support\Facades\Log;

class SmsService
{
    private Client $client;
    
    public function __construct()
    {
        $this->client = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );
    }
    
    public function sendOtp(string $phone, string $code): bool
    {
        try {
            $message = $this->client->messages->create($phone, [
                'from' => config('services.twilio.from'),
                'body' => "FootApp: Votre code de vérification est {$code}. Valable 5 minutes.",
            ]);
            
            Log::info('OTP sent', [
                'phone' => $phone,
                'sid' => $message->sid,
            ]);
            
            return true;
        } catch (\Exception $e) {
            Log::error('SMS failed', [
                'phone' => $phone,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }
}
```

#### Option B : Termii (Afrique, moins cher)

```php
// app/Services/Notification/TermiiSmsService.php
class TermiiSmsService
{
    private string $apiKey;
    private string $baseUrl = 'https://api.ng.termii.com/api/sms';
    
    public function __construct()
    {
        $this->apiKey = config('services.termii.key');
    }
    
    public function sendOtp(string $phone, string $code): bool
    {
        $response = Http::post($this->baseUrl . '/send', [
            'to' => $phone,
            'from' => 'FootApp',
            'sms' => "Votre code FootApp: {$code}",
            'type' => 'plain',
            'channel' => 'generic',
            'api_key' => $this->apiKey,
        ]);
        
        return $response->successful();
    }
}
```

> 💡 **Recommandation** : Termii pour Afrique (~0.02€/SMS), Twilio pour international (~0.05€/SMS).

---

### J2 (6h) - Système OTP

#### Migration table users (déjà fait Sprint 01)

Vérifier qu'on a :
- `phone` (unique)
- `otp_code` (hashé)
- `otp_expires_at`
- `otp_attempts`

#### Service OTP

```php
// app/Services/Auth/OtpService.php
namespace App\Services\Auth;

use App\Models\User;
use App\Services\Notification\SmsService;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cache;

class OtpService
{
    private const OTP_LENGTH = 4;
    private const OTP_VALIDITY_MINUTES = 5;
    private const MAX_ATTEMPTS = 3;
    private const RATE_LIMIT_KEY = 'otp_rate_limit:';
    
    public function __construct(
        private SmsService $smsService
    ) {}
    
    public function sendOtp(string $phone): array
    {
        // Rate limiting : max 1 SMS/minute par numéro
        $rateLimitKey = self::RATE_LIMIT_KEY . $phone;
        
        if (Cache::has($rateLimitKey)) {
            return [
                'success' => false,
                'message' => 'Veuillez attendre 1 minute avant de redemander un code',
            ];
        }
        
        // Générer code 4 chiffres
        $code = str_pad(random_int(0, 9999), self::OTP_LENGTH, '0', STR_PAD_LEFT);
        
        // Trouver ou créer user
        $user = User::firstOrCreate(
            ['phone' => $phone],
            [
                'name' => 'User_' . substr($phone, -4),
                'language' => 'fr',
            ]
        );
        
        // Sauvegarder OTP hashé
        $user->update([
            'otp_code' => Hash::make($code),
            'otp_expires_at' => now()->addMinutes(self::OTP_VALIDITY_MINUTES),
            'otp_attempts' => 0,
        ]);
        
        // Envoyer SMS
        $sent = $this->smsService->sendOtp($phone, $code);
        
        if ($sent) {
            // Activer rate limit
            Cache::put($rateLimitKey, true, 60);
            
            return [
                'success' => true,
                'message' => 'Code envoyé par SMS',
                'expires_in' => self::OTP_VALIDITY_MINUTES * 60,
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Erreur lors de l\'envoi du SMS',
        ];
    }
    
    public function verifyOtp(string $phone, string $code): array
    {
        $user = User::where('phone', $phone)->first();
        
        if (!$user || !$user->otp_code) {
            return [
                'success' => false,
                'message' => 'Aucun code en attente pour ce numéro',
            ];
        }
        
        // Vérifier expiration
        if ($user->otp_expires_at->isPast()) {
            return [
                'success' => false,
                'message' => 'Code expiré, veuillez en redemander un',
            ];
        }
        
        // Vérifier tentatives
        if ($user->otp_attempts >= self::MAX_ATTEMPTS) {
            return [
                'success' => false,
                'message' => 'Trop de tentatives, redemander un nouveau code',
            ];
        }
        
        // Vérifier le code
        if (!Hash::check($code, $user->otp_code)) {
            $user->increment('otp_attempts');
            
            return [
                'success' => false,
                'message' => 'Code incorrect',
                'attempts_left' => self::MAX_ATTEMPTS - $user->otp_attempts,
            ];
        }
        
        // Succès : nettoyer OTP + générer code parrainage si nouveau user
        $user->update([
            'otp_code' => null,
            'otp_expires_at' => null,
            'otp_attempts' => 0,
            'last_login_at' => now(),
        ]);
        
        if (!$user->referral_code) {
            $user->generateReferralCode();
        }
        
        // Générer token Sanctum
        $token = $user->createToken('mobile-app', ['*'], now()->addDays(30))->plainTextToken;
        
        return [
            'success' => true,
            'message' => 'Connexion réussie',
            'user' => $user->fresh(),
            'token' => $token,
        ];
    }
}
```

---

### J3 (4h) - Controllers & Routes

```bash
php artisan make:controller Api/V1/AuthController
```

```php
// app/Http/Controllers/Api/V1/AuthController.php
namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\Auth\OtpService;
use App\Services\Auth\FacebookAuthService;
use App\Http\Requests\Auth\SendOtpRequest;
use App\Http\Requests\Auth\VerifyOtpRequest;
use App\Http\Requests\Auth\FacebookLoginRequest;
use Illuminate\Http\JsonResponse;

class AuthController extends Controller
{
    public function __construct(
        private OtpService $otpService,
        private FacebookAuthService $facebookService
    ) {}
    
    public function sendOtp(SendOtpRequest $request): JsonResponse
    {
        $result = $this->otpService->sendOtp($request->phone);
        
        return response()->json($result, $result['success'] ? 200 : 422);
    }
    
    public function verifyOtp(VerifyOtpRequest $request): JsonResponse
    {
        $result = $this->otpService->verifyOtp(
            $request->phone,
            $request->code
        );
        
        if (!$result['success']) {
            return response()->json($result, 422);
        }
        
        return response()->json([
            'success' => true,
            'message' => $result['message'],
            'data' => [
                'user' => new UserResource($result['user']),
                'token' => $result['token'],
            ],
        ]);
    }
    
    public function facebookLogin(FacebookLoginRequest $request): JsonResponse
    {
        $result = $this->facebookService->loginWithToken($request->access_token);
        
        if (!$result['success']) {
            return response()->json($result, 422);
        }
        
        return response()->json($result);
    }
    
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();
        
        return response()->json([
            'success' => true,
            'message' => 'Déconnecté',
        ]);
    }
    
    public function me(Request $request): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => new UserResource($request->user()),
        ]);
    }
}
```

#### Form Requests (validation)

```bash
php artisan make:request Auth/SendOtpRequest
php artisan make:request Auth/VerifyOtpRequest
php artisan make:request Auth/FacebookLoginRequest
```

```php
// app/Http/Requests/Auth/SendOtpRequest.php
class SendOtpRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'phone' => [
                'required',
                'string',
                'regex:/^\+[1-9]\d{1,14}$/', // E.164 format
            ],
        ];
    }
    
    public function messages(): array
    {
        return [
            'phone.regex' => 'Format de numéro invalide. Utilisez le format international (+221...)',
        ];
    }
}
```

```php
// app/Http/Requests/Auth/VerifyOtpRequest.php
class VerifyOtpRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'phone' => 'required|string',
            'code' => 'required|string|size:4',
        ];
    }
}
```

#### Routes API

```php
// routes/api.php
use App\Http\Controllers\Api\V1\AuthController;

Route::prefix('v1')->group(function () {
    // Public
    Route::prefix('auth')->group(function () {
        Route::post('/send-otp', [AuthController::class, 'sendOtp'])
            ->middleware('throttle:5,1'); // 5 tentatives/minute
        
        Route::post('/verify-otp', [AuthController::class, 'verifyOtp'])
            ->middleware('throttle:10,1');
        
        Route::post('/facebook', [AuthController::class, 'facebookLogin'])
            ->middleware('throttle:5,1');
    });
    
    // Authenticated
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/auth/me', [AuthController::class, 'me']);
        Route::post('/auth/logout', [AuthController::class, 'logout']);
    });
});
```

---

### J4 (4h) - Facebook OAuth

#### Setup Laravel Socialite

```php
// config/services.php
'facebook' => [
    'client_id' => env('FACEBOOK_CLIENT_ID'),
    'client_secret' => env('FACEBOOK_CLIENT_SECRET'),
    'redirect' => env('FACEBOOK_REDIRECT_URI'),
],
```

#### Service Facebook

```php
// app/Services/Auth/FacebookAuthService.php
namespace App\Services\Auth;

use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class FacebookAuthService
{
    public function loginWithToken(string $accessToken): array
    {
        // Vérifier le token via Facebook Graph API
        $response = Http::get('https://graph.facebook.com/me', [
            'fields' => 'id,name,email',
            'access_token' => $accessToken,
        ]);
        
        if (!$response->successful()) {
            return [
                'success' => false,
                'message' => 'Token Facebook invalide',
            ];
        }
        
        $fbUser = $response->json();
        
        // Trouver ou créer user
        $user = User::firstOrCreate(
            ['facebook_id' => $fbUser['id']],
            [
                'name' => $fbUser['name'],
                'email' => $fbUser['email'] ?? null,
                'language' => 'fr',
            ]
        );
        
        // Générer code parrainage si nouveau
        if (!$user->referral_code) {
            $user->generateReferralCode();
        }
        
        $user->update(['last_login_at' => now()]);
        
        // Token Sanctum
        $token = $user->createToken('mobile-app', ['*'], now()->addDays(30))
            ->plainTextToken;
        
        return [
            'success' => true,
            'message' => 'Connexion Facebook réussie',
            'data' => [
                'user' => new UserResource($user),
                'token' => $token,
            ],
        ];
    }
}
```

---

### J5 (4h) - Resources & Tests

#### UserResource (transformer)

```bash
php artisan make:resource UserResource
```

```php
// app/Http/Resources/UserResource.php
class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'language' => $this->language,
            'is_premium' => $this->isPremiumActive(),
            'subscription' => [
                'type' => $this->subscription_type,
                'expires_at' => $this->subscription_expires_at,
                'days_left' => $this->subscription_expires_at?->diffInDays(now()),
            ],
            'referral' => [
                'code' => $this->referral_code,
                'count' => $this->referrals_count,
            ],
            'preferred_bookmaker' => $this->preferred_bookmaker,
            'created_at' => $this->created_at,
            'last_login_at' => $this->last_login_at,
        ];
    }
}
```

#### Tests Pest/PHPUnit

```php
// tests/Feature/Auth/OtpAuthTest.php
test('user can request OTP with valid phone', function () {
    $response = $this->postJson('/api/v1/auth/send-otp', [
        'phone' => '+221771234567',
    ]);
    
    $response->assertOk()
        ->assertJson([
            'success' => true,
        ]);
    
    $this->assertDatabaseHas('users', [
        'phone' => '+221771234567',
    ]);
});

test('OTP request fails with invalid phone format', function () {
    $response = $this->postJson('/api/v1/auth/send-otp', [
        'phone' => '0771234567', // sans +
    ]);
    
    $response->assertStatus(422);
});

test('user can verify OTP with correct code', function () {
    // Préparer
    $user = User::factory()->create([
        'phone' => '+221771234567',
        'otp_code' => Hash::make('1234'),
        'otp_expires_at' => now()->addMinutes(5),
    ]);
    
    $response = $this->postJson('/api/v1/auth/verify-otp', [
        'phone' => '+221771234567',
        'code' => '1234',
    ]);
    
    $response->assertOk()
        ->assertJsonStructure([
            'data' => [
                'user' => ['id', 'phone'],
                'token',
            ],
        ]);
});

test('OTP verification fails with wrong code', function () {
    User::factory()->create([
        'phone' => '+221771234567',
        'otp_code' => Hash::make('1234'),
        'otp_expires_at' => now()->addMinutes(5),
    ]);
    
    $response = $this->postJson('/api/v1/auth/verify-otp', [
        'phone' => '+221771234567',
        'code' => '9999',
    ]);
    
    $response->assertStatus(422);
});

test('OTP verification fails after 3 attempts', function () {
    $user = User::factory()->create([
        'phone' => '+221771234567',
        'otp_code' => Hash::make('1234'),
        'otp_expires_at' => now()->addMinutes(5),
        'otp_attempts' => 3,
    ]);
    
    $response = $this->postJson('/api/v1/auth/verify-otp', [
        'phone' => '+221771234567',
        'code' => '1234',
    ]);
    
    $response->assertStatus(422);
});
```

---

### J6 (3h) - Documentation API

Créer une **collection Postman** ou **OpenAPI/Swagger** :

```bash
# Installer Scribe (génération auto doc)
composer require --dev knuckleswtf/scribe
php artisan scribe:install
php artisan scribe:generate
```

Annoter les controllers :

```php
/**
 * Send OTP
 *
 * Envoie un code OTP à 4 chiffres par SMS au numéro fourni.
 * Rate limit: 1 SMS/minute par numéro.
 *
 * @bodyParam phone string required Numéro au format E.164. Example: +221771234567
 * 
 * @response 200 {
 *   "success": true,
 *   "message": "Code envoyé par SMS",
 *   "expires_in": 300
 * }
 */
public function sendOtp(SendOtpRequest $request): JsonResponse
```

---

## ✅ CRITÈRES DE VALIDATION SPRINT 02

- [ ] `POST /api/v1/auth/send-otp` envoie un SMS réel
- [ ] `POST /api/v1/auth/verify-otp` retourne un token Sanctum
- [ ] `POST /api/v1/auth/facebook` fonctionne avec un vrai token FB
- [ ] `GET /api/v1/auth/me` retourne l'utilisateur connecté
- [ ] `POST /api/v1/auth/logout` révoque le token
- [ ] Rate limiting 1 SMS/min vérifié
- [ ] Tests Pest passent à 100%
- [ ] Documentation Scribe générée
- [ ] CI GitHub Actions vert

---

## 🐛 PIÈGES À ÉVITER

### ❌ Stocker l'OTP en clair
**Solution** : toujours `Hash::make()` et `Hash::check()`.

### ❌ Pas de rate limiting
**Solution** : middleware `throttle:5,1` + cache Redis 60s.

### ❌ Token Sanctum sans expiration
**Solution** : `now()->addDays(30)` à la création.

### ❌ Numéros sans format E.164
**Solution** : validation regex stricte côté backend ET frontend.

### ❌ OTP de 6 chiffres trop long
**Solution** : 4 chiffres = équilibre sécurité/UX (sur mobile).

---

## 🎓 PROMPTS IA UTILES

```
"Génère un service Laravel pour envoyer des OTP par SMS via Twilio,
avec rate limiting Redis, hash bcrypt, et expiration 5 minutes."

"Crée des tests Pest pour tester l'auth OTP avec : 
- envoi OTP
- vérification correcte
- code expiré  
- 3 tentatives max
- rate limiting"

"Configure Laravel Socialite pour Facebook OAuth en API mode 
(sans redirect, juste validation de token)."
```

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Setup Twilio/Termii | 4h |
| Service OTP | 6h |
| Controllers + Routes | 4h |
| Facebook OAuth | 4h |
| Tests + Documentation | 7h |
| **TOTAL** | **25h** |

> **Réaliste à 30h/semaine** : 1 semaine ✅

---

## 🔗 PROCHAINE ÉTAPE

✅ **Sprint 02 terminé** → Démarrer `SPRINT-03-Algorithme-v3.md` (LE PLUS IMPORTANT)

---

*Auth = base de tout. Faite proprement = pas de problèmes plus tard.*
