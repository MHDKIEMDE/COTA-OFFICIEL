# 🔬 SPRINT 04 - Multi-Sources Données + ML Basique

> **Phase** : 1 - MVP | **Durée** : 2 semaines (60h) | **Priorité** : 🟠 IMPORTANT
> **Prérequis** : Sprint 03 validé (win rate ≥ 55%)

---

## 🎯 OBJECTIF DU SPRINT

Améliorer l'algorithme avec :
- ✅ Données xG (Expected Goals) via SofaScore/Understat
- ✅ Données blessures importantes
- ✅ Cotes des bookmakers (intégration en critère bonus)
- ✅ Microservice Python ML basique (régression logistique)
- ✅ Pipeline d'entraînement automatique
- ✅ A/B testing : algo statique vs ML

**Livrable final** : Algorithme enrichi capable d'atteindre 58-62% sur les pronostics de haute confiance.

---

## ⚠️ NOTE IMPORTANTE

Si le Sprint 03 a atteint > 60% sans ML, **ce sprint peut être reporté en Phase 2**. Le ROI temps/gain est faible si l'algo statique fonctionne déjà bien.

**Décision** : ne lancer ce sprint QUE si win rate < 60% au sprint 03.

---

## 📋 TÂCHES DÉTAILLÉES

### Semaine 1 - Sources de données enrichies

#### J1 (6h) - Scraping SofaScore (xG)

> ⚠️ SofaScore n'a pas d'API publique gratuite. Solutions :
> 1. Scraping (légalement gris, fragile)
> 2. API payante (Sportmonks ~50€/mois)
> 3. Understat (gratuit mais limité Top 5)

**Recommandation MVP** : utiliser **Understat** (gratuit, limité aux Top 5 EU).

```php
// app/Services/External/UnderstatService.php
namespace App\Services\External;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

class UnderstatService
{
    private string $baseUrl = 'https://understat.com';
    
    /**
     * Récupère les xG d'un match
     */
    public function getMatchXG(int $understatMatchId): ?array
    {
        return Cache::remember(
            "understat:match:{$understatMatchId}",
            now()->addDays(1),
            function() use ($understatMatchId) {
                $response = Http::get("{$this->baseUrl}/match/{$understatMatchId}");
                
                if (!$response->successful()) return null;
                
                // Parse HTML pour extraire le JSON embarqué
                preg_match('/var match_info\s*=\s*JSON\.parse\(\'(.+?)\'\)/', $response->body(), $matches);
                
                if (empty($matches[1])) return null;
                
                $data = json_decode(stripslashes($matches[1]), true);
                
                return [
                    'home_xg' => (float) $data['xG']['h'],
                    'away_xg' => (float) $data['xG']['a'],
                    'home_shots' => (int) $data['shots']['h'],
                    'away_shots' => (int) $data['shots']['a'],
                ];
            }
        );
    }
    
    /**
     * Stats xG d'une équipe sur la saison
     */
    public function getTeamSeasonXG(string $teamSlug, int $season): ?array
    {
        return Cache::remember(
            "understat:team:{$teamSlug}:{$season}",
            now()->addDays(1),
            function() use ($teamSlug, $season) {
                $response = Http::get("{$this->baseUrl}/team/{$teamSlug}/{$season}");
                
                if (!$response->successful()) return null;
                
                preg_match('/var statisticsData\s*=\s*JSON\.parse\(\'(.+?)\'\)/', $response->body(), $matches);
                
                if (empty($matches[1])) return null;
                
                return json_decode(stripslashes($matches[1]), true);
            }
        );
    }
}
```

#### J2 (4h) - Données blessures

API-Football a un endpoint `/injuries` (plan Standard) :

```php
// app/Services/External/InjuriesService.php
class InjuriesService
{
    public function __construct(private ApiFootballService $apiService) {}
    
    public function getTeamInjuries(int $teamId, int $leagueId): array
    {
        return Cache::remember(
            "injuries:team:{$teamId}",
            now()->addHours(6),
            fn() => $this->apiService->callApi('/injuries', [
                'team' => $teamId,
                'league' => $leagueId,
                'season' => now()->year,
            ])
        );
    }
    
    /**
     * Calcule un "score d'absences" (joueurs clés blessés)
     */
    public function calculateInjuryImpact(int $teamId, int $leagueId): float
    {
        $injuries = $this->getTeamInjuries($teamId, $leagueId);
        
        // Score basé sur position des blessés
        $impact = 0;
        foreach ($injuries as $injury) {
            $position = $injury['player']['position'] ?? 'Unknown';
            $impact += match($position) {
                'Goalkeeper' => 3,
                'Defender' => 2,
                'Midfielder' => 2.5,
                'Attacker' => 3,
                default => 1,
            };
        }
        
        return min(10, $impact); // Cap à 10
    }
}
```

#### J3 (4h) - Intégration cotes bookmakers

```php
// app/Services/External/OddsService.php
class OddsService
{
    public function getMatchOdds(int $matchExternalId): ?array
    {
        return Cache::remember(
            "odds:match:{$matchExternalId}",
            now()->addHours(2),
            fn() => $this->apiService->callApi('/odds', [
                'fixture' => $matchExternalId,
                'bookmaker' => '8', // Bet365 (référence)
                'bet' => '1', // Match Winner
            ])
        );
    }
    
    /**
     * Détecte si les cotes du bookmaker confirment notre prédiction
     */
    public function validateWithMarketOdds(FootballMatch $match, string $ourPrediction): array
    {
        $odds = $this->getMatchOdds($match->external_id);
        
        if (!$odds) return ['agreement' => 'unknown'];
        
        // Probabilités implicites depuis cotes
        $homeOdds = $odds['home'];
        $drawOdds = $odds['draw'];
        $awayOdds = $odds['away'];
        
        $homeProba = 1 / $homeOdds;
        $drawProba = 1 / $drawOdds;
        $awayProba = 1 / $awayOdds;
        
        $marketFavorite = match (true) {
            $homeProba > $drawProba && $homeProba > $awayProba => '1',
            $drawProba > $homeProba && $drawProba > $awayProba => 'X',
            default => '2',
        };
        
        return [
            'market_favorite' => $marketFavorite,
            'agreement' => $marketFavorite === $ourPrediction,
            'odds' => $odds,
            'implicit_proba' => [
                '1' => round($homeProba * 100, 2),
                'X' => round($drawProba * 100, 2),
                '2' => round($awayProba * 100, 2),
            ],
        ];
    }
}
```

#### J4-J5 (12h) - Nouveau critère xG + Refactor algorithme

**Ajouter un critère xG (10 points additionnels)** :

```php
// app/Services/Algorithm/Criteria/ExpectedGoalsCriterion.php
class ExpectedGoalsCriterion
{
    private const WEIGHT = 10;
    
    public function calculate(Team $homeTeam, Team $awayTeam): array
    {
        $homeXG = $this->getTeamAvgXG($homeTeam);
        $awayXG = $this->getTeamAvgXG($awayTeam);
        
        if ($homeXG === null || $awayXG === null) {
            return ['score' => 0, 'reason' => 'No xG data'];
        }
        
        // Différentiel xG
        $xgDiff = $homeXG['xg_for'] - $awayXG['xg_for'];
        $xgaDiff = $awayXG['xg_against'] - $homeXG['xg_against'];
        
        $score = (($xgDiff + $xgaDiff) / 4) * self::WEIGHT;
        $score = max(-self::WEIGHT, min(self::WEIGHT, $score));
        
        return [
            'score' => round($score, 2),
            'home_xg' => $homeXG,
            'away_xg' => $awayXG,
        ];
    }
}
```

**Mise à jour pondérations** (avec critère xG) :

| Critère | Ancien poids | Nouveau poids |
|---------|--------------|---------------|
| Forme récente | 28% | 25% |
| H2H | 23% | 20% |
| Dom/Ext | 18% | 15% |
| Classement | 13% | 10% |
| Stats buts | 10% | 8% |
| Horaire | 8% | 6% |
| **xG (NEW)** | - | **10%** |
| **Blessures (NEW)** | - | **6%** |
| **TOTAL** | **100%** | **100%** |

---

### Semaine 2 - Microservice Python ML

#### J6-J7 (12h) - Setup FastAPI + Modèle de base

```bash
# Sur le VPS, créer le service ML
mkdir /opt/ml-service && cd /opt/ml-service
python3.11 -m venv venv
source venv/bin/activate
pip install fastapi uvicorn scikit-learn pandas numpy joblib redis pymysql
```

```python
# /opt/ml-service/app/main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import pandas as pd
import os

app = FastAPI(title="FootApp ML Service")

# Charger modèle au démarrage
MODEL_PATH = os.getenv("MODEL_PATH", "trained_models/predictor_v1.pkl")
model = None

@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
        print(f"Model loaded from {MODEL_PATH}")
    else:
        print("⚠️ No model found, using fallback")

class MatchFeatures(BaseModel):
    home_form_points: float
    away_form_points: float
    h2h_diff: float
    home_position: int
    away_position: int
    home_xg_avg: float
    away_xg_avg: float
    match_hour: int
    home_injuries_impact: float
    away_injuries_impact: float

class PredictionResponse(BaseModel):
    win_proba_home: float
    win_proba_draw: float
    win_proba_away: float
    confidence: float
    recommended_bet: str

@app.post("/predict", response_model=PredictionResponse)
async def predict(features: MatchFeatures):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    df = pd.DataFrame([features.dict()])
    probas = model.predict_proba(df)[0]
    
    confidence = max(probas) * 100
    bet_idx = probas.argmax()
    bet_map = {0: '1', 1: 'X', 2: '2'}
    
    return PredictionResponse(
        win_proba_home=float(probas[0]),
        win_proba_draw=float(probas[1]),
        win_proba_away=float(probas[2]),
        confidence=float(confidence),
        recommended_bet=bet_map[bet_idx]
    )

@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": model is not None}
```

#### J8 (6h) - Pipeline entraînement

```python
# /opt/ml-service/app/trainer.py
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, classification_report
import joblib
import pymysql
import os

def load_training_data():
    """Charge les matchs historiques depuis MySQL."""
    conn = pymysql.connect(
        host=os.getenv("DB_HOST"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
    )
    
    query = """
    SELECT 
        m.id, m.match_date, m.home_score, m.away_score,
        ms.home_form_points, ms.away_form_points,
        ms.h2h_diff, ms.home_position, ms.away_position,
        ms.home_xg_avg, ms.away_xg_avg,
        HOUR(m.match_date) as match_hour,
        ms.home_injuries_impact, ms.away_injuries_impact
    FROM matches m
    INNER JOIN match_statistics ms ON ms.match_id = m.id
    WHERE m.status = 'FT'
      AND m.match_date >= '2023-01-01'
    """
    
    df = pd.read_sql(query, conn)
    conn.close()
    
    # Calcul de la cible (résultat)
    df['result'] = df.apply(lambda r: 
        0 if r['home_score'] > r['away_score'] else
        1 if r['home_score'] == r['away_score'] else
        2, axis=1
    )
    
    return df

def train():
    print("Loading data...")
    df = load_training_data()
    print(f"Loaded {len(df)} matches")
    
    features = [
        'home_form_points', 'away_form_points', 'h2h_diff',
        'home_position', 'away_position',
        'home_xg_avg', 'away_xg_avg',
        'match_hour', 'home_injuries_impact', 'away_injuries_impact'
    ]
    
    X = df[features]
    y = df['result']
    
    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # Modèle 1 : Régression logistique
    print("\n=== Logistic Regression ===")
    lr = LogisticRegression(max_iter=1000, multi_class='multinomial')
    lr.fit(X_train, y_train)
    lr_score = lr.score(X_test, y_test)
    print(f"Accuracy: {lr_score:.4f}")
    
    # Modèle 2 : Random Forest
    print("\n=== Random Forest ===")
    rf = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
    rf.fit(X_train, y_train)
    rf_score = rf.score(X_test, y_test)
    print(f"Accuracy: {rf_score:.4f}")
    
    # Choisir le meilleur
    best_model = rf if rf_score > lr_score else lr
    best_name = "RandomForest" if rf_score > lr_score else "LogisticRegression"
    print(f"\n✅ Best model: {best_name}")
    
    # Cross-validation
    cv_scores = cross_val_score(best_model, X, y, cv=5)
    print(f"CV Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
    
    # Classification report
    y_pred = best_model.predict(X_test)
    print("\n", classification_report(y_test, y_pred, target_names=['Home Win', 'Draw', 'Away Win']))
    
    # Sauvegarder
    os.makedirs('trained_models', exist_ok=True)
    joblib.dump(best_model, 'trained_models/predictor_v1.pkl')
    print("✅ Model saved")

if __name__ == "__main__":
    train()
```

#### J9 (4h) - Wrapper PHP côté Laravel

```php
// app/Services/ML/MlPredictionService.php
namespace App\Services\ML;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

class MlPredictionService
{
    private string $mlServiceUrl;
    
    public function __construct()
    {
        $this->mlServiceUrl = config('services.ml.url', 'http://localhost:8001');
    }
    
    public function predict(array $features): ?array
    {
        try {
            $response = Http::timeout(5)
                ->post("{$this->mlServiceUrl}/predict", $features);
            
            if (!$response->successful()) {
                \Log::warning('ML service prediction failed');
                return null;
            }
            
            return $response->json();
        } catch (\Exception $e) {
            \Log::error('ML service unreachable', ['error' => $e->getMessage()]);
            return null;
        }
    }
    
    public function isHealthy(): bool
    {
        return Cache::remember('ml-service:health', 60, function() {
            try {
                $response = Http::timeout(2)->get("{$this->mlServiceUrl}/health");
                return $response->successful() && $response->json('model_loaded') === true;
            } catch (\Exception) {
                return false;
            }
        });
    }
}
```

#### J10 (4h) - A/B testing : Statique vs ML

```php
// app/Services/Algorithm/HybridScoringService.php
class HybridScoringService
{
    public function calculate(FootballMatch $match): array
    {
        // Score statique (toujours)
        $staticResult = $this->staticScoringService->calculateScore($match);
        
        // Score ML (si dispo)
        $mlResult = null;
        if ($this->mlService->isHealthy()) {
            $features = $this->extractFeatures($match);
            $mlResult = $this->mlService->predict($features);
        }
        
        // Stratégie : moyenne pondérée si les 2 disponibles
        if ($mlResult) {
            $finalScore = ($staticResult['total_score'] * 0.6) + ($mlResult['confidence'] * 0.4);
            $source = 'hybrid';
        } else {
            $finalScore = $staticResult['total_score'];
            $source = 'static';
        }
        
        // Log pour A/B analyse
        \Log::info('Prediction generated', [
            'match_id' => $match->id,
            'static_score' => $staticResult['total_score'],
            'ml_score' => $mlResult['confidence'] ?? null,
            'final_score' => $finalScore,
            'source' => $source,
        ]);
        
        return [
            'total_score' => $finalScore,
            'static_details' => $staticResult,
            'ml_details' => $mlResult,
            'source' => $source,
        ];
    }
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Service Understat fonctionnel pour Top 5 EU
- [ ] Données blessures intégrées
- [ ] Cotes bookmakers récupérées
- [ ] Microservice Python ML déployé sur VPS
- [ ] Modèle entraîné sur 2+ saisons (Random Forest ou Logistic)
- [ ] Communication Laravel ↔ Python OK
- [ ] Hybrid scoring (statique + ML) opérationnel
- [ ] Backtest avec ML montre gain de 3-5% vs statique seul

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Sources données enrichies | 16h |
| Critère xG + Refactor | 12h |
| Setup ML Python | 12h |
| Pipeline entraînement | 8h |
| Wrapper PHP + A/B | 8h |
| Tests | 4h |
| **TOTAL** | **60h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ Sprint 04 → `SPRINT-05-Paiements.md`
