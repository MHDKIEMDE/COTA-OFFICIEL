# 🚀 SPRINT 10 - Tests + Déploiement + Beta Launch

> **Phase** : 1 - MVP | **Durée** : 1 semaine (30h) | **Priorité** : 🔴 CRITIQUE
> **Prérequis** : Sprints 01-09 terminés

---

## 🎯 OBJECTIF DU SPRINT

Préparer le lancement public :
- ✅ Tests E2E complets (backend + mobile)
- ✅ Tests sur 5+ devices Android physiques
- ✅ Optimisations performance
- ✅ Build APK release signé
- ✅ Soumission Google Play (Beta)
- ✅ Recrutement 20 beta testeurs
- ✅ Documentation utilisateur (FAQ)

**Livrable final** : APK installable, 20 testeurs en beta, premiers retours.

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Tests Backend

```bash
# Coverage tests
php artisan test --coverage --min=70
```

**Tests critiques à vérifier** :

```bash
tests/
├── Feature/
│   ├── Auth/
│   │   ├── OtpAuthTest.php          ✓ (Sprint 02)
│   │   ├── FacebookAuthTest.php
│   │   └── LogoutTest.php
│   ├── Algorithm/
│   │   ├── PredictionScoringTest.php  ✓ (Sprint 03)
│   │   └── BacktestTest.php
│   ├── Payment/
│   │   ├── PaydunyaPaymentTest.php
│   │   ├── StripePaymentTest.php
│   │   └── WebhookTest.php
│   ├── Subscription/
│   │   └── ActivationTest.php
│   ├── Affiliation/
│   │   ├── TrackingTest.php
│   │   └── BonusGrantTest.php
│   └── Api/
│       ├── PredictionsApiTest.php
│       └── ProfileApiTest.php
└── Unit/
    ├── Services/
    └── Models/
```

**Test E2E paiement complet** :

```php
test('complete subscription flow', function () {
    // 1. User crée checkout
    $user = User::factory()->create();
    
    $response = $this->actingAs($user, 'sanctum')
        ->postJson('/api/v1/payments/checkout', [
            'plan_type' => 'monthly',
            'gateway' => 'paydunya',
        ]);
    
    $response->assertOk();
    $token = $response->json('data.token');
    
    // 2. Simuler webhook
    Http::fake([
        '*paydunya*' => Http::response([
            'status' => 'completed',
            'invoice' => ['token' => $token],
        ]),
    ]);
    
    $this->postJson('/webhooks/paydunya', [
        'data' => ['invoice' => ['token' => $token]],
    ]);
    
    // 3. Vérifier user devient premium
    $user->refresh();
    expect($user->is_premium)->toBeTrue();
    expect($user->subscription_expires_at)->toBeAfter(now()->addDays(29));
});
```

### J2 (4h) - Tests Mobile

```bash
# Tests Flutter
flutter test
flutter test --coverage

# Tests E2E (integration)
flutter test integration_test/
```

**Tests prioritaires** :

```dart
// integration_test/auth_flow_test.dart
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  
  testWidgets('Complete login flow OTP', (tester) async {
    app.main();
    await tester.pumpAndSettle();
    
    // Skip onboarding
    await tester.tap(find.text('Passer'));
    await tester.pumpAndSettle();
    
    // Saisir téléphone
    await tester.enterText(find.byType(TextField), '771234567');
    await tester.tap(find.text('Recevoir le code'));
    await tester.pumpAndSettle();
    
    // Saisir OTP (mock backend)
    expect(find.text('Code de vérification'), findsOneWidget);
    
    await tester.enterText(find.byKey(const Key('otp_input')), '1234');
    await tester.tap(find.text('Valider'));
    await tester.pumpAndSettle();
    
    // Vérifier dashboard
    expect(find.text('Pronostics du jour'), findsOneWidget);
  });
}
```

### J3 (4h) - Optimisations Performance

**Backend** :

```bash
# Cache config + routes pour prod
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan event:cache

# Optimize composer
composer install --optimize-autoloader --no-dev
```

**Optimisations BDD** :

```sql
-- Vérifier index
SHOW INDEX FROM predictions;
SHOW INDEX FROM users;

-- Analyser slow queries
SET GLOBAL slow_query_log = 'ON';
SET GLOBAL long_query_time = 1;
```

**Mobile** :

```dart
// pubspec.yaml - exclure debug
flutter:
  uses-material-design: true
  generate: true

# Build optimisé
flutter build apk --release --shrink --tree-shake-icons --split-per-abi
```

**Vérifier taille APK** : doit être < 30 MB.

### J4 (6h) - Tests Devices Physiques

**Liste devices à tester** :

| Device | OS | RAM | Type |
|--------|-----|-----|------|
| Tecno Spark 8C | Android 11 | 2GB | Low-end |
| Samsung A12 | Android 12 | 4GB | Mid-range |
| Xiaomi Redmi Note 10 | Android 13 | 6GB | Mid-range |
| Samsung S22 (ami) | Android 14 | 8GB | High-end |
| iPhone 13 (test) | iOS 17 | 6GB | iOS |

**Checklist par device** :

- [ ] App installe sans erreur
- [ ] Onboarding fluide
- [ ] OTP reçu < 10 secondes
- [ ] Dashboard charge < 2 secondes
- [ ] Scroll fluide (60fps)
- [ ] Carte à gratter responsive
- [ ] WebView paiement fonctionne
- [ ] WebView auto-fill fonctionne
- [ ] Notifications push reçues
- [ ] Pas de crash sur 30 min d'utilisation

### J5 (4h) - Build Release + Soumission Play Store

**Signature APK Android** :

```bash
# Générer keystore (1 seule fois)
keytool -genkey -v -keystore ~/footapp-release-key.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias footapp

# Configurer android/key.properties
storePassword=xxx
keyPassword=xxx
keyAlias=footapp
storeFile=/Users/xxx/footapp-release-key.keystore
```

```gradle
// android/app/build.gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
        }
    }
}
```

```bash
# Build APK signé
flutter build apk --release

# Bundle (pour Play Store, recommandé)
flutter build appbundle --release
```

**Soumission Google Play** :

1. Aller sur https://play.google.com/console
2. Créer une nouvelle application
3. Remplir :
   - **Nom** : FootApp - Pronostics IA
   - **Catégorie** : Sports
   - **Description courte** : "Pronostics football automatisés par IA"
   - **Description complète** : (positionnement "data analytics")
   - **Screenshots** (8 minimum, 1080x1920)
   - **Icône** (512x512)
   - **Bannière** (1024x500)
   - **Pays** : Sénégal, Côte d'Ivoire, Burkina, Mali (Phase 1)
   - **Politique confidentialité** : URL obligatoire
   - **Audience cible** : 18+
4. Uploader le `.aab` (App Bundle)
5. Soumettre en **piste de test fermée** (pas de production directe)

**⚠️ Précautions Play Store** :

- Pas mentionner "betting" ou "paris" dans la description (utilise "data analytics", "statistiques sportives")
- Disclaimer fort dans la description
- Ne pas inclure de bouton "Parier" trop visible dans les screenshots

### J6 (4h) - Recrutement Beta Testeurs

**Sources de recrutement (20 testeurs)** :

| Source | Nombre cible | Méthode |
|--------|--------------|---------|
| Famille/amis | 5 | Direct |
| Groupes WhatsApp foot | 5 | Annonce avec QR code |
| Telegram (canaux paris) | 5 | Post avec lien |
| Twitter/X | 3 | Post + DM |
| LinkedIn (réseau pro) | 2 | DM |

**Message d'invitation** :

```
🎯 [BETA TEST] FootApp - Pronostics Football IA

Salut ! Je lance une nouvelle app de pronostics 
football basée sur l'IA, et je cherche 20 beta 
testeurs pour la prochaine semaine.

Ce que tu obtiens :
✅ 1 mois Premium GRATUIT (valeur 8000 FCFA)
✅ Accès en avant-première
✅ Influence sur les features finales

Ce que je te demande :
📱 Tester l'app (15-30 min/jour)
💬 Partager tes retours (form Google ~5 min)
🐛 Signaler les bugs

Lien APK : [Google Play test track]
Group WhatsApp Beta : [lien]

Intéressé(e) ? Réponds OUI 🚀
```

**Setup groupe Beta** :
- WhatsApp Group "FootApp Beta Testers"
- Form Google Forms pour feedback structuré
- Lien APK direct (Play Store closed test)

### J7 (4h) - Documentation Utilisateur + Lancement

**FAQ in-app** (8 questions essentielles) :

1. **Comment fonctionne l'algorithme ?**
   "Notre IA analyse 6 critères (forme, H2H, etc.) pour générer des pronostics avec un score de confiance 0-100."

2. **Que signifient les étoiles de confiance ?**
   "⭐ Faible (50-59), ⭐⭐ Moyenne (60-69), ⭐⭐⭐ Élevée (70-84), ⭐⭐⭐⭐ Très élevée (85+)"

3. **Qu'est-ce que BTTS, Over/Under, Double Chance ?**
   "BTTS = Both Teams To Score (les 2 équipes marquent)..."

4. **Comment obtenir 7 jours gratuits ?**
   "Inscris-toi sur un de nos bookmakers partenaires via le lien dans l'app."

5. **Comment renouveler mon abonnement ?**
   "Va dans Profil > Mon abonnement > Renouveler"

6. **Les pronostics sont-ils garantis gagnants ?**
   "AUCUN pronostic n'est garanti. Notre algo a un taux de réussite de 55-60% en moyenne."

7. **Puis-je annuler mon abonnement ?**
   "Pas d'auto-renewal en Phase 1. Aucune annulation requise."

8. **Comment contacter le support ?**
   "Profil > Aide > Signaler un problème, ou support@mhdservice.com"

**CGU + Politique confidentialité** : à rédiger avec un avocat.

**Disclaimer in-app** (visible permanent) :

```
⚠️ AVERTISSEMENT
Les pronostics sont générés par algorithme statistique.
AUCUNE GARANTIE DE GAIN.
Les paris sportifs comportent des risques financiers.
🔞 Interdit aux moins de 18 ans
⚖️ Jouez avec modération
```

---

## ✅ CRITÈRES DE VALIDATION SPRINT 10

- [ ] Tests backend coverage > 70%
- [ ] Tests Flutter coverage > 50%
- [ ] APK testé sur 5+ devices physiques
- [ ] Aucun crash bloquant
- [ ] Performance OK (chargement < 2s)
- [ ] APK signé et < 30 MB
- [ ] Bundle uploadé sur Play Store (closed test)
- [ ] 20 beta testeurs recrutés
- [ ] FAQ in-app + CGU/Politique en ligne
- [ ] Disclaimer présent partout
- [ ] Email support@mhdservice.com actif
- [ ] Channel WhatsApp Beta créé

---

## 🎉 LAUNCH CHECKLIST

### Avant J0 (lancement)

- [ ] Backend en production
- [ ] APK validé par Google (1-3 jours)
- [ ] 20 beta users prêts
- [ ] Réseaux sociaux préparés (3 posts d'annonce)
- [ ] Email/SMS d'annonce rédigé
- [ ] Plan de communication (1 semaine de teasing)

### Jour J

- [ ] Annoncer sur WhatsApp/Facebook/Twitter
- [ ] Envoyer lien APK aux beta testeurs
- [ ] Monitor Sentry (alerte si > 5 errors/h)
- [ ] Répondre aux questions/bugs en direct

### J+1 à J+7

- [ ] Mesurer KPIs quotidiens (DAU, conversion, win rate)
- [ ] Recueillir feedback (form Google)
- [ ] Patcher bugs critiques
- [ ] Itérer sur les retours

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Tests backend | 4h |
| Tests mobile | 4h |
| Optimisations | 4h |
| Tests devices physiques | 6h |
| Build + Play Store | 4h |
| Recrutement beta | 4h |
| Doc utilisateur + Launch | 4h |
| **TOTAL** | **30h** |

---

## 🎯 OBJECTIFS POST-LAUNCH (Mois 4)

- [ ] 50 utilisateurs actifs (beta + organique)
- [ ] 5 abonnements payants
- [ ] 1 inscription bookmaker
- [ ] Win rate confirmé sur données live
- [ ] NPS > 30 sur les beta

---

## 🔗 SUITE

✅ **Phase 1 MVP TERMINÉE !** 🎉

→ `PHASE-2-GROWTH/MODULE-Gamification.md` (croissance)
→ `PHASE-2-GROWTH/MODULE-Site-Web-SEO.md`
→ etc.

**Avant de commencer Phase 2** : avoir 100+ utilisateurs et au moins 500€ MRR.

---

*Le MVP est un commencement, pas une fin. Itérer, mesurer, améliorer.*
