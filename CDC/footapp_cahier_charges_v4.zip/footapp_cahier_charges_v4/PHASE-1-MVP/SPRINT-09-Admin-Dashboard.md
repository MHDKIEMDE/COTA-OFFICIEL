# 🎛️ SPRINT 09 - Dashboard Admin (Filament)

> **Phase** : 1 - MVP | **Durée** : 1 semaine (30h) | **Priorité** : 🟠 IMPORTANT
> **Prérequis** : Sprints 01-08 terminés

---

## 🎯 OBJECTIF DU SPRINT

Construire un dashboard admin complet avec **Laravel Filament 3** pour :
- ✅ Gérer les pronostics (override manuel, validation résultats)
- ✅ Suivre les utilisateurs (premium, blocages, communications)
- ✅ Suivre les paiements et abonnements
- ✅ Suivre les conversions affiliation
- ✅ Gérer les promotions/codes promo
- ✅ Voir les KPIs en temps réel

**Livrable final** : Interface admin web pour gérer FootApp, accessible sur `https://api.footapp.com/admin`.

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Setup Filament + Sécurité

```bash
# Installation (déjà fait Sprint 01)
php artisan filament:install --panels

# Créer un admin user
php artisan make:filament-user
# → Email: admin@footapp.com
# → Password: ********
```

**Sécuriser le panel admin** :

```php
// app/Models/User.php
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;

class User extends Authenticatable implements FilamentUser
{
    public function canAccessPanel(Panel $panel): bool
    {
        return $this->is_admin === true 
            && str_ends_with($this->email, '@mhdservice.com');
    }
}
```

**Ajouter colonne `is_admin`** :

```php
Schema::table('users', function (Blueprint $table) {
    $table->boolean('is_admin')->default(false);
});
```

### J2 (4h) - Vue d'ensemble (Dashboard)

```bash
php artisan make:filament-widget DashboardOverview --stats-overview
php artisan make:filament-widget RevenueChart --chart
php artisan make:filament-widget PredictionsChart --chart
php artisan make:filament-widget RecentSignups --table
```

```php
// app/Filament/Widgets/DashboardOverview.php
class DashboardOverview extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            Stat::make('Utilisateurs Total', User::count())
                ->description('+' . User::whereDate('created_at', today())->count() . ' aujourd\'hui')
                ->descriptionIcon('heroicon-m-arrow-trending-up')
                ->color('success')
                ->chart(User::query()
                    ->whereBetween('created_at', [now()->subDays(30), now()])
                    ->groupByRaw('DATE(created_at)')
                    ->selectRaw('COUNT(*) as count')
                    ->pluck('count')->toArray()
                ),
            
            Stat::make('Premium Actifs', User::premium()->count())
                ->description('Conversion: ' . $this->getConversionRate() . '%')
                ->color('warning'),
            
            Stat::make('Revenus du Mois', $this->getMonthlyRevenue() . ' FCFA')
                ->description('+12% vs mois dernier')
                ->color('success'),
            
            Stat::make('Win Rate Algo (7j)', $this->getWinRate() . '%')
                ->description($this->getWinRateTrend())
                ->color($this->getWinRate() >= 55 ? 'success' : 'danger'),
            
            Stat::make('Inscriptions Bookmakers', Affiliation::where('status', 'registered')
                ->whereDate('signup_completed_at', today())->count())
                ->description('aujourd\'hui')
                ->color('info'),
            
            Stat::make('Pronostics du Jour', Prediction::whereDate('created_at', today())->count())
                ->description($this->getPredictionsBreakdown())
                ->color('primary'),
        ];
    }
    
    private function getWinRate(): float
    {
        $predictions = Prediction::where('status', '!=', 'pending')
            ->where('created_at', '>', now()->subDays(7))
            ->get();
        
        if ($predictions->isEmpty()) return 0;
        
        $won = $predictions->where('status', 'won')->count();
        return round(($won / $predictions->count()) * 100, 1);
    }
}
```

### J3 (6h) - Resource Predictions

```bash
php artisan make:filament-resource Prediction --view --simple
```

```php
// app/Filament/Resources/PredictionResource.php
class PredictionResource extends Resource
{
    protected static ?string $model = Prediction::class;
    protected static ?string $navigationIcon = 'heroicon-o-presentation-chart-bar';
    protected static ?string $modelLabel = 'Pronostic';
    
    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('match.competition.name')
                    ->label('Compétition')
                    ->searchable(),
                
                TextColumn::make('match')
                    ->label('Match')
                    ->getStateUsing(fn ($record) => 
                        "{$record->match->homeTeam->name} vs {$record->match->awayTeam->name}"
                    ),
                
                TextColumn::make('match.match_date')
                    ->label('Date')
                    ->dateTime('d/m H:i'),
                
                TextColumn::make('bet_choice')
                    ->label('Pari')
                    ->badge(),
                
                TextColumn::make('odds')
                    ->label('Cote')
                    ->numeric(2),
                
                TextColumn::make('confidence_score')
                    ->label('Confiance')
                    ->numeric(1)
                    ->suffix('%')
                    ->color(fn ($state) => match (true) {
                        $state >= 85 => 'success',
                        $state >= 70 => 'info',
                        $state >= 60 => 'warning',
                        default => 'gray',
                    }),
                
                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->colors([
                        'gray' => 'pending',
                        'success' => 'won',
                        'danger' => 'lost',
                        'warning' => 'void',
                    ]),
                
                IconColumn::make('is_premium_only')
                    ->label('Premium')
                    ->boolean(),
                
                TextColumn::make('clicks_count')
                    ->label('Clics')
                    ->numeric(),
            ])
            ->filters([
                SelectFilter::make('status')
                    ->options([
                        'pending' => 'En attente',
                        'won' => 'Gagné',
                        'lost' => 'Perdu',
                        'void' => 'Annulé',
                    ]),
                
                SelectFilter::make('confidence_score')
                    ->label('Niveau confiance')
                    ->options([
                        'very_high' => 'Très élevée (85+)',
                        'high' => 'Élevée (70-84)',
                        'medium' => 'Moyenne (60-69)',
                    ])
                    ->query(function ($query, array $data) {
                        return match ($data['value']) {
                            'very_high' => $query->where('confidence_score', '>=', 85),
                            'high' => $query->whereBetween('confidence_score', [70, 84]),
                            'medium' => $query->whereBetween('confidence_score', [60, 69]),
                            default => $query,
                        };
                    }),
                
                Filter::make('match_date')
                    ->form([
                        DatePicker::make('from'),
                        DatePicker::make('to'),
                    ])
                    ->query(function ($query, array $data) {
                        return $query
                            ->when($data['from'], fn ($q, $date) => $q->whereHas('match', fn ($q) => $q->whereDate('match_date', '>=', $date)))
                            ->when($data['to'], fn ($q, $date) => $q->whereHas('match', fn ($q) => $q->whereDate('match_date', '<=', $date)));
                    }),
            ])
            ->actions([
                Action::make('mark_won')
                    ->label('Marquer Gagné')
                    ->color('success')
                    ->icon('heroicon-o-check')
                    ->requiresConfirmation()
                    ->visible(fn ($record) => $record->status === 'pending')
                    ->action(fn ($record) => $record->update(['status' => 'won', 'settled_at' => now()])),
                
                Action::make('mark_lost')
                    ->label('Marquer Perdu')
                    ->color('danger')
                    ->icon('heroicon-o-x-mark')
                    ->requiresConfirmation()
                    ->visible(fn ($record) => $record->status === 'pending')
                    ->action(fn ($record) => $record->update(['status' => 'lost', 'settled_at' => now()])),
                
                ViewAction::make(),
                EditAction::make(),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                    BulkAction::make('mark_won')
                        ->label('Marquer comme gagnés')
                        ->action(fn ($records) => $records->each->update(['status' => 'won'])),
                ]),
            ])
            ->defaultSort('created_at', 'desc');
    }
}
```

### J4 (4h) - Resource Users

```bash
php artisan make:filament-resource User
```

Highlights:

```php
public static function table(Table $table): Table
{
    return $table
        ->columns([
            TextColumn::make('id')->sortable(),
            TextColumn::make('name')->searchable(),
            TextColumn::make('phone')->searchable(),
            TextColumn::make('email')->searchable(),
            TextColumn::make('country_code'),
            
            IconColumn::make('is_premium')
                ->boolean()
                ->trueIcon('heroicon-o-star')
                ->trueColor('warning'),
            
            TextColumn::make('subscription_expires_at')
                ->label('Expire le')
                ->dateTime('d/m/Y'),
            
            TextColumn::make('referrals_count')
                ->label('Filleuls')
                ->numeric()
                ->sortable(),
            
            TextColumn::make('preferred_bookmaker')
                ->badge(),
            
            TextColumn::make('last_login_at')
                ->label('Dernière co')
                ->since(),
            
            TextColumn::make('created_at')
                ->dateTime('d/m/Y'),
        ])
        ->actions([
            Action::make('grant_premium')
                ->label('Offrir 7j Premium')
                ->color('warning')
                ->icon('heroicon-o-gift')
                ->form([
                    Select::make('days')
                        ->options([
                            '3' => '3 jours',
                            '7' => '7 jours',
                            '15' => '15 jours',
                            '30' => '30 jours',
                        ])
                        ->required(),
                ])
                ->action(function ($record, array $data) {
                    $expiry = max(now(), $record->subscription_expires_at ?? now())
                        ->addDays($data['days']);
                    
                    $record->update([
                        'is_premium' => true,
                        'subscription_expires_at' => $expiry,
                    ]);
                    
                    Notification::make()
                        ->title("{$data['days']} jours premium offerts à {$record->name}")
                        ->success()
                        ->send();
                }),
            
            Action::make('block')
                ->label('Bloquer')
                ->color('danger')
                ->icon('heroicon-o-no-symbol')
                ->requiresConfirmation()
                ->action(fn ($record) => $record->update(['is_blocked' => true])),
            
            Action::make('send_notification')
                ->label('Notif Push')
                ->icon('heroicon-o-bell')
                ->form([
                    TextInput::make('title')->required(),
                    Textarea::make('body')->required(),
                ])
                ->action(function ($record, array $data) {
                    // Envoyer FCM
                    app(NotificationService::class)->sendToUser(
                        $record, $data['title'], $data['body']
                    );
                }),
        ])
        ->filters([
            SelectFilter::make('is_premium')->options([
                true => 'Premium',
                false => 'Gratuit',
            ]),
            SelectFilter::make('preferred_bookmaker')->options([
                'betwinner' => 'Betwinner',
                '1xbet' => '1xBet',
                'melbet' => 'Melbet',
            ]),
        ]);
}
```

### J5 (4h) - Resources Subscriptions, Affiliations, Promotions

```bash
php artisan make:filament-resource Subscription
php artisan make:filament-resource Affiliation
php artisan make:filament-resource Promotion
```

**Subscriptions** :

```php
// Colonnes principales
TextColumn::make('user.name'),
TextColumn::make('plan_type')->badge(),
TextColumn::make('amount')->money('XOF'),
TextColumn::make('status')->badge()->colors([
    'success' => 'active',
    'gray' => 'expired',
    'danger' => 'cancelled',
]),
TextColumn::make('starts_at')->dateTime(),
TextColumn::make('expires_at')->dateTime(),
```

**Affiliations** :

```php
TextColumn::make('user.name'),
TextColumn::make('bookmaker')->badge(),
TextColumn::make('status')->badge(),
TextColumn::make('clicked_at')->since(),
TextColumn::make('signup_completed_at')->since(),
IconColumn::make('premium_granted')->boolean(),

// Actions admin
Action::make('verify_signup')
    ->label('Vérifier inscription')
    ->action(function ($record) {
        app(AffiliationService::class)->checkAndGrantBonus(
            $record->user, $record->bookmaker
        );
    }),
```

**Promotions** :

```php
public static function form(Form $form): Form
{
    return $form->schema([
        Select::make('bookmaker')->options([
            'betwinner' => 'Betwinner',
            '1xbet' => '1xBet',
            'melbet' => 'Melbet',
        ])->required(),
        
        TextInput::make('promo_code')->required(),
        TextInput::make('description')->required(),
        
        Select::make('bonus_type')->options([
            'first_deposit' => '1er dépôt',
            'free_bet' => 'Pari gratuit',
            'cashback' => 'Cashback',
            'odds_boost' => 'Boost cote',
        ]),
        
        TextInput::make('bonus_amount')->numeric(),
        TextInput::make('bonus_percentage')->numeric()->suffix('%'),
        TextInput::make('min_deposit')->numeric(),
        TextInput::make('max_bonus')->numeric(),
        
        Textarea::make('terms'),
        
        DateTimePicker::make('valid_from'),
        DateTimePicker::make('valid_until'),
        
        Toggle::make('is_active')->default(true),
        TextInput::make('priority')->numeric()->default(1),
    ]);
}
```

### J6 (4h) - Resources Payments, Feedbacks, Statistics

**Payments** : vue read-only avec filtres par gateway/status/dates.

**Feedbacks** :

```php
TextColumn::make('user.name'),
TextColumn::make('category')->badge(),
TextColumn::make('description')->limit(80),
TextColumn::make('status')->badge(),
ImageColumn::make('screenshot_path'),

Action::make('respond')
    ->form([
        Textarea::make('response')->required(),
    ])
    ->action(function ($record, $data) {
        $record->update([
            'admin_response' => $data['response'],
            'status' => 'resolved',
        ]);
        $record->user->notify(new FeedbackRespondedNotification($record));
    });
```

**Statistics widget** : graphique évolution win rate, revenus, users.

### J7 (4h) - Pages custom + Notifications

**Page : Backtest Algorithm** :

```bash
php artisan make:filament-page BacktestAlgorithm
```

```php
class BacktestAlgorithm extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-beaker';
    protected static ?string $title = 'Backtest Algorithme';
    
    public ?string $startDate = null;
    public ?string $endDate = null;
    public ?int $minScore = 50;
    public array $results = [];
    public bool $isRunning = false;
    
    public function runBacktest()
    {
        $this->isRunning = true;
        
        // Lancer command (dans un job pour gros volumes)
        Artisan::call('algorithm:backtest', [
            '--start' => $this->startDate,
            '--end' => $this->endDate,
            '--min-score' => $this->minScore,
        ]);
        
        // Récupérer les résultats depuis logs/cache
        $this->results = Cache::get('last_backtest_results', []);
        $this->isRunning = false;
        
        Notification::make()
            ->title('Backtest terminé')
            ->success()
            ->send();
    }
}
```

**Page : Auto-Fill Errors** :

```php
// Vue des erreurs auto-fill récentes pour debug
public function table(Table $table): Table
{
    return $table->query(
        AutoFillError::query()->latest()
    )->columns([
        TextColumn::make('bookmaker'),
        TextColumn::make('user.name'),
        TextColumn::make('error_message')->limit(80),
        TextColumn::make('created_at')->dateTime(),
    ]);
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Admin accessible sur `https://api.footapp.com/admin`
- [ ] Dashboard widget overview fonctionne
- [ ] Resource Predictions : filtrage, override, marquage gagné/perdu
- [ ] Resource Users : grant premium, block, send notif
- [ ] Resource Subscriptions, Affiliations, Promotions, Payments
- [ ] Page Backtest Algorithm
- [ ] Sécurité : seul admin email @mhdservice.com peut accéder
- [ ] Mobile-friendly (Filament responsive)

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Setup + Sécurité | 4h |
| Dashboard widgets | 4h |
| Resource Predictions | 6h |
| Resource Users | 4h |
| Resources Subscriptions/Affiliations | 4h |
| Resources Promotions/Payments | 4h |
| Pages custom | 4h |
| **TOTAL** | **30h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ Sprint 09 → `SPRINT-10-Tests-Deploy.md` (FINAL !)
