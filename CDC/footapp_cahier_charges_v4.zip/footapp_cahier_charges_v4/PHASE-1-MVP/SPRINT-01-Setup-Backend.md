# 🏗️ SPRINT 01 - Setup Backend Laravel

> **Phase** : 1 - MVP | **Durée** : 2 semaines (50h) | **Priorité** : 🔴 CRITIQUE
> **Prérequis** : VPS Hostinger commandé, domaine acheté

---

## 🎯 OBJECTIF DU SPRINT

Mettre en place les **fondations techniques solides** du backend Laravel 11 avec :
- ✅ Environnement de dev local fonctionnel
- ✅ Repository GitHub configuré
- ✅ Structure de base de données complète
- ✅ Architecture des dossiers (services, repositories)
- ✅ Outils de monitoring de base (Sentry, Pulse)
- ✅ CI/CD GitHub Actions opérationnel

**Livrable final** : Backend Laravel déployable, prêt à recevoir les fonctionnalités métier.

---

## 📋 TÂCHES DÉTAILLÉES

### Semaine 1 - Setup local + structure

#### J1 (8h) - Installation environnement local

- [ ] Installer **Laravel Herd** (PHP 8.3 + tools)
- [ ] Installer **MySQL 8.0** local
- [ ] Installer **Redis** local
- [ ] Installer **Composer**
- [ ] Configurer **Cursor IDE** + extensions Laravel
- [ ] Installer **TablePlus** (GUI MySQL)
- [ ] Installer **Postman** (test API)

```bash
# Vérifications
php --version  # >= 8.3
composer --version
mysql --version  # >= 8.0
redis-cli ping  # PONG
```

#### J2 (4h) - Création projet Laravel

```bash
# Création projet
composer create-project laravel/laravel footapp-backend --prefer-dist
cd footapp-backend

# Installation packages essentiels
composer require laravel/sanctum
composer require filament/filament:^3.2
composer require spatie/laravel-permission
composer require spatie/laravel-activitylog
composer require spatie/laravel-backup
composer require sentry/sentry-laravel
composer require laravel/horizon
composer require laravel/pulse
composer require laravel/socialite
composer require twilio/sdk
composer require predis/predis

# Dev only
composer require --dev barryvdh/laravel-debugbar
composer require --dev laravel/telescope
composer require --dev pestphp/pest
```

#### J3 (4h) - Configuration .env + GitHub

```bash
# Initialiser Git
git init
git remote add origin git@github.com:mhdservice/footapp-backend.git

# .gitignore Laravel par défaut OK
# Ajouter
echo ".env.local" >> .gitignore
echo "storage/app/private/" >> .gitignore

# Premier commit
git add .
git commit -m "feat: initial Laravel 11 setup with core packages"
git push -u origin main
```

**Variables `.env` à configurer** :

```env
APP_NAME="FootApp"
APP_ENV=local
APP_KEY=base64:xxx
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=footapp
DB_USERNAME=root
DB_PASSWORD=

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

# API-Football
API_FOOTBALL_KEY=xxx
API_FOOTBALL_HOST=v3.football.api-sports.io

# Paydunya
PAYDUNYA_MASTER_KEY=xxx
PAYDUNYA_PRIVATE_KEY=xxx
PAYDUNYA_PUBLIC_KEY=xxx
PAYDUNYA_TOKEN=xxx
PAYDUNYA_MODE=test  # ou live

# Stripe
STRIPE_KEY=xxx
STRIPE_SECRET=xxx
STRIPE_WEBHOOK_SECRET=xxx

# Twilio (SMS OTP)
TWILIO_SID=xxx
TWILIO_TOKEN=xxx
TWILIO_FROM=+xxx

# Firebase (FCM)
FIREBASE_PROJECT_ID=xxx
FIREBASE_CREDENTIALS=storage/app/firebase-credentials.json

# Sentry
SENTRY_LARAVEL_DSN=xxx

# Bookmakers Affiliation
BETWINNER_AFFILIATE_ID=xxx
ONEXBET_AFFILIATE_ID=xxx
MELBET_AFFILIATE_ID=xxx
```

#### J4-J5 (16h) - Architecture des dossiers

Créer la structure suivante dans `app/` :

```bash
mkdir -p app/Services/Algorithm
mkdir -p app/Services/Bookmaker
mkdir -p app/Services/ML
mkdir -p app/Services/Notification
mkdir -p app/Services/Payment
mkdir -p app/Services/User

mkdir -p app/Repositories/Contracts
mkdir -p app/Repositories/Eloquent

mkdir -p app/Http/Controllers/Api/V1
mkdir -p app/Http/Controllers/Webhooks
mkdir -p app/Http/Resources

mkdir -p app/Enums
mkdir -p app/Exceptions/Custom
mkdir -p app/Events
mkdir -p app/Listeners
```

**Créer un Service Provider custom** :

```bash
php artisan make:provider RepositoryServiceProvider
```

```php
// app/Providers/RepositoryServiceProvider.php
namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Repositories\Contracts\PredictionRepositoryInterface;
use App\Repositories\Eloquent\PredictionRepository;
// ... autres repos

class RepositoryServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(
            PredictionRepositoryInterface::class,
            PredictionRepository::class
        );
        // Bind tous les autres repos ici
    }
}
```

### Semaine 2 - Database + Outils + Déploiement

#### J6-J7 (12h) - Migrations base de données

> 📖 **Schéma complet** : voir `ANNEXE-BDD-Schema.md`

**Migrations à créer (15 tables)** :

```bash
# Users (extension de la migration Laravel par défaut)
php artisan make:migration update_users_table_for_footapp

# Tables custom
php artisan make:migration create_competitions_table
php artisan make:migration create_teams_table
php artisan make:migration create_matches_table
php artisan make:migration create_predictions_table
php artisan make:migration create_combined_bets_table
php artisan make:migration create_subscriptions_table
php artisan make:migration create_payments_table
php artisan make:migration create_affiliations_table
php artisan make:migration create_referrals_table
php artisan make:migration create_feedbacks_table
php artisan make:migration create_notifications_log_table
php artisan make:migration create_statistics_table
php artisan make:migration create_promotions_table
php artisan make:migration create_user_preferences_table
```

**Exemple migration users étendue** :

```php
// database/migrations/xxxx_update_users_table_for_footapp.php
public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->string('phone', 20)->unique()->nullable()->after('email');
        $table->string('country_code', 2)->nullable()->after('phone');
        $table->string('facebook_id')->nullable()->unique()->after('country_code');
        
        // OTP
        $table->string('otp_code')->nullable();
        $table->timestamp('otp_expires_at')->nullable();
        $table->integer('otp_attempts')->default(0);
        
        // Premium
        $table->boolean('is_premium')->default(false);
        $table->timestamp('subscription_expires_at')->nullable();
        $table->string('subscription_type')->nullable(); // daily, weekly, monthly, etc.
        
        // Référral
        $table->string('referral_code', 10)->unique()->nullable();
        $table->foreignId('referred_by')->nullable()->constrained('users');
        $table->integer('referrals_count')->default(0);
        
        // Bookmaker preference
        $table->string('preferred_bookmaker')->nullable();
        $table->string('bookmaker_account_id')->nullable();
        $table->timestamp('bookmaker_selected_at')->nullable();
        
        // Métadonnées
        $table->string('language', 5)->default('fr');
        $table->string('device_id')->nullable();
        $table->json('fcm_tokens')->nullable();
        $table->boolean('is_blocked')->default(false);
        $table->timestamp('last_login_at')->nullable();
        
        // Index
        $table->index(['is_premium', 'subscription_expires_at']);
        $table->index('referral_code');
        $table->index('phone');
    });
}
```

**Exemple migration predictions** :

```php
public function up(): void
{
    Schema::create('predictions', function (Blueprint $table) {
        $table->id();
        $table->foreignId('match_id')->constrained()->cascadeOnDelete();
        
        // Prédiction
        $table->enum('bet_type', [
            'match_winner', 'over_under', 'btts', 
            'double_chance', 'handicap', 'exact_score',
            'on_target', 'corners'
        ]);
        $table->string('bet_choice'); // ex: '1', 'X', '2', 'Over 2.5'
        $table->decimal('odds', 5, 2); // ex: 1.85
        
        // Scoring
        $table->decimal('confidence_score', 5, 2); // 0-100
        $table->json('scoring_details'); // Détail par critère
        $table->text('analysis')->nullable(); // Texte analyse
        
        // Status
        $table->enum('status', ['pending', 'won', 'lost', 'void', 'cancelled'])
              ->default('pending');
        $table->timestamp('settled_at')->nullable();
        
        // Visibilité
        $table->boolean('is_premium_only')->default(false);
        $table->boolean('is_featured')->default(false);
        
        // Affiliation links
        $table->json('bookmaker_links')->nullable();
        $table->integer('clicks_count')->default(0);
        
        $table->timestamps();
        
        // Index
        $table->index(['status', 'created_at']);
        $table->index('confidence_score');
        $table->index('is_premium_only');
    });
}
```

#### J8 (6h) - Models Eloquent + Relations

```bash
# Models
php artisan make:model Competition
php artisan make:model Team
php artisan make:model FootballMatch  # 'Match' réservé
php artisan make:model Prediction
php artisan make:model CombinedBet
php artisan make:model Subscription
php artisan make:model Payment
php artisan make:model Affiliation
php artisan make:model Referral
php artisan make:model Feedback
php artisan make:model Promotion
php artisan make:model UserPreference
```

**Exemple Model User** :

```php
// app/Models/User.php
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name', 'email', 'phone', 'country_code', 'facebook_id',
        'is_premium', 'subscription_expires_at', 'subscription_type',
        'referral_code', 'referred_by', 'preferred_bookmaker',
        'language', 'device_id', 'fcm_tokens',
    ];

    protected $hidden = ['password', 'remember_token', 'otp_code'];

    protected $casts = [
        'is_premium' => 'boolean',
        'subscription_expires_at' => 'datetime',
        'otp_expires_at' => 'datetime',
        'last_login_at' => 'datetime',
        'fcm_tokens' => 'array',
        'is_blocked' => 'boolean',
    ];

    // Relations
    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    public function activeSubscription(): HasOne
    {
        return $this->hasOne(Subscription::class)
            ->where('status', 'active')
            ->where('expires_at', '>', now())
            ->latest();
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referred_by');
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(User::class, 'referred_by');
    }

    // Méthodes utilitaires
    public function isPremiumActive(): bool
    {
        return $this->is_premium 
            && $this->subscription_expires_at 
            && $this->subscription_expires_at->isFuture();
    }

    public function generateReferralCode(): string
    {
        do {
            $code = strtoupper(Str::random(6)) . $this->id;
        } while (User::where('referral_code', $code)->exists());
        
        $this->update(['referral_code' => $code]);
        return $code;
    }

    // Scopes
    public function scopePremium($query)
    {
        return $query->where('is_premium', true)
            ->where('subscription_expires_at', '>', now());
    }
}
```

#### J9 (4h) - Sentry + Pulse + Telescope

```bash
# Sentry
php artisan sentry:publish --dsn=https://xxx@sentry.io/xxx

# Pulse (monitoring built-in)
php artisan vendor:publish --provider="Laravel\Pulse\PulseServiceProvider"
php artisan migrate

# Telescope (dev only)
php artisan telescope:install
php artisan migrate
```

#### J10 (4h) - CI/CD GitHub Actions

```yaml
# .github/workflows/laravel.yml
name: Laravel CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      mysql:
        image: mysql:8.0
        env:
          MYSQL_ROOT_PASSWORD: root
          MYSQL_DATABASE: footapp_test
        ports:
          - 3306:3306
      redis:
        image: redis:7
        ports:
          - 6379:6379

    steps:
      - uses: actions/checkout@v4

      - name: Setup PHP 8.3
        uses: shivammathur/setup-php@v2
        with:
          php-version: '8.3'
          extensions: mbstring, xml, bcmath, mysql, redis
          coverage: pcov

      - name: Cache composer dependencies
        uses: actions/cache@v3
        with:
          path: vendor
          key: ${{ runner.os }}-composer-${{ hashFiles('**/composer.lock') }}

      - name: Install dependencies
        run: composer install --no-interaction --prefer-dist

      - name: Copy .env
        run: cp .env.example .env.testing

      - name: Generate key
        run: php artisan key:generate --env=testing

      - name: Run migrations
        run: php artisan migrate --env=testing --force

      - name: Run tests
        run: php artisan test --parallel

  deploy-prod:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    
    steps:
      - name: Deploy to VPS via SSH
        uses: appleboy/ssh-action@v1.0.0
        with:
          host: ${{ secrets.VPS_HOST }}
          username: ${{ secrets.VPS_USER }}
          key: ${{ secrets.VPS_SSH_KEY }}
          script: |
            cd /var/www/footapp-backend
            git pull origin main
            composer install --no-dev --optimize-autoloader
            php artisan migrate --force
            php artisan config:cache
            php artisan route:cache
            php artisan view:cache
            php artisan queue:restart
            sudo systemctl reload php8.3-fpm
            sudo systemctl reload nginx
```

#### J11-J12 (8h) - Déploiement VPS Hostinger

**Configuration serveur Ubuntu 22.04** :

```bash
# Connexion SSH
ssh root@vps_ip

# Mise à jour
apt update && apt upgrade -y

# Installation LEMP
apt install -y nginx mysql-server php8.3-fpm php8.3-mysql \
  php8.3-redis php8.3-mbstring php8.3-xml php8.3-curl \
  php8.3-zip php8.3-bcmath php8.3-gd composer

# Redis
apt install -y redis-server

# Node.js (pour assets)
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Certbot (SSL Let's Encrypt)
apt install -y certbot python3-certbot-nginx

# Sécuriser MySQL
mysql_secure_installation

# Créer DB
mysql -u root -p
> CREATE DATABASE footapp;
> CREATE USER 'footapp'@'localhost' IDENTIFIED BY 'strong_password';
> GRANT ALL PRIVILEGES ON footapp.* TO 'footapp'@'localhost';
> FLUSH PRIVILEGES;
> EXIT;

# Cloner le projet
cd /var/www
git clone git@github.com:mhdservice/footapp-backend.git
cd footapp-backend
composer install --no-dev --optimize-autoloader

# Permissions
chown -R www-data:www-data /var/www/footapp-backend
chmod -R 755 /var/www/footapp-backend
chmod -R 775 /var/www/footapp-backend/storage
chmod -R 775 /var/www/footapp-backend/bootstrap/cache

# Config .env production
cp .env.example .env
nano .env  # Configurer prod

php artisan key:generate
php artisan migrate --force
php artisan config:cache
php artisan route:cache

# SSL
certbot --nginx -d api.footapp.com

# Supervisor (queue workers)
apt install -y supervisor
nano /etc/supervisor/conf.d/footapp-worker.conf
```

**Configuration Nginx** :

```nginx
# /etc/nginx/sites-available/footapp
server {
    listen 80;
    server_name api.footapp.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.footapp.com;
    
    root /var/www/footapp-backend/public;
    index index.php;
    
    ssl_certificate /etc/letsencrypt/live/api.footapp.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.footapp.com/privkey.pem;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    location ~ /\.(?!well-known).* {
        deny all;
    }
    
    # Compression
    gzip on;
    gzip_types text/plain application/json application/javascript text/css;
    
    # Headers sécurité
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    add_header X-XSS-Protection "1; mode=block";
}
```

---

## ✅ CRITÈRES DE VALIDATION SPRINT 01

À la fin du sprint, tu dois pouvoir cocher :

### Local
- [ ] `php artisan serve` lance le projet sur localhost:8000
- [ ] `/api/health` répond 200 OK
- [ ] Toutes les migrations passent sans erreur
- [ ] `php artisan test` exécute les tests basiques
- [ ] Telescope accessible sur `/telescope`
- [ ] Pulse accessible sur `/pulse`

### GitHub
- [ ] Code pushé sur `main`
- [ ] GitHub Actions vert (tests passent en CI)
- [ ] README.md créé avec instructions installation

### Production
- [ ] Site `https://api.footapp.com/api/health` accessible
- [ ] SSL Let's Encrypt actif
- [ ] Sentry reçoit les erreurs
- [ ] Logs accessibles (`tail -f storage/logs/laravel.log`)
- [ ] Queue worker tourne (Supervisor)
- [ ] Backup quotidien configuré

### Sécurité
- [ ] `.env` jamais commité sur GitHub
- [ ] Mot de passe MySQL fort
- [ ] Firewall UFW activé (ports 80, 443, 22 only)
- [ ] Fail2ban installé

---

## 🐛 PIÈGES FRÉQUENTS À ÉVITER

### ❌ Erreur 1 : Permissions storage
```bash
# Si erreur "permission denied"
sudo chown -R www-data:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

### ❌ Erreur 2 : Migrations échouent
```bash
# Si erreur "key too long"
# Dans AppServiceProvider::boot()
Schema::defaultStringLength(191);
```

### ❌ Erreur 3 : Sanctum cookies issue
```bash
# Dans config/sanctum.php, vérifier
'stateful' => [...],
# Et CORS dans config/cors.php
```

### ❌ Erreur 4 : Queue ne démarre pas
```bash
# Vérifier Supervisor
sudo supervisorctl status footapp-worker:*
sudo supervisorctl restart footapp-worker:*
```

---

## 🎓 RESSOURCES IA-FRIENDLY

### Pour Cursor / Claude

**Prompts utiles** pour ce sprint :

```
"Génère-moi une migration Laravel 11 pour une table predictions 
avec match_id, bet_type, bet_choice, odds, confidence_score, 
status, et timestamps. Inclus les index pertinents."

"Crée un Model Eloquent User avec relations vers subscriptions, 
referrals, payments. Inclus une méthode isPremiumActive()."

"Configure un workflow GitHub Actions pour Laravel 11 avec tests 
PHPUnit, MySQL et Redis."
```

### Documentation à bookmark

- 📖 [Laravel 11 Docs](https://laravel.com/docs/11.x)
- 📖 [Filament 3 Docs](https://filamentphp.com/docs/3.x)
- 📖 [Sanctum Auth](https://laravel.com/docs/11.x/sanctum)
- 📖 [Laravel Horizon](https://laravel.com/docs/11.x/horizon)

---

## 📊 ESTIMATION TEMPS

| Phase | Heures |
|-------|--------|
| Setup local | 12h |
| Architecture + Models | 16h |
| Migrations BDD | 12h |
| CI/CD + Sentry | 4h |
| Déploiement VPS | 8h |
| Buffer/imprévus | 8h |
| **TOTAL** | **60h** |

> **Réaliste à 30h/semaine** : 2 semaines (Sprint 01 ✅)

---

## 🔗 PROCHAINE ÉTAPE

✅ **Sprint 01 terminé** → Démarrer `SPRINT-02-Auth-OTP.md`

---

*Sprint conçu pour solo dev + IA assist | Itérations rapides*
