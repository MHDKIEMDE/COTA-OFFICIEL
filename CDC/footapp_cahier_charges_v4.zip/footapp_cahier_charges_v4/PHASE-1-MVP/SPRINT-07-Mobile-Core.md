# 📱 SPRINT 07 - Mobile App Core (Flutter)

> **Phase** : 1 - MVP | **Durée** : 2 semaines (60h) | **Priorité** : 🔴 CRITIQUE
> **Prérequis** : Backend Sprints 01-06 terminés

---

## 🎯 OBJECTIF DU SPRINT

Construire le coeur de l'application mobile Flutter :
- ✅ Setup projet + architecture Clean
- ✅ Onboarding (4 slides) + Popup bookmaker
- ✅ Authentification (OTP + Facebook)
- ✅ Dashboard pronostics
- ✅ Détail pronostic
- ✅ Profil utilisateur
- ✅ Navigation principale (BottomNav)

**Livrable final** : APK Android installable, user peut s'inscrire, voir les pronostics, naviguer.

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Setup projet Flutter

```bash
# Installer Flutter 3.24+
# https://docs.flutter.dev/get-started/install

flutter --version  # >= 3.24.0
flutter doctor     # Vérifier toolchain

# Créer projet
flutter create footapp_mobile \
  --org com.mhdservice \
  --project-name footapp \
  --description "FootApp - Pronostics Football IA" \
  --platforms=android,ios

cd footapp_mobile

# Setup Git
git init
git remote add origin git@github.com:mhdservice/footapp-mobile.git

# Installer packages essentiels
flutter pub add flutter_riverpod
flutter pub add riverpod_annotation
flutter pub add dio
flutter pub add retrofit
flutter pub add hive hive_flutter
flutter pub add shared_preferences
flutter pub add google_fonts
flutter pub add flutter_svg
flutter pub add cached_network_image
flutter pub add shimmer
flutter pub add lottie
flutter pub add firebase_core firebase_auth firebase_messaging
flutter pub add flutter_facebook_auth
flutter pub add local_auth
flutter pub add webview_flutter
flutter pub add url_launcher
flutter pub add go_router
flutter pub add intl
flutter pub add uuid
flutter pub add posthog_flutter

# Dev dependencies
flutter pub add --dev build_runner
flutter pub add --dev riverpod_generator
flutter pub add --dev json_serializable
flutter pub add --dev hive_generator
```

### J2 (6h) - Architecture Clean

Structure des dossiers :

```
lib/
├── core/
│   ├── api/
│   │   ├── api_client.dart
│   │   ├── api_interceptors.dart
│   │   └── api_endpoints.dart
│   ├── theme/
│   │   ├── app_colors.dart
│   │   ├── app_text_styles.dart
│   │   └── app_theme.dart
│   ├── routing/
│   │   └── app_router.dart
│   ├── storage/
│   │   ├── secure_storage.dart
│   │   └── local_storage.dart
│   ├── errors/
│   │   ├── app_exceptions.dart
│   │   └── error_handler.dart
│   └── utils/
│       ├── validators.dart
│       └── extensions.dart
├── data/
│   ├── models/
│   │   ├── user_model.dart
│   │   ├── prediction_model.dart
│   │   └── ...
│   ├── repositories/
│   │   ├── auth_repository.dart
│   │   ├── prediction_repository.dart
│   │   └── ...
│   └── datasources/
│       ├── remote/
│       └── local/
├── domain/
│   ├── entities/
│   └── usecases/
├── presentation/
│   ├── screens/
│   │   ├── onboarding/
│   │   ├── auth/
│   │   ├── dashboard/
│   │   ├── prediction_detail/
│   │   ├── history/
│   │   ├── profile/
│   │   └── subscription/
│   ├── widgets/
│   │   ├── common/
│   │   └── specific/
│   └── providers/
└── main.dart
```

### J3 (6h) - Theme & Design system

```dart
// lib/core/theme/app_colors.dart
import 'package:flutter/material.dart';

class AppColors {
  // Primary palette
  static const primary = Color(0xFF00BCD4);     // Cyan vif
  static const primaryDark = Color(0xFF0097A7);
  static const primaryLight = Color(0xFF4DD0E1);
  
  // Accent
  static const accent = Color(0xFFFF6B35);      // Orange foot
  static const accentLight = Color(0xFFFF8C61);
  
  // Neutrals (dark mode first)
  static const background = Color(0xFF0F1419);
  static const surface = Color(0xFF1A1F2E);
  static const surfaceLight = Color(0xFF252B3D);
  
  // Text
  static const textPrimary = Color(0xFFFFFFFF);
  static const textSecondary = Color(0xFFB0B7C3);
  static const textTertiary = Color(0xFF6B7280);
  
  // Status
  static const success = Color(0xFF10B981);     // Vert (won)
  static const error = Color(0xFFEF4444);       // Rouge (lost)
  static const warning = Color(0xFFF59E0B);     // Jaune
  static const info = Color(0xFF3B82F6);        // Bleu
  
  // Confidence levels
  static const confidenceVeryHigh = Color(0xFF10B981);
  static const confidenceHigh = Color(0xFF60A5FA);
  static const confidenceMedium = Color(0xFFF59E0B);
  static const confidenceLow = Color(0xFFF97316);
  
  // Premium
  static const premium = Color(0xFFFFD700);     // Or
  static const premiumDark = Color(0xFFFBBF24);
}
```

```dart
// lib/core/theme/app_theme.dart
class AppTheme {
  static ThemeData get darkTheme => ThemeData(
    brightness: Brightness.dark,
    primaryColor: AppColors.primary,
    scaffoldBackgroundColor: AppColors.background,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.accent,
      surface: AppColors.surface,
      error: AppColors.error,
    ),
    textTheme: GoogleFonts.poppinsTextTheme(
      ThemeData.dark().textTheme,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      elevation: 0,
      centerTitle: true,
    ),
    cardTheme: CardTheme(
      color: AppColors.surface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.black,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}
```

### J4 (6h) - API Client (Dio + Retrofit)

```dart
// lib/core/api/api_client.dart
import 'package:dio/dio.dart';

class ApiClient {
  static late Dio _dio;
  
  static Dio get instance {
    return _dio;
  }
  
  static void initialize({String? token}) {
    _dio = Dio(BaseOptions(
      baseUrl: 'https://api.footapp.com/api/v1',
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      },
    ));
    
    // Logger en debug
    if (kDebugMode) {
      _dio.interceptors.add(LogInterceptor(
        requestBody: true,
        responseBody: true,
      ));
    }
    
    // Auto-refresh token / handle 401
    _dio.interceptors.add(InterceptorsWrapper(
      onError: (DioException error, handler) async {
        if (error.response?.statusCode == 401) {
          // Token expiré, déconnexion
          await SecureStorage.clearAll();
          // Navigator vers login
        }
        return handler.next(error);
      },
    ));
  }
  
  static void setToken(String token) {
    _dio.options.headers['Authorization'] = 'Bearer $token';
  }
  
  static void clearToken() {
    _dio.options.headers.remove('Authorization');
  }
}
```

### J5 (6h) - Models + Repositories

```dart
// lib/data/models/prediction_model.dart
import 'package:json_annotation/json_annotation.dart';

part 'prediction_model.g.dart';

@JsonSerializable()
class PredictionModel {
  final int id;
  final FootballMatchModel match;
  final String betType;
  final String betChoice;
  final double odds;
  final double confidenceScore;
  final String? analysis;
  final String status; // pending, won, lost
  final bool isPremiumOnly;
  final DateTime createdAt;
  
  PredictionModel({
    required this.id,
    required this.match,
    required this.betType,
    required this.betChoice,
    required this.odds,
    required this.confidenceScore,
    this.analysis,
    required this.status,
    required this.isPremiumOnly,
    required this.createdAt,
  });
  
  factory PredictionModel.fromJson(Map<String, dynamic> json) =>
      _$PredictionModelFromJson(json);
  
  Map<String, dynamic> toJson() => _$PredictionModelToJson(this);
  
  String get confidenceLevel {
    if (confidenceScore >= 85) return 'TRÈS ÉLEVÉE';
    if (confidenceScore >= 70) return 'ÉLEVÉE';
    if (confidenceScore >= 60) return 'MOYENNE';
    return 'FAIBLE';
  }
}
```

```dart
// lib/data/repositories/prediction_repository.dart
class PredictionRepository {
  final Dio _dio;
  
  PredictionRepository(this._dio);
  
  Future<List<PredictionModel>> getTodayPredictions() async {
    try {
      final response = await _dio.get('/predictions/today');
      final data = response.data['data'] as List;
      return data.map((e) => PredictionModel.fromJson(e)).toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }
  
  Future<PredictionModel> getPrediction(int id) async {
    final response = await _dio.get('/predictions/$id');
    return PredictionModel.fromJson(response.data['data']);
  }
  
  Future<CombinedBetModel?> getDailyCombined() async {
    try {
      final response = await _dio.get('/predictions/combined-daily');
      return CombinedBetModel.fromJson(response.data['data']);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) return null;
      throw _handleError(e);
    }
  }
}
```

### J6-J7 (10h) - Onboarding + Popup Bookmaker

```dart
// lib/presentation/screens/onboarding/onboarding_screen.dart
class OnboardingScreen extends ConsumerStatefulWidget {
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final PageController _controller = PageController();
  int _currentPage = 0;
  
  final List<OnboardingPage> _pages = [
    OnboardingPage(
      title: '🤖 Pronostics IA',
      subtitle: 'Algorithme analysant 50+ critères pour des pronos fiables',
      lottie: 'assets/lottie/ai_brain.json',
    ),
    OnboardingPage(
      title: '⚡ Auto-Fill Bookmakers',
      subtitle: 'Pariez en 15 secondes avec le pré-remplissage automatique',
      lottie: 'assets/lottie/lightning.json',
    ),
    OnboardingPage(
      title: '💰 Mobile Money',
      subtitle: 'Wave, Orange Money, MTN, Moov - Sans carte bancaire',
      lottie: 'assets/lottie/mobile_money.json',
    ),
    OnboardingPage(
      title: '🎁 7 Jours Gratuits',
      subtitle: 'Inscris-toi sur un bookmaker partenaire et reçois 7j premium',
      lottie: 'assets/lottie/gift.json',
    ),
  ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Skip button
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () => _completeOnboarding(),
                child: const Text('Passer'),
              ),
            ),
            
            // Pages
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _currentPage = i),
                itemBuilder: (_, i) => _buildPage(_pages[i]),
              ),
            ),
            
            // Indicator
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_pages.length, (i) => 
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 8,
                  width: i == _currentPage ? 24 : 8,
                  decoration: BoxDecoration(
                    color: i == _currentPage 
                        ? AppColors.primary 
                        : AppColors.textTertiary,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
            
            const SizedBox(height: 32),
            
            // CTA
            Padding(
              padding: const EdgeInsets.all(24),
              child: ElevatedButton(
                onPressed: _currentPage < _pages.length - 1
                    ? () => _controller.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        )
                    : _completeOnboarding,
                child: Text(
                  _currentPage < _pages.length - 1 ? 'Suivant' : 'Commencer',
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Future<void> _completeOnboarding() async {
    await LocalStorage.set('onboarding_completed', true);
    if (mounted) context.go('/auth/login');
  }
}
```

```dart
// Popup sélection bookmaker (après onboarding, avant auth)
class BookmakerSelectionDialog extends ConsumerStatefulWidget {
  // Implémentation cf. cahier des charges initial
  // 3 options: Betwinner / 1xBet / Melbet
  // 2 modes: J'ai un compte / Je m'inscris
}
```

### J8-J9 (12h) - Auth Screens

```dart
// lib/presentation/screens/auth/login_screen.dart
class LoginScreen extends ConsumerStatefulWidget {
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _phoneController = TextEditingController();
  String _countryCode = '+221';
  bool _isLoading = false;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),
              
              // Logo
              Image.asset('assets/logo.png', height: 80),
              
              const SizedBox(height: 40),
              
              Text('Bienvenue 👋', 
                style: Theme.of(context).textTheme.headlineLarge),
              
              const SizedBox(height: 8),
              
              Text('Connecte-toi pour accéder aux pronostics',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppColors.textSecondary,
                )),
              
              const SizedBox(height: 40),
              
              // Phone input
              Container(
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    // Country picker
                    InkWell(
                      onTap: _pickCountry,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Text('🇸🇳', style: const TextStyle(fontSize: 20)),
                            const SizedBox(width: 8),
                            Text(_countryCode),
                          ],
                        ),
                      ),
                    ),
                    
                    Container(width: 1, height: 30, color: AppColors.textTertiary),
                    
                    Expanded(
                      child: TextField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                          hintText: '77 123 45 67',
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.all(16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 24),
              
              ElevatedButton(
                onPressed: _isLoading ? null : _sendOtp,
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.black)
                    : const Text('Recevoir le code'),
              ),
              
              const SizedBox(height: 24),
              
              const Row(children: [
                Expanded(child: Divider()),
                Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('OU')),
                Expanded(child: Divider()),
              ]),
              
              const SizedBox(height: 24),
              
              // Facebook
              OutlinedButton.icon(
                onPressed: _loginFacebook,
                icon: const Icon(Icons.facebook),
                label: const Text('Continuer avec Facebook'),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Future<void> _sendOtp() async {
    final phone = '$_countryCode${_phoneController.text.trim()}';
    setState(() => _isLoading = true);
    
    try {
      await ref.read(authRepositoryProvider).sendOtp(phone);
      if (mounted) context.push('/auth/verify-otp', extra: phone);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }
}
```

### J10-J11 (10h) - Dashboard + Détail Pronostic

```dart
// lib/presentation/screens/dashboard/dashboard_screen.dart
class DashboardScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final predictionsAsync = ref.watch(todayPredictionsProvider);
    final user = ref.watch(currentUserProvider);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('FootApp'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => context.push('/notifications'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => ref.refresh(todayPredictionsProvider),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Bannière premium
            if (!user.isPremium) PremiumBanner(),
            
            // Bannière bonus 7j
            BonusBanner(),
            
            const SizedBox(height: 24),
            
            // Combiné du jour (carte à gratter si gratuit)
            CombinedDailyCard(),
            
            const SizedBox(height: 24),
            
            // Section Pronostics
            const Text('🔥 Pronostics du jour',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            
            const SizedBox(height: 16),
            
            predictionsAsync.when(
              data: (predictions) => Column(
                children: predictions.map((p) => 
                  PredictionCard(prediction: p)
                ).toList(),
              ),
              loading: () => const ShimmerLoadingList(),
              error: (e, st) => ErrorWidget(message: e.toString()),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const FootAppBottomNav(currentIndex: 0),
    );
  }
}

// Widget Card Pronostic
class PredictionCard extends StatelessWidget {
  final PredictionModel prediction;
  
  const PredictionCard({required this.prediction});
  
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => context.push('/prediction/${prediction.id}'),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header : compétition + heure
              Row(
                children: [
                  Image.network(prediction.match.competition.logo, height: 20),
                  const SizedBox(width: 8),
                  Text(prediction.match.competition.name,
                    style: const TextStyle(color: AppColors.textSecondary)),
                  const Spacer(),
                  Text(DateFormat('HH:mm').format(prediction.match.matchDate)),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // Teams
              Row(
                children: [
                  Expanded(
                    child: TeamRow(team: prediction.match.homeTeam),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text('VS'),
                  ),
                  Expanded(
                    child: TeamRow(team: prediction.match.awayTeam, alignEnd: true),
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              const Divider(),
              const SizedBox(height: 12),
              
              // Pari + Confidence
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Pari
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Pari', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      Text(_formatBet(prediction),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  
                  // Cote
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Cote', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                      Text(prediction.odds.toStringAsFixed(2),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  
                  // Confidence
                  ConfidenceBadge(score: prediction.confidenceScore),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  String _formatBet(PredictionModel p) {
    return switch (p.betType) {
      'match_winner' => switch (p.betChoice) {
        '1' => '${p.match.homeTeam.name} gagne',
        'X' => 'Match nul',
        '2' => '${p.match.awayTeam.name} gagne',
        _ => p.betChoice,
      },
      'over_under' => p.betChoice == 'over_2.5' ? '+2.5 buts' : '-2.5 buts',
      'btts' => p.betChoice == 'yes' ? 'Les 2 équipes marquent' : 'Une équipe ne marque pas',
      _ => p.betChoice,
    };
  }
}
```

### J12 (4h) - Navigation + Profil basique

```dart
// lib/core/routing/app_router.dart
import 'package:go_router/go_router.dart';

final appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
    GoRoute(path: '/onboarding', builder: (_, __) => const OnboardingScreen()),
    GoRoute(path: '/auth/login', builder: (_, __) => const LoginScreen()),
    GoRoute(path: '/auth/verify-otp', builder: (_, state) => 
      VerifyOtpScreen(phone: state.extra as String)),
    GoRoute(path: '/dashboard', builder: (_, __) => const DashboardScreen()),
    GoRoute(path: '/prediction/:id', builder: (_, state) => 
      PredictionDetailScreen(id: int.parse(state.pathParameters['id']!))),
    GoRoute(path: '/history', builder: (_, __) => const HistoryScreen()),
    GoRoute(path: '/stats', builder: (_, __) => const StatsScreen()),
    GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
    GoRoute(path: '/subscription', builder: (_, __) => const SubscriptionScreen()),
  ],
);
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] APK Android généré et installable
- [ ] Onboarding 4 slides fonctionnel
- [ ] Popup bookmaker à la première ouverture
- [ ] Login OTP fonctionne avec backend
- [ ] Login Facebook fonctionne
- [ ] Dashboard affiche les pronostics du jour
- [ ] Détail prono ouvre depuis le dashboard
- [ ] BottomNav navigation entre les écrans
- [ ] Dark mode appliqué partout
- [ ] Données mises en cache (Hive)
- [ ] Indicateurs de chargement (Shimmer)
- [ ] Gestion erreurs réseau

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Setup projet | 4h |
| Architecture | 6h |
| Theme & Design | 6h |
| API Client | 6h |
| Models & Repos | 6h |
| Onboarding + Popup | 10h |
| Auth Screens | 12h |
| Dashboard + Détail | 10h |
| Navigation | 4h |
| **TOTAL** | **64h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ Sprint 07 → `SPRINT-08-Mobile-Premium.md`
