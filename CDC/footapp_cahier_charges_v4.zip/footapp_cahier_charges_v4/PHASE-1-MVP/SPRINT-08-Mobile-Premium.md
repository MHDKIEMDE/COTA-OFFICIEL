# 💎 SPRINT 08 - Mobile Premium + Carte à Gratter

> **Phase** : 1 - MVP | **Durée** : 1 semaine (30h) | **Priorité** : 🟠 IMPORTANT
> **Prérequis** : Sprints 05-07 terminés

---

## 🎯 OBJECTIF DU SPRINT

Implémenter les écrans premium et la gamification :
- ✅ Écran abonnement (3 formules)
- ✅ WebView paiement Paydunya/Stripe
- ✅ Carte à gratter pour le combiné quotidien
- ✅ WebView auto-fill bookmakers
- ✅ Notifications push (FCM)
- ✅ Gestion premium/free states

**Livrable final** : User peut s'abonner, gratter le combiné premium, parier via auto-fill.

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Écran Abonnement

```dart
// lib/presentation/screens/subscription/subscription_screen.dart
class SubscriptionScreen extends ConsumerStatefulWidget {
  @override
  ConsumerState<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends ConsumerState<SubscriptionScreen> {
  String _selectedPlan = 'monthly';
  String _selectedGateway = 'paydunya';
  bool _isLoading = false;
  
  final _plans = [
    {
      'type': 'daily',
      'name': 'Journalier',
      'price_fcfa': 500,
      'price_per_day': 500,
      'duration': '1 jour',
      'discount': null,
      'badge': null,
    },
    {
      'type': 'weekly',
      'name': 'Hebdomadaire',
      'price_fcfa': 2500,
      'price_per_day': 357,
      'duration': '7 jours',
      'discount': null,
      'badge': null,
    },
    {
      'type': 'monthly',
      'name': 'Mensuel',
      'price_fcfa': 8000,
      'price_per_day': 267,
      'duration': '30 jours',
      'discount': '-25% par jour',
      'badge': '⭐ Populaire',
    },
    {
      'type': 'quarterly',
      'name': 'Trimestriel',
      'price_fcfa': 20000,
      'price_per_day': 222,
      'duration': '97 jours',
      'discount': '-38% par jour',
      'badge': '🔥 Meilleure offre',
    },
    {
      'type': 'vip',
      'name': 'VIP Premium',
      'price_fcfa': 15000,
      'price_per_day': 500,
      'duration': '30 jours',
      'discount': null,
      'badge': '👑 VIP',
    },
  ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Devenir Premium')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.premium, AppColors.premiumDark],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Text('🏆', style: TextStyle(fontSize: 48)),
                  const SizedBox(height: 12),
                  const Text('Débloquez tous les pronostics',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Combinés quotidiens • Stats avancées • Notifications',
                    style: TextStyle(color: Colors.black.withOpacity(0.7))),
                ],
              ),
            ),
            
            const SizedBox(height: 24),
            
            // Bénéfices
            const _BenefitsList(),
            
            const SizedBox(height: 24),
            
            // Plans
            const Text('Choisis ta formule',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            
            ..._plans.map((plan) => _buildPlanCard(plan)),
            
            const SizedBox(height: 24),
            
            // Méthode de paiement
            const Text('Méthode de paiement',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            
            _buildGatewayOption('paydunya', 'Mobile Money (Wave, Orange, MTN, Moov)', '📱'),
            _buildGatewayOption('stripe', 'Carte bancaire', '💳'),
            
            const SizedBox(height: 24),
            
            // CTA
            ElevatedButton(
              onPressed: _isLoading ? null : _proceedPayment,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                minimumSize: const Size(double.infinity, 56),
              ),
              child: _isLoading
                  ? const CircularProgressIndicator()
                  : Text('S\'abonner pour ${_getSelectedPlan()['price_fcfa']} FCFA'),
            ),
            
            const SizedBox(height: 12),
            
            Text('Paiement sécurisé • Activation immédiate',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          ],
        ),
      ),
    );
  }
  
  Future<void> _proceedPayment() async {
    setState(() => _isLoading = true);
    
    try {
      final response = await ref.read(paymentRepositoryProvider).createCheckout(
        planType: _selectedPlan,
        gateway: _selectedGateway,
      );
      
      // Ouvrir WebView
      if (mounted) {
        final result = await context.push('/payment-webview', extra: response);
        
        // Si paiement réussi, refresh user
        if (result == 'success') {
          ref.invalidate(currentUserProvider);
          if (mounted) {
            context.pop();
            _showSuccessDialog();
          }
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }
}
```

### J2 (4h) - WebView Paiement

```dart
// lib/presentation/screens/payment/payment_webview_screen.dart
class PaymentWebViewScreen extends ConsumerStatefulWidget {
  final String paymentUrl;
  
  const PaymentWebViewScreen({required this.paymentUrl});
  
  @override
  ConsumerState<PaymentWebViewScreen> createState() => _PaymentWebViewScreenState();
}

class _PaymentWebViewScreenState extends ConsumerState<PaymentWebViewScreen> {
  late WebViewController _controller;
  bool _isLoading = true;
  
  @override
  void initState() {
    super.initState();
    
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => _isLoading = true),
          onPageFinished: (_) => setState(() => _isLoading = false),
          onNavigationRequest: (request) {
            // Détecter URLs de retour
            if (request.url.startsWith('footapp://payment/success')) {
              context.pop('success');
              return NavigationDecision.prevent;
            }
            if (request.url.startsWith('footapp://payment/cancel')) {
              context.pop('cancel');
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.paymentUrl));
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Paiement'),
        actions: [
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () => _confirmCancel(),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
```

### J3-J4 (8h) - Carte à Gratter (Gamification)

> 💡 **Implémentation** : utiliser le package `scratcher` ou créer un Custom Painter.

```bash
flutter pub add scratcher
```

```dart
// lib/presentation/widgets/scratch_card_combined.dart
import 'package:scratcher/scratcher.dart';

class ScratchCardCombined extends ConsumerStatefulWidget {
  final CombinedBetModel combined;
  
  const ScratchCardCombined({required this.combined});
  
  @override
  ConsumerState<ScratchCardCombined> createState() => _ScratchCardCombinedState();
}

class _ScratchCardCombinedState extends ConsumerState<ScratchCardCombined> {
  bool _revealed = false;
  
  @override
  Widget build(BuildContext context) {
    final isPremium = ref.watch(currentUserProvider).isPremium;
    
    if (isPremium) {
      // Pas de scratch pour premium - affichage direct
      return _buildRevealedCard();
    }
    
    // Pour les gratuits : carte à gratter
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          // Contenu sous-jacent (visible après scratch)
          _buildRevealedCard(),
          
          // Couche scratch
          if (!_revealed)
            Positioned.fill(
              child: Scratcher(
                accuracy: ScratchAccuracy.low,
                threshold: 40, // 40% à gratter pour révéler
                color: AppColors.primary,
                image: Image.asset('assets/scratch_pattern.png', fit: BoxFit.cover),
                onThreshold: () {
                  setState(() => _revealed = true);
                  _onRevealed();
                },
                child: Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primary, AppColors.primaryDark],
                    ),
                  ),
                  child: const Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('🎰', style: TextStyle(fontSize: 80)),
                        SizedBox(height: 16),
                        Text(
                          'Combiné du Jour',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Grattez pour découvrir',
                          style: TextStyle(fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
  
  Widget _buildRevealedCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.surface, AppColors.surfaceLight],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('🏆', style: TextStyle(fontSize: 32)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Combiné Premium',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('Confiance moyenne: ${widget.combined.confidenceAvg.toInt()}%',
                      style: const TextStyle(color: AppColors.textSecondary)),
                  ],
                ),
              ),
              ConfidenceBadge(score: widget.combined.confidenceAvg),
            ],
          ),
          
          const SizedBox(height: 16),
          const Divider(),
          const SizedBox(height: 12),
          
          // Liste des matchs
          ...widget.combined.predictions.map((p) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: [
                Container(
                  width: 24, height: 24,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(Icons.check, size: 16, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    '${p.match.homeTeam.name} vs ${p.match.awayTeam.name}',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text('@${p.odds.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          )),
          
          const SizedBox(height: 12),
          const Divider(),
          const SizedBox(height: 12),
          
          // Cote totale
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Cote totale', style: TextStyle(fontSize: 16)),
              Text(
                'x${widget.combined.totalOdds.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppColors.success,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // CTA Parier
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _openBookmaker(),
              icon: const Icon(Icons.flash_on),
              label: const Text('Parier maintenant ⚡'),
            ),
          ),
        ],
      ),
    );
  }
  
  void _onRevealed() {
    // Analytics
    ref.read(analyticsProvider).logEvent('combined_scratched', {
      'combined_id': widget.combined.id,
    });
    
    // Notification au backend
    ref.read(combinedRepositoryProvider).markScratched(widget.combined.id);
  }
  
  void _openBookmaker() {
    final user = ref.read(currentUserProvider);
    final preferred = user.preferredBookmaker ?? 'betwinner';
    context.push('/auto-fill/${widget.combined.id}/$preferred');
  }
}
```

### J5 (4h) - WebView Auto-Fill

```dart
// lib/presentation/screens/bookmaker/auto_fill_webview_screen.dart
class AutoFillWebViewScreen extends ConsumerStatefulWidget {
  final int combinedId;
  final String bookmaker;
  
  const AutoFillWebViewScreen({
    required this.combinedId,
    required this.bookmaker,
  });
  
  @override
  ConsumerState<AutoFillWebViewScreen> createState() => _AutoFillWebViewScreenState();
}

class _AutoFillWebViewScreenState extends ConsumerState<AutoFillWebViewScreen> {
  late WebViewController _controller;
  String? _bookmakerUrl;
  String? _autoFillScript;
  bool _isLoading = true;
  bool _scriptInjected = false;
  
  @override
  void initState() {
    super.initState();
    _loadAutoFillData();
  }
  
  Future<void> _loadAutoFillData() async {
    try {
      final data = await ref.read(betSlipRepositoryProvider).getAutoFillData(
        bookmaker: widget.bookmaker,
        combinedId: widget.combinedId,
      );
      
      setState(() {
        _bookmakerUrl = data['bookmaker_url'];
        _autoFillScript = data['autofill_script'];
      });
      
      _initWebView();
    } catch (e) {
      // Handle error
    }
  }
  
  void _initWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel(
        'AutoFillResult',
        onMessageReceived: (message) {
          // Réception du résultat de l'injection
          final data = jsonDecode(message.message);
          _handleAutoFillResult(data);
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => _isLoading = true),
          onPageFinished: (_) async {
            setState(() => _isLoading = false);
            
            // Injecter le script auto-fill après chargement
            if (!_scriptInjected && _autoFillScript != null) {
              await Future.delayed(const Duration(seconds: 2));
              await _controller.runJavaScript(_autoFillScript!);
              setState(() => _scriptInjected = true);
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(_bookmakerUrl!));
  }
  
  void _handleAutoFillResult(Map<String, dynamic> data) {
    // Reporter au backend
    ref.read(betSlipRepositoryProvider).reportAutoFillResult(
      bookmaker: widget.bookmaker,
      success: data['success'] ?? false,
      matchesFilled: data['matches_filled'],
    );
    
    if (data['success']) {
      // Toast succès
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Coupon pré-rempli ! Vérifiez et confirmez.')),
      );
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pari sur ${widget.bookmaker}'),
        actions: [
          if (_scriptInjected)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Center(child: Text('✅ Auto-fill OK')),
            ),
        ],
      ),
      body: _bookmakerUrl == null
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                WebViewWidget(controller: _controller),
                if (_isLoading)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 16),
                          Text('Préparation du coupon...',
                            style: TextStyle(color: Colors.white)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}
```

### J6 (4h) - Notifications Push (FCM)

```dart
// lib/core/services/notification_service.dart
class NotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotif = FlutterLocalNotificationsPlugin();
  
  Future<void> initialize() async {
    // Permissions
    await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    
    // Token FCM
    final token = await _fcm.getToken();
    if (token != null) {
      // Envoyer au backend pour enregistrer
      await _sendTokenToBackend(token);
    }
    
    // Listener token refresh
    _fcm.onTokenRefresh.listen(_sendTokenToBackend);
    
    // Foreground messages
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    
    // Background messages
    FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationTap);
    
    // Local notifications setup
    await _initLocalNotifications();
  }
  
  Future<void> _initLocalNotifications() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings();
    
    await _localNotif.initialize(
      const InitializationSettings(
        android: androidSettings,
        iOS: iosSettings,
      ),
    );
  }
  
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    // Afficher notification locale
    await _localNotif.show(
      message.hashCode,
      message.notification?.title ?? 'FootApp',
      message.notification?.body ?? '',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'footapp_channel',
          'FootApp Notifications',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }
  
  Future<void> _sendTokenToBackend(String token) async {
    try {
      await ApiClient.instance.post('/users/fcm-token', data: {'token': token});
    } catch (_) {
      // Retry plus tard
    }
  }
}
```

### J7 (4h) - Profil + Premium gating

```dart
// lib/presentation/screens/profile/profile_screen.dart
class ProfileScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    
    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header user
          _buildUserHeader(user),
          
          const SizedBox(height: 24),
          
          // Subscription status
          if (user.isPremium)
            _PremiumStatusCard(user: user)
          else
            _UpgradeCard(),
          
          const SizedBox(height: 24),
          
          // Sections
          _ProfileSection(
            title: 'Mon Compte',
            items: [
              _ProfileItem(icon: Icons.person, title: 'Informations', onTap: () {}),
              _ProfileItem(icon: Icons.language, title: 'Langue', onTap: () {}),
              _ProfileItem(icon: Icons.notifications, title: 'Notifications', onTap: () {}),
              _ProfileItem(icon: Icons.lock, title: 'Sécurité (PIN, Biométrie)', onTap: () {}),
            ],
          ),
          
          _ProfileSection(
            title: 'Premium & Bonus',
            items: [
              _ProfileItem(icon: Icons.star, title: 'Mon abonnement', 
                onTap: () => context.push('/subscription')),
              _ProfileItem(icon: Icons.card_giftcard, title: 'Parrainage',
                onTap: () => context.push('/referral')),
              _ProfileItem(icon: Icons.local_offer, title: 'Bonus 7j gratuits',
                onTap: () => context.push('/affiliations')),
            ],
          ),
          
          _ProfileSection(
            title: 'Aide',
            items: [
              _ProfileItem(icon: Icons.help, title: 'FAQ', onTap: () {}),
              _ProfileItem(icon: Icons.bug_report, title: 'Signaler un problème', onTap: () {}),
              _ProfileItem(icon: Icons.info, title: 'À propos', onTap: () {}),
            ],
          ),
          
          const SizedBox(height: 24),
          
          OutlinedButton(
            onPressed: () => _logout(ref),
            child: const Text('Se déconnecter'),
          ),
        ],
      ),
    );
  }
}
```

### Premium Gating Widget

```dart
// lib/presentation/widgets/premium_gate.dart
class PremiumGate extends ConsumerWidget {
  final Widget child;
  final String featureName;
  
  const PremiumGate({required this.child, required this.featureName});
  
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPremium = ref.watch(currentUserProvider).isPremium;
    
    if (isPremium) return child;
    
    return Stack(
      children: [
        Opacity(opacity: 0.3, child: child),
        Positioned.fill(
          child: ColoredBox(
            color: Colors.black.withOpacity(0.7),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.lock, size: 48, color: AppColors.premium),
                  const SizedBox(height: 12),
                  Text('$featureName réservé Premium',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => context.push('/subscription'),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.premium),
                    child: const Text('Passer Premium'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Écran abonnement affiche les 5 formules
- [ ] WebView paiement Paydunya s'ouvre
- [ ] Retour app après paiement réussi → user devient premium
- [ ] Carte à gratter fonctionnelle (40% scratch threshold)
- [ ] Auto-fill WebView injection script
- [ ] Notifications push reçues (test FCM)
- [ ] Premium gates affichés sur features payantes
- [ ] Profil complet (subscription, parrainage, etc.)

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Écran abonnement | 4h |
| WebView paiement | 4h |
| Carte à gratter | 8h |
| Auto-Fill WebView | 4h |
| Notifications FCM | 4h |
| Profil + Gating | 6h |
| **TOTAL** | **30h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ Sprint 08 → `SPRINT-09-Admin-Dashboard.md`
