# 🔗 SPRINT 06 - Affiliation Bookmakers + Auto-Fill

> **Phase** : 1 - MVP | **Durée** : 1 semaine (30h) | **Priorité** : 🔴 CRITIQUE (revenue)
> **Prérequis** : Sprints 01-05 terminés

---

## 🎯 OBJECTIF DU SPRINT

Mettre en place le système d'affiliation et de pré-remplissage automatique :
- ✅ Tracking des clics et inscriptions bookmakers
- ✅ Système de bonus 7 jours premium
- ✅ Codes promo dynamiques par bookmaker
- ✅ Scripts d'auto-fill pour Betwinner/1xBet/Melbet
- ✅ Dashboard admin pour suivre les conversions

**Livrable final** : User clique "Parier", arrive sur le bookmaker avec coupon pré-rempli, et FootApp gagne une commission.

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Setup comptes affiliation

**Inscriptions bookmakers** (à faire en parallèle - 1 semaine de validation) :

1. **Betwinner Affiliates** : https://betwinneraffiliates.com
2. **1xBet Affiliates** : https://1xpartners.com
3. **Melbet Affiliates** : https://melbetaffiliates.com

**Documents requis** :
- Pièce d'identité
- Adresse de l'app (footapp.com)
- Numéros de téléphone vérifiables
- Plan de promotion

**Récupérer les liens trackés** :
```
https://betwinner.com/?tag=YOUR_AFFILIATE_ID
https://1xbet.com/?tag=YOUR_AFFILIATE_ID
https://melbet.com/?tag=YOUR_AFFILIATE_ID
```

### J2 (6h) - Modèles & Migrations

```php
// Migration affiliations table (sprint 01) - Vérifier ces colonnes
Schema::create('affiliations', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->enum('bookmaker', ['betwinner', '1xbet', 'melbet']);
    $table->string('tracking_id')->unique();
    $table->string('tracking_url');
    
    // Tracking événements
    $table->timestamp('clicked_at')->nullable();
    $table->timestamp('signup_started_at')->nullable();
    $table->timestamp('signup_completed_at')->nullable();
    $table->timestamp('first_deposit_at')->nullable();
    $table->decimal('first_deposit_amount', 10, 2)->nullable();
    
    // Récompense
    $table->boolean('premium_granted')->default(false);
    $table->timestamp('premium_granted_at')->nullable();
    $table->integer('premium_days_granted')->default(7);
    
    // Commission
    $table->decimal('estimated_commission', 10, 2)->nullable();
    $table->boolean('commission_confirmed')->default(false);
    $table->json('metadata')->nullable();
    
    $table->enum('status', ['pending', 'clicked', 'registered', 'deposited', 'expired'])
          ->default('pending');
    
    $table->timestamps();
    
    $table->index(['user_id', 'status']);
    $table->index('tracking_id');
});

// Migration promotions table
Schema::create('promotions', function (Blueprint $table) {
    $table->id();
    $table->enum('bookmaker', ['betwinner', '1xbet', 'melbet']);
    $table->string('promo_code', 50);
    $table->string('description');
    $table->enum('bonus_type', ['first_deposit', 'free_bet', 'cashback', 'odds_boost']);
    $table->decimal('bonus_amount', 10, 2)->nullable();
    $table->integer('bonus_percentage')->nullable();
    $table->decimal('min_deposit', 10, 2)->nullable();
    $table->decimal('max_bonus', 10, 2)->nullable();
    $table->text('terms')->nullable();
    $table->timestamp('valid_from')->nullable();
    $table->timestamp('valid_until')->nullable();
    $table->boolean('is_active')->default(true);
    $table->integer('priority')->default(1);
    $table->json('targeting')->nullable(); // pays, etc.
    $table->timestamps();
});
```

### J3 (6h) - Service Affiliation

```php
// app/Services/Bookmaker/AffiliationService.php
namespace App\Services\Bookmaker;

use App\Models\{User, Affiliation};
use Illuminate\Support\Str;

class AffiliationService
{
    private array $bookmakers = [
        'betwinner' => [
            'base_url' => 'https://betwinner.com',
            'affiliate_param' => 'tag',
            'affiliate_id' => null, // Set in env
        ],
        '1xbet' => [
            'base_url' => 'https://1xbet.com',
            'affiliate_param' => 'tag',
            'affiliate_id' => null,
        ],
        'melbet' => [
            'base_url' => 'https://melbet.com',
            'affiliate_param' => 'tag',
            'affiliate_id' => null,
        ],
    ];
    
    public function __construct()
    {
        $this->bookmakers['betwinner']['affiliate_id'] = config('services.affiliations.betwinner');
        $this->bookmakers['1xbet']['affiliate_id'] = config('services.affiliations.onexbet');
        $this->bookmakers['melbet']['affiliate_id'] = config('services.affiliations.melbet');
    }
    
    public function generateTrackingUrl(User $user, string $bookmaker): string
    {
        // ID unique pour identifier l'utilisateur dans le tracking
        $trackingId = Str::uuid();
        
        $config = $this->bookmakers[$bookmaker];
        
        // Format : {base_url}?tag={affiliate}_{tracking_id}
        $url = $config['base_url'] . '?' . http_build_query([
            $config['affiliate_param'] => $config['affiliate_id'] . '_' . $trackingId,
            'sub_id' => $user->id,
        ]);
        
        // Sauvegarder
        Affiliation::create([
            'user_id' => $user->id,
            'bookmaker' => $bookmaker,
            'tracking_id' => $trackingId,
            'tracking_url' => $url,
            'clicked_at' => now(),
            'status' => 'clicked',
        ]);
        
        return $url;
    }
    
    public function checkAndGrantBonus(User $user, string $bookmaker): bool
    {
        // Trouver l'affiliation la plus récente
        $affiliation = Affiliation::where('user_id', $user->id)
            ->where('bookmaker', $bookmaker)
            ->where('status', 'clicked')
            ->latest()
            ->first();
        
        if (!$affiliation) return false;
        
        // Si déjà bonus accordé, skip
        if ($affiliation->premium_granted) return false;
        
        // En production : vérifier auprès du bookmaker via API affiliation
        // Pour MVP : trust + verification manuelle dans dashboard admin
        
        $affiliation->update([
            'status' => 'registered',
            'signup_completed_at' => now(),
            'premium_granted' => true,
            'premium_granted_at' => now(),
            'premium_days_granted' => 7,
        ]);
        
        // Activer 7j premium
        $newExpiry = max(now(), $user->subscription_expires_at ?? now())
            ->addDays(7);
        
        $user->update([
            'is_premium' => true,
            'subscription_type' => 'affiliate_bonus',
            'subscription_expires_at' => $newExpiry,
        ]);
        
        $user->notify(new AffiliateBonusActivatedNotification($bookmaker));
        
        return true;
    }
    
    public function getActivePromos(string $bookmaker): array
    {
        return Promotion::where('bookmaker', $bookmaker)
            ->where('is_active', true)
            ->where(function($q) {
                $q->whereNull('valid_until')
                  ->orWhere('valid_until', '>', now());
            })
            ->orderBy('priority')
            ->get()
            ->toArray();
    }
}
```

### J4 (6h) - Controllers & Endpoints

```php
// app/Http/Controllers/Api/V1/AffiliationController.php
class AffiliationController extends Controller
{
    public function __construct(private AffiliationService $service) {}
    
    public function getTrackingUrl(Request $request, string $bookmaker)
    {
        $request->validate([
            'bookmaker' => 'required|in:betwinner,1xbet,melbet',
        ]);
        
        $url = $this->service->generateTrackingUrl(
            $request->user(),
            $bookmaker
        );
        
        return response()->json([
            'success' => true,
            'data' => [
                'tracking_url' => $url,
                'bookmaker' => $bookmaker,
                'promos' => $this->service->getActivePromos($bookmaker),
            ],
        ]);
    }
    
    public function checkBonus(Request $request, string $bookmaker)
    {
        $granted = $this->service->checkAndGrantBonus(
            $request->user(),
            $bookmaker
        );
        
        return response()->json([
            'success' => true,
            'bonus_granted' => $granted,
            'message' => $granted 
                ? '🎁 7 jours premium activés !'
                : 'Bonus non disponible',
        ]);
    }
    
    public function getPromos(string $bookmaker)
    {
        $promos = $this->service->getActivePromos($bookmaker);
        
        return response()->json([
            'success' => true,
            'data' => $promos,
        ]);
    }
}

// Job vérification automatique
// app/Jobs/CheckBookmakerRegistrationsJob.php
class CheckBookmakerRegistrationsJob implements ShouldQueue
{
    public function handle()
    {
        // Affiliations clickées dans les 7 derniers jours, statut "clicked"
        $pending = Affiliation::where('status', 'clicked')
            ->where('clicked_at', '>', now()->subDays(7))
            ->get();
        
        foreach ($pending as $affiliation) {
            // En production : appel API bookmaker (si dispo)
            // Pour MVP : vérification manuelle dashboard admin
            
            // Si tu as accès à l'API affiliation, ici tu verifies
            // l'inscription par tracking_id
        }
    }
}
```

### J5 (6h) - Scripts Auto-Fill JavaScript

> ⚠️ **Important** : ces scripts sont injectés via WebView Flutter, pas exécutés côté backend.

```javascript
// Stocké en BDD ou fichier statique servi par Laravel
// app/Services/Bookmaker/AutoFillScripts.php

public function getAutoFillScript(string $bookmaker, array $predictionData): string
{
    $jsonData = json_encode($predictionData);
    
    return match($bookmaker) {
        'betwinner' => $this->betwinnerScript($jsonData),
        '1xbet' => $this->onexbetScript($jsonData),
        'melbet' => $this->melbetScript($jsonData),
    };
}

private function betwinnerScript(string $jsonData): string
{
    return <<<JS
    (function() {
        const predictionData = {$jsonData};
        
        // Délai avant injection (page load)
        setTimeout(() => {
            try {
                // 1. Cliquer onglet coupon si pas ouvert
                const slipTab = document.querySelector('[data-testid="tab-slip"], .slip-tab');
                if (slipTab) slipTab.click();
                
                // 2. Pour chaque match, sélectionner le pari
                predictionData.matches.forEach((match, idx) => {
                    setTimeout(() => {
                        selectBetForMatch(match);
                    }, idx * 500);
                });
                
                // 3. Remplir le stake
                setTimeout(() => {
                    const stakeInput = document.querySelector('input[placeholder*="Mise"], input[name*="stake"]');
                    if (stakeInput) {
                        stakeInput.value = predictionData.stake_default || 10000;
                        stakeInput.dispatchEvent(new Event('input', { bubbles: true }));
                        stakeInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }, predictionData.matches.length * 500 + 1000);
                
                // 4. Notifier le succès au native
                if (window.flutter_inappwebview) {
                    window.flutter_inappwebview.callHandler('autofill_success', {
                        matches_filled: predictionData.matches.length,
                    });
                }
            } catch (error) {
                console.error('Auto-fill error:', error);
                if (window.flutter_inappwebview) {
                    window.flutter_inappwebview.callHandler('autofill_error', {
                        error: error.message,
                    });
                }
            }
        }, 2500); // Attendre 2.5s pour que la page charge
        
        function selectBetForMatch(match) {
            const matchElement = findMatchElement(match.team1, match.team2);
            if (!matchElement) return;
            
            switch (match.bet_type) {
                case 'match_winner':
                case '1x2':
                    selectMatchWinner(matchElement, match.selection);
                    break;
                case 'over_under':
                    selectOverUnder(matchElement, match.selection);
                    break;
                case 'btts':
                    selectBTTS(matchElement, match.selection);
                    break;
                case 'handicap':
                    selectHandicap(matchElement, match.selection);
                    break;
                case 'exact_score':
                    selectExactScore(matchElement, match.selection);
                    break;
            }
        }
        
        function findMatchElement(team1, team2) {
            const matchItems = document.querySelectorAll('[class*="match-item"], .event-row');
            for (const item of matchItems) {
                if (item.textContent.includes(team1) && item.textContent.includes(team2)) {
                    return item;
                }
            }
            return null;
        }
        
        function selectMatchWinner(matchEl, selection) {
            // selection: '1', 'X', '2'
            const buttons = matchEl.querySelectorAll('[class*="bet-button"]');
            const map = {'1': 0, 'X': 1, '2': 2};
            if (buttons[map[selection]]) buttons[map[selection]].click();
        }
        
        function selectOverUnder(matchEl, selection) {
            // selection: 'over_2.5'
            const overButton = matchEl.querySelector(`[data-bet*="${selection}"]`);
            if (overButton) overButton.click();
        }
        
        function selectBTTS(matchEl, selection) {
            // selection: 'yes' / 'no'
            const button = matchEl.querySelector(`[data-bet*="btts_${selection}"]`);
            if (button) button.click();
        }
        
        function selectHandicap(matchEl, selection) {
            // selection: '-1.5' / '+1.5'
            const button = Array.from(matchEl.querySelectorAll('button'))
                .find(b => b.textContent.includes(selection));
            if (button) button.click();
        }
        
        function selectExactScore(matchEl, selection) {
            // selection: '2-1'
            const dropdown = matchEl.querySelector('select[name*="score"]');
            if (dropdown) {
                dropdown.value = selection;
                dropdown.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
    })();
    JS;
}
```

### J6 (2h) - Endpoint pour Mobile

```php
// app/Http/Controllers/Api/V1/BetSlipController.php
class BetSlipController extends Controller
{
    public function getAutoFillData(
        Request $request,
        string $bookmaker,
        int $combinedBetId
    ) {
        $combined = CombinedBet::with('predictions.match.homeTeam', 'predictions.match.awayTeam')
            ->findOrFail($combinedBetId);
        
        // User doit être premium pour combiné premium
        if ($combined->is_premium_only && !$request->user()->isPremiumActive()) {
            return response()->json(['error' => 'Premium required'], 403);
        }
        
        // Préparer les données pour le script
        $matches = $combined->predictions->map(fn($p) => [
            'team1' => $p->match->homeTeam->name,
            'team2' => $p->match->awayTeam->name,
            'bet_type' => $p->bet_type,
            'selection' => $p->bet_choice,
            'odds' => $p->odds,
        ])->toArray();
        
        $script = app(AutoFillScripts::class)->getAutoFillScript($bookmaker, [
            'matches' => $matches,
            'stake_default' => 10000,
            'total_odds' => $combined->total_odds,
        ]);
        
        return response()->json([
            'success' => true,
            'data' => [
                'bookmaker_url' => app(AffiliationService::class)
                    ->generateTrackingUrl($request->user(), $bookmaker),
                'autofill_script' => $script,
                'matches_count' => count($matches),
            ],
        ]);
    }
    
    public function reportAutoFillResult(Request $request)
    {
        $validated = $request->validate([
            'bookmaker' => 'required|in:betwinner,1xbet,melbet',
            'success' => 'required|boolean',
            'matches_filled' => 'integer',
            'error' => 'nullable|string',
        ]);
        
        // Logger pour analyse (Sentry si error)
        if (!$validated['success']) {
            \Sentry\captureMessage('Auto-fill failed', [
                'bookmaker' => $validated['bookmaker'],
                'error' => $validated['error'],
                'user_id' => $request->user()->id,
            ]);
        }
        
        return response()->json(['received' => true]);
    }
}
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] 3 comptes affiliation créés (Betwinner, 1xBet, Melbet)
- [ ] Liens trackés génèrent un sub_id unique par user
- [ ] Endpoint `/affiliations/{bookmaker}/url` fonctionne
- [ ] Bonus 7j premium activé après "vérif" inscription
- [ ] Codes promo affichés selon bookmaker choisi
- [ ] Script auto-fill testé sur Betwinner (sandbox)
- [ ] Mobile peut récupérer le script et l'injecter via WebView
- [ ] Logs Sentry configurés pour erreurs auto-fill

---

## ⚠️ NOTES CRITIQUES

### Auto-fill = fragile
Les sélecteurs CSS des bookmakers changent souvent. **Maintenance régulière requise**.

**Plan B** : Si auto-fill échoue 3x → afficher message "Coupon non rempli automatiquement, sélectionner manuellement" + deep link.

### Vérification inscription = manuel en MVP
Sans accès API affiliation officielle, l'admin doit valider manuellement les inscriptions dans le dashboard.

**En Phase 2** : intégrer l'API affiliation officielle de chaque bookmaker (Betwinner Postback, etc.).

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Setup comptes | 4h |
| Migrations + Models | 6h |
| Service Affiliation | 6h |
| Controllers/Endpoints | 6h |
| Scripts Auto-Fill | 6h |
| Tests | 2h |
| **TOTAL** | **30h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ Sprint 06 → `SPRINT-07-Mobile-Core.md` (Flutter !)
