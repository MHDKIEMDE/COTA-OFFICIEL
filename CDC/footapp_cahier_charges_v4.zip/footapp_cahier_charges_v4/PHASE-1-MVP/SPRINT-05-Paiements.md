# 💳 SPRINT 05 - Paiements (Paydunya + Stripe)

> **Phase** : 1 - MVP | **Durée** : 1 semaine (30h) | **Priorité** : 🔴 CRITIQUE
> **Prérequis** : Sprint 02 (auth) terminé

---

## 🎯 OBJECTIF DU SPRINT

Implémenter le système de paiement complet :
- ✅ Paydunya (Mobile Money Afrique : Wave, Orange Money, MTN, Moov)
- ✅ Stripe (Carte bancaire international)
- ✅ Webhooks sécurisés
- ✅ Gestion des abonnements (création, renouvellement, expiration)
- ✅ Page checkout responsive
- ✅ Logs et reconciliation

**Livrable final** : Utilisateur peut s'abonner via Mobile Money OU CB et son compte est upgrade automatiquement.

---

## ⚠️ DÉCISIONS IMPORTANTES

- ❌ **Crypto reportée** en Phase 3 (complexité juridique)
- ✅ **Paydunya en priorité** (95% des users sont en Afrique)
- ✅ **Stripe** pour les rares users Europe/USA
- ✅ **Pas d'auto-renewal** en Phase 1 (manuel pour réduire complexité)

---

## 📋 TÂCHES DÉTAILLÉES

### J1 (4h) - Setup Paydunya

**Inscription** :
1. Créer compte sur https://paydunya.com
2. Vérifier compte (KYC entreprise)
3. Récupérer clés API (sandbox + prod)

```env
# .env
PAYDUNYA_MASTER_KEY=xxx
PAYDUNYA_PRIVATE_KEY=xxx
PAYDUNYA_PUBLIC_KEY=xxx
PAYDUNYA_TOKEN=xxx
PAYDUNYA_MODE=test # ou live
PAYDUNYA_CALLBACK_URL=https://api.footapp.com/webhooks/paydunya
PAYDUNYA_RETURN_URL=footapp://payment/success
PAYDUNYA_CANCEL_URL=footapp://payment/cancel
```

```php
// config/services.php
'paydunya' => [
    'master_key' => env('PAYDUNYA_MASTER_KEY'),
    'private_key' => env('PAYDUNYA_PRIVATE_KEY'),
    'public_key' => env('PAYDUNYA_PUBLIC_KEY'),
    'token' => env('PAYDUNYA_TOKEN'),
    'mode' => env('PAYDUNYA_MODE', 'test'),
    'callback_url' => env('PAYDUNYA_CALLBACK_URL'),
    'return_url' => env('PAYDUNYA_RETURN_URL'),
    'cancel_url' => env('PAYDUNYA_CANCEL_URL'),
],
```

### J2 (8h) - Service Paydunya

```php
// app/Services/Payment/PaydunyaService.php
namespace App\Services\Payment;

use Illuminate\Support\Facades\Http;
use App\Models\{User, Payment, Subscription};

class PaydunyaService
{
    private string $baseUrl;
    
    public function __construct()
    {
        $mode = config('services.paydunya.mode');
        $this->baseUrl = $mode === 'live' 
            ? 'https://app.paydunya.com/api/v1'
            : 'https://app.paydunya.com/sandbox-api/v1';
    }
    
    public function createInvoice(User $user, string $planType): array
    {
        $plan = $this->getPlanDetails($planType);
        
        $invoiceData = [
            'invoice' => [
                'total_amount' => $plan['amount'],
                'description' => "Abonnement FootApp - {$plan['name']}",
            ],
            'store' => [
                'name' => 'FootApp',
                'tagline' => 'Pronostics Football IA',
                'website_url' => 'https://footapp.com',
            ],
            'custom_data' => [
                'user_id' => $user->id,
                'plan_type' => $planType,
            ],
            'actions' => [
                'cancel_url' => config('services.paydunya.cancel_url'),
                'return_url' => config('services.paydunya.return_url'),
                'callback_url' => config('services.paydunya.callback_url'),
            ],
        ];
        
        $response = Http::withHeaders($this->getHeaders())
            ->post("{$this->baseUrl}/checkout-invoice/create", $invoiceData);
        
        if (!$response->successful()) {
            \Log::error('Paydunya invoice creation failed', [
                'response' => $response->body(),
            ]);
            throw new \Exception('Erreur création facture Paydunya');
        }
        
        $data = $response->json();
        
        // Sauvegarder le payment en attente
        Payment::create([
            'user_id' => $user->id,
            'gateway' => 'paydunya',
            'gateway_token' => $data['token'],
            'amount' => $plan['amount'],
            'currency' => 'XOF',
            'plan_type' => $planType,
            'status' => 'pending',
            'metadata' => $data,
        ]);
        
        return [
            'payment_url' => $data['response_text'],
            'token' => $data['token'],
        ];
    }
    
    public function verifyPayment(string $token): array
    {
        $response = Http::withHeaders($this->getHeaders())
            ->get("{$this->baseUrl}/checkout-invoice/confirm/{$token}");
        
        return $response->json();
    }
    
    private function getHeaders(): array
    {
        return [
            'Content-Type' => 'application/json',
            'PAYDUNYA-MASTER-KEY' => config('services.paydunya.master_key'),
            'PAYDUNYA-PRIVATE-KEY' => config('services.paydunya.private_key'),
            'PAYDUNYA-PUBLIC-KEY' => config('services.paydunya.public_key'),
            'PAYDUNYA-TOKEN' => config('services.paydunya.token'),
        ];
    }
    
    private function getPlanDetails(string $planType): array
    {
        return match($planType) {
            'daily' => ['name' => 'Journalier', 'amount' => 500, 'days' => 1],
            'weekly' => ['name' => 'Hebdomadaire', 'amount' => 2500, 'days' => 7],
            'monthly' => ['name' => 'Mensuel', 'amount' => 8000, 'days' => 30],
            'quarterly' => ['name' => 'Trimestriel', 'amount' => 20000, 'days' => 97],
            'vip' => ['name' => 'VIP', 'amount' => 15000, 'days' => 30],
            default => throw new \Exception('Plan invalide'),
        };
    }
}
```

### J3 (4h) - Webhook Paydunya

```php
// app/Http/Controllers/Webhooks/PaydunyaWebhookController.php
namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use App\Services\Payment\PaydunyaService;
use App\Services\Payment\SubscriptionService;
use Illuminate\Http\Request;

class PaydunyaWebhookController extends Controller
{
    public function handle(
        Request $request,
        PaydunyaService $paydunya,
        SubscriptionService $subscriptionService
    ) {
        // Vérifier signature (Paydunya envoie un hash)
        $token = $request->input('data.invoice.token');
        
        if (!$token) {
            return response()->json(['error' => 'Token missing'], 400);
        }
        
        // Re-vérifier auprès de Paydunya (sécurité)
        $verification = $paydunya->verifyPayment($token);
        
        if (($verification['status'] ?? '') !== 'completed') {
            \Log::warning('Webhook paydunya - status non completed', [
                'token' => $token,
                'verification' => $verification,
            ]);
            return response()->json(['received' => true]);
        }
        
        // Traiter le paiement
        $payment = Payment::where('gateway_token', $token)->first();
        
        if (!$payment || $payment->status === 'completed') {
            return response()->json(['received' => true]);
        }
        
        $payment->update([
            'status' => 'completed',
            'paid_at' => now(),
            'gateway_response' => $verification,
        ]);
        
        // Activer abonnement
        $subscriptionService->activate($payment);
        
        return response()->json(['received' => true]);
    }
}
```

```php
// routes/api.php
Route::post('/webhooks/paydunya', [PaydunyaWebhookController::class, 'handle'])
    ->name('webhooks.paydunya');
```

### J4 (4h) - Service Subscription

```php
// app/Services/Payment/SubscriptionService.php
class SubscriptionService
{
    public function activate(Payment $payment): Subscription
    {
        $user = $payment->user;
        $plan = $this->getPlanDetails($payment->plan_type);
        
        // Calculer date expiration
        $startsAt = now();
        
        // Si déjà premium, prolonger depuis l'expiration
        if ($user->subscription_expires_at && $user->subscription_expires_at->isFuture()) {
            $startsAt = $user->subscription_expires_at;
        }
        
        $expiresAt = $startsAt->copy()->addDays($plan['days']);
        
        // Créer subscription
        $subscription = Subscription::create([
            'user_id' => $user->id,
            'payment_id' => $payment->id,
            'plan_type' => $payment->plan_type,
            'amount' => $payment->amount,
            'currency' => $payment->currency,
            'starts_at' => $startsAt,
            'expires_at' => $expiresAt,
            'status' => 'active',
        ]);
        
        // Activer premium sur user
        $user->update([
            'is_premium' => true,
            'subscription_type' => $payment->plan_type,
            'subscription_expires_at' => $expiresAt,
        ]);
        
        // Notifier user
        $user->notify(new SubscriptionActivatedNotification($subscription));
        
        // Bonus parrainage si applicable
        if ($user->referrer && $user->subscriptions()->count() === 1) {
            $this->applyReferralReward($user->referrer);
        }
        
        return $subscription;
    }
    
    private function applyReferralReward(User $referrer): void
    {
        $referrer->increment('referrals_count');
        
        $rewardDays = match (true) {
            $referrer->referrals_count >= 20 => 9999, // À vie
            $referrer->referrals_count >= 10 => 30,
            $referrer->referrals_count >= 5 => 7,
            default => 3,
        };
        
        $newExpiry = max(now(), $referrer->subscription_expires_at ?? now())
            ->addDays($rewardDays);
        
        $referrer->update([
            'is_premium' => true,
            'subscription_expires_at' => $newExpiry,
        ]);
    }
}
```

### J5 (4h) - Stripe (international)

```bash
composer require stripe/stripe-php
```

```php
// app/Services/Payment/StripeService.php
namespace App\Services\Payment;

use Stripe\StripeClient;

class StripeService
{
    private StripeClient $stripe;
    
    public function __construct()
    {
        $this->stripe = new StripeClient(config('services.stripe.secret'));
    }
    
    public function createCheckoutSession(User $user, string $planType): array
    {
        $plan = $this->getPlanDetails($planType);
        
        $session = $this->stripe->checkout->sessions->create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'eur',
                    'product_data' => [
                        'name' => "FootApp - {$plan['name']}",
                    ],
                    'unit_amount' => $plan['amount_eur'] * 100, // centimes
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => config('services.stripe.success_url'),
            'cancel_url' => config('services.stripe.cancel_url'),
            'metadata' => [
                'user_id' => $user->id,
                'plan_type' => $planType,
            ],
        ]);
        
        // Sauvegarder Payment
        Payment::create([
            'user_id' => $user->id,
            'gateway' => 'stripe',
            'gateway_token' => $session->id,
            'amount' => $plan['amount_eur'],
            'currency' => 'EUR',
            'plan_type' => $planType,
            'status' => 'pending',
        ]);
        
        return [
            'payment_url' => $session->url,
            'session_id' => $session->id,
        ];
    }
}
```

### J6 (4h) - Endpoints API + Tests

```php
// app/Http/Controllers/Api/V1/PaymentController.php
class PaymentController extends Controller
{
    public function __construct(
        private PaydunyaService $paydunya,
        private StripeService $stripe
    ) {}
    
    public function createCheckout(Request $request)
    {
        $validated = $request->validate([
            'plan_type' => 'required|in:daily,weekly,monthly,quarterly,vip',
            'gateway' => 'required|in:paydunya,stripe',
        ]);
        
        $user = $request->user();
        
        $result = match ($validated['gateway']) {
            'paydunya' => $this->paydunya->createInvoice($user, $validated['plan_type']),
            'stripe' => $this->stripe->createCheckoutSession($user, $validated['plan_type']),
        };
        
        return response()->json(['success' => true, 'data' => $result]);
    }
    
    public function history(Request $request)
    {
        $payments = $request->user()
            ->payments()
            ->latest()
            ->paginate(20);
        
        return response()->json([
            'success' => true,
            'data' => PaymentResource::collection($payments),
        ]);
    }
    
    public function plans()
    {
        return response()->json([
            'success' => true,
            'data' => [
                ['type' => 'daily', 'name' => 'Journalier', 'price_fcfa' => 500, 'price_eur' => 0.80, 'duration_days' => 1],
                ['type' => 'weekly', 'name' => 'Hebdomadaire', 'price_fcfa' => 2500, 'price_eur' => 3.80, 'duration_days' => 7],
                ['type' => 'monthly', 'name' => 'Mensuel', 'price_fcfa' => 8000, 'price_eur' => 12, 'duration_days' => 30, 'badge' => 'Populaire'],
                ['type' => 'quarterly', 'name' => 'Trimestriel', 'price_fcfa' => 20000, 'price_eur' => 30, 'duration_days' => 97, 'badge' => 'Meilleure offre', 'discount' => '-33%'],
                ['type' => 'vip', 'name' => 'VIP Premium', 'price_fcfa' => 15000, 'price_eur' => 23, 'duration_days' => 30, 'badge' => 'VIP'],
            ],
        ]);
    }
}
```

### J7 (2h) - Job d'expiration

```php
// app/Jobs/CheckExpiredSubscriptionsJob.php
class CheckExpiredSubscriptionsJob implements ShouldQueue
{
    public function handle()
    {
        // Désactiver premium expirés
        User::where('is_premium', true)
            ->where('subscription_expires_at', '<', now())
            ->chunk(100, function($users) {
                foreach ($users as $user) {
                    $user->update(['is_premium' => false]);
                    $user->notify(new SubscriptionExpiredNotification());
                }
            });
        
        // Notifier expirations imminentes (J-3)
        User::where('is_premium', true)
            ->whereBetween('subscription_expires_at', [
                now()->addDays(2),
                now()->addDays(3),
            ])
            ->chunk(100, function($users) {
                foreach ($users as $user) {
                    $user->notify(new SubscriptionExpiringNotification(3));
                }
            });
    }
}

// Schedule dans bootstrap/app.php
->withSchedule(function (Schedule $schedule) {
    $schedule->job(new CheckExpiredSubscriptionsJob)->dailyAt('10:00');
})
```

---

## ✅ CRITÈRES DE VALIDATION

- [ ] Paydunya sandbox : paiement test réussi
- [ ] Paydunya prod : 1 paiement réel testé (ton propre compte)
- [ ] Stripe sandbox : paiement test CB réussi
- [ ] Webhook Paydunya activate l'abonnement
- [ ] Webhook Stripe activate l'abonnement
- [ ] User devient premium automatiquement après paiement
- [ ] Email/notif envoyée après activation
- [ ] Job d'expiration fonctionne (cron)
- [ ] Bonus parrainage appliqué (1 filleul = 3j)

---

## 🐛 PIÈGES À ÉVITER

### Webhook signatures non vérifiées
```php
// Stripe : vérifier signature
$event = \Stripe\Webhook::constructEvent(
    $payload, $sigHeader, config('services.stripe.webhook_secret')
);
```

### Double activation
```php
// Toujours vérifier que payment n'est pas déjà completed
if ($payment->status === 'completed') return;
```

### Currency mismatch
```php
// Toujours stocker en BDD avec la devise originale
'amount' => 8000, // FCFA
'currency' => 'XOF',
// Conversion en €/$ uniquement à l'affichage
```

---

## 📊 ESTIMATION TEMPS

| Tâche | Heures |
|-------|--------|
| Setup Paydunya | 4h |
| Service Paydunya | 8h |
| Webhook + Subscription | 4h |
| Stripe | 4h |
| Endpoints API | 4h |
| Job expiration + tests | 6h |
| **TOTAL** | **30h** |

---

## 🔗 PROCHAINE ÉTAPE

✅ Sprint 05 → `SPRINT-06-Affiliation.md`
